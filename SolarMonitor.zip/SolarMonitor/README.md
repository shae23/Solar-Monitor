# Solar Monitor

Private Android app for the home solar system, using the SOLARMAN OpenAPI.
Sign in once inside the app with the App ID, App Secret, SOLARMAN email and password.
Nothing secret is stored in this repository.
