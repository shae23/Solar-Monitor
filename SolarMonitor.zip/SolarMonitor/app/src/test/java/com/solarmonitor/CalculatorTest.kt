package com.solarmonitor

import com.solarmonitor.data.parseDay
import com.solarmonitor.data.parseLive
import com.solarmonitor.logic.BatteryOutlook
import com.solarmonitor.logic.Source
import com.solarmonitor.logic.batteryOutlook
import com.solarmonitor.logic.formatDate
import com.solarmonitor.logic.formatDuration
import com.solarmonitor.logic.formatTime
import com.solarmonitor.logic.shares
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.ZoneId

class CalculatorTest {
    private val now = Instant.parse("2026-10-13T12:00:00Z")

    @Test
    fun runsOutAfter233Minutes() {
        val r = batteryOutlook(now, 68.0, 16.0, 20.0, 1980.0)
        assertTrue(r is BatteryOutlook.RunsOut)
        assertEquals(233L, (r as BatteryOutlook.RunsOut).minutes)
    }

    @Test
    fun fullAfter103Minutes() {
        val r = batteryOutlook(now, 54.0, 16.0, 20.0, -4300.0)
        assertTrue(r is BatteryOutlook.FullAt)
        assertEquals(103L, (r as BatteryOutlook.FullAt).minutes)
    }

    @Test
    fun idleAndReserve() {
        assertTrue(batteryOutlook(now, 50.0, 16.0, 20.0, 5.0) is BatteryOutlook.Idle)
        assertTrue(batteryOutlook(now, 18.0, 16.0, 20.0, 1000.0) is BatteryOutlook.AtReserve)
    }

    @Test
    fun sharesSumTo100() {
        val s = shares(1000.0, 1000.0, 800.0, 0.0)
        assertEquals(listOf(36, 36, 28), s.map { it.percent })
        assertEquals(listOf(Source.SOLAR, Source.GRID, Source.BATTERY), s.map { it.source })
        assertEquals(100, s.sumOf { it.percent })
    }

    @Test
    fun noSharesWhenNothingActive() {
        assertTrue(shares(0.0, 0.0, -500.0, 0.0).isEmpty())
    }

    @Test
    fun durationText() {
        assertEquals("3 h 53 min", formatDuration(233))
        assertEquals("45 min", formatDuration(45))
    }

    @Test
    fun parsesLive() {
        val j = JSONObject("""{"generationPower":2100,"usePower":1500,"batteryPower":-900,"batterySoc":68,"purchasePower":0}""")
        val p = parseLive(j)
        assertEquals(2100.0, p.solarW, 0.001)
        assertEquals(-900.0, p.batteryW, 0.001)
        assertEquals(68.0, p.soc, 0.001)
    }

    @Test
    fun chargingFromRealReply() {
        val j = JSONObject("""{"chargePower":-876.15,"batteryPower":-876.15,"dischargePower":0,"generationPower":1555,"usePower":678.85,"batterySoc":30,"gridPower":null,"purchasePower":null}""")
        val p = parseLive(j)
        assertEquals(-876.15, p.batteryW, 0.001)
    }

    @Test
    fun dischargingAtNight() {
        val j = JSONObject("""{"chargePower":0,"batteryPower":1390,"dischargePower":1390,"generationPower":0,"usePower":1390,"batterySoc":63}""")
        assertEquals(1390.0, parseLive(j).batteryW, 0.001)
    }

    @Test
    fun balanceFixesWrongSign() {
        val j = JSONObject("""{"batteryPower":1380,"generationPower":1830,"usePower":443,"batterySoc":28}""")
        assertEquals(-1380.0, parseLive(j).batteryW, 0.001)
    }

    @Test
    fun parsesDay() {
        val j = JSONObject("""{"stationDataItems":[{"generationValue":10.5,"useValue":12.0,"gridValue":0,"buyValue":1.5}]}""")
        val d = parseDay(j)
        assertEquals(10.5, d.productionKwh!!, 0.001)
        assertEquals(1.5, d.purchaseKwh!!, 0.001)
    }

    @Test
    fun timeAndDateText() {
        val at = Instant.parse("2026-10-13T20:45:00Z")
        val zone = ZoneId.of("America/Jamaica")
        assertEquals("3:45 PM", formatTime(at, zone))
        assertEquals("Tue 13 Oct", formatDate(at, zone))
    }
}
