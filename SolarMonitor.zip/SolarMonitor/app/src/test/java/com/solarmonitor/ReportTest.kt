package com.solarmonitor

import com.solarmonitor.data.DayPoint
import com.solarmonitor.data.parseDays
import com.solarmonitor.data.parseFrame
import com.solarmonitor.logic.billCycle
import com.solarmonitor.logic.percentSplit
import com.solarmonitor.logic.total
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

class ReportTest {
    @Test
    fun parsesDaysFromRealShape() {
        val j = JSONObject(
            """{"total":1,"stationDataItems":[{"useValue":6.1,"year":2026,"month":10,"day":13,
            "generationValue":8.0,"chargeValue":1.2,"dischargeValue":5.7,"buyValue":0,"gridValue":0}]}"""
        )
        val d = parseDays(j)
        assertEquals(1, d.size)
        assertEquals(LocalDate.of(2026, 10, 13), d[0].date)
        assertEquals(5.7, d[0].dischargeKwh, 0.001)
        assertEquals(6.1, d[0].useKwh, 0.001)
    }

    @Test
    fun splitsAddUp() {
        val e = listOf(DayPoint(LocalDate.of(2026, 10, 13), 10.0, 8.0, 1.0, 0.0, 3.0, 4.0)).total()
        assertEquals(7.0, e.toLoad, 0.001)
        assertEquals(3.0, e.fromSolar, 0.001)
        assertEquals(100, percentSplit(listOf(e.toLoad, e.toBattery, e.toGrid)).sum())
    }

    @Test
    fun percentsOfZeroAreZero() {
        assertEquals(listOf(0, 0, 0), percentSplit(listOf(0.0, 0.0, 0.0)))
    }

    @Test
    fun billCycleStartsOnTheChosenDay() {
        val (s, e) = billCycle(LocalDate.of(2026, 10, 13), 19)
        assertEquals(LocalDate.of(2026, 9, 19), s)
        assertEquals(LocalDate.of(2026, 10, 18), e)
        val (s2, e2) = billCycle(LocalDate.of(2026, 10, 19), 19)
        assertEquals(LocalDate.of(2026, 10, 19), s2)
        assertEquals(LocalDate.of(2026, 11, 18), e2)
    }

    @Test
    fun billCycleInJanuaryLooksBackToDecember() {
        val (s, e) = billCycle(LocalDate.of(2027, 1, 5), 19)
        assertEquals(LocalDate.of(2026, 12, 19), s)
        assertEquals(LocalDate.of(2027, 1, 18), e)
    }

    @Test
    fun parsesFrameWithTextTimes() {
        val j = JSONObject(
            """{"stationDataItems":[
            {"dateTime":"2026-10-13 08:30:00","generationPower":1555,"usePower":678.85,"batteryPower":-876.15,"batterySoc":30},
            {"dateTime":"2026-10-13 08:35:00","generationPower":1600,"usePower":700,"batteryPower":-900,"batterySoc":31}]}"""
        )
        val p = parseFrame(j, ZoneId.of("UTC"), false)
        assertEquals(2, p.size)
        assertEquals(8.5f, p[0].hour, 0.001f)
        assertEquals(-876.15, p[0].batteryW, 0.001)
    }
}
