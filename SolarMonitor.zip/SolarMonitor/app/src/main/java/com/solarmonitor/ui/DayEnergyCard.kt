package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.solarmonitor.data.DayTotals
import com.solarmonitor.data.PlantBattery
import com.solarmonitor.data.PowerNow
import com.solarmonitor.data.Store
import com.solarmonitor.logic.formatKwh
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** One daily figure that can be shown on the second page of the battery card. */
private class DayCard(val key: String, val label: String, val icon: ImageVector, val tone: Color, val value: (DayTotals) -> Double?)

private val AllCards = listOf(
    DayCard("prod", "Daily Production", Icons.Rounded.WbSunny, Palette.Solar) { it.productionKwh },
    DayCard("cons", "Daily Consumption", Icons.Rounded.Home, Palette.Text) { it.usedKwh },
    DayCard("chg", "Daily Charging", Icons.Rounded.ArrowUpward, Palette.Battery) { it.chargeKwh },
    DayCard("dis", "Daily Discharging", Icons.Rounded.ArrowDownward, Palette.Discharge) { it.dischargeKwh },
    DayCard("buy", "Daily Purchase", Icons.Rounded.ShoppingCart, Palette.Grid) { it.purchaseKwh },
    DayCard("feed", "Daily Feed-In", Icons.Rounded.Power, Palette.Grid) { it.exportKwh }
)
private val DefaultKeys = AllCards.map { it.key }
private fun cardOf(key: String): DayCard? = AllCards.firstOrNull { it.key == key }

/** The battery card with a second page, reached by swiping, showing the day's figures. */
@Composable
fun BatteryPager(
    now: PowerNow,
    battery: PlantBattery?,
    hasData: Boolean,
    day: DayTotals,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pager = rememberPagerState(pageCount = { 2 })
    val context = LocalContext.current
    val store = remember { Store(context.applicationContext) }
    var shown by remember { mutableStateOf(store.dayCards()?.filter { cardOf(it) != null } ?: DefaultKeys) }
    var choosing by remember { mutableStateOf(false) }

    Column(modifier.fillMaxWidth()) {
        HorizontalPager(state = pager, pageSpacing = 8.dp, verticalAlignment = Alignment.Top) { page ->
            if (page == 0) RunOutCard(now, battery, hasData, onOpenSettings)
            else DayEnergyCard(day, shown, onChoose = { choosing = true })
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            for (i in 0 until 2) {
                val on = pager.currentPage == i
                Box(
                    Modifier
                        .padding(horizontal = 3.dp)
                        .height(6.dp)
                        .width(if (on) 18.dp else 6.dp)
                        .clip(CircleShape)
                        .background(if (on) Palette.TextSecondary else Palette.IdleLine)
                )
            }
        }
    }

    if (choosing) {
        CardChooser(
            current = shown,
            onDismiss = { choosing = false },
            onSave = { keys ->
                shown = keys
                store.saveDayCards(keys)
                choosing = false
            }
        )
    }
}

@Composable
private fun DayEnergyCard(day: DayTotals, keys: List<String>, onChoose: () -> Unit, modifier: Modifier = Modifier) {
    val dateText = DateTimeFormatter.ofPattern("EEE d MMM", Locale.US).format(LocalDate.now())
    val cards = keys.mapNotNull { cardOf(it) }
    Column(
        modifier
            .fillMaxWidth()
            .heightIn(min = 232.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.RunCard)
            .padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(Palette.Battery.copy(alpha = 0.6f)))
            Spacer(Modifier.width(8.dp))
            Text("Today", color = Palette.Battery, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Text(dateText, color = Palette.TextSecondary, fontSize = 14.sp)
            Spacer(Modifier.width(10.dp))
            IconButton(
                onClick = onChoose,
                modifier = Modifier.size(40.dp),
                colors = IconButtonDefaults.iconButtonColors(containerColor = Palette.InverterBody, contentColor = Palette.NavOn)
            ) {
                Icon(Icons.Rounded.Dashboard, contentDescription = "Choose cards", modifier = Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        if (cards.isEmpty()) {
            Text("No cards shown. Tap the button to add some.", color = Palette.TextSecondary, fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp))
        } else {
            // Left column starts at the card's left margin and the right column ends at its right margin.
            Row(Modifier.fillMaxWidth().padding(end = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    cards.filterIndexed { i, _ -> i % 2 == 0 }.forEach { Figure(it, day) }
                }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    cards.filterIndexed { i, _ -> i % 2 == 1 }.forEach { Figure(it, day) }
                }
            }
        }
    }
}

@Composable
private fun Figure(card: DayCard, day: DayTotals) {
    Row(Modifier.height(44.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(card.icon, contentDescription = null, tint = card.tone, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(fontSize = 24.sp, fontWeight = FontWeight.Medium, color = Palette.Text)) { append(formatKwh(card.value(day))) }
                    withStyle(SpanStyle(fontSize = 12.sp, color = Palette.TextSecondary)) { append(" kWh") }
                },
                maxLines = 1
            )
            Text(card.label, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1, softWrap = false)
        }
    }
}

/** Full screen list for choosing which daily cards show and in what order. */
@Composable
private fun CardChooser(current: List<String>, onDismiss: () -> Unit, onSave: (List<String>) -> Unit) {
    var order by remember { mutableStateOf(current) }
    var dragging by remember { mutableStateOf<String?>(null) }
    var dragY by remember { mutableFloatStateOf(0f) }
    val rowPx = with(LocalDensity.current) { (54.dp + 8.dp).toPx() }
    val more = DefaultKeys.filter { it !in order }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        Box(Modifier.fillMaxSize().background(Palette.Background)) {
            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Palette.Text)
                    }
                    Spacer(Modifier.weight(1f))
                    Row(
                        Modifier.clip(RoundedCornerShape(12.dp)).clickable0 { order = DefaultKeys }.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null, tint = Palette.Solar, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Restore Default", color = Palette.Solar, fontSize = 14.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("Displayed", color = Palette.Text, fontSize = 19.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
                Text("Drag the handles on the left to change the order on the card.", color = Palette.TextSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))

                order.forEach { key ->
                    val card = cardOf(key) ?: return@forEach
                    androidx.compose.runtime.key(key) {
                        val isDragging = dragging == key
                        Row(
                            Modifier
                                .padding(bottom = 8.dp)
                                .fillMaxWidth()
                                .height(54.dp)
                                .graphicsLayer { translationY = if (isDragging) dragY else 0f }
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isDragging) Palette.RunCard else Palette.Card),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                    .width(44.dp)
                                    .height(54.dp)
                                    .pointerInput(key) {
                                        detectDragGestures(
                                            onDragStart = { dragging = key; dragY = 0f },
                                            onDragEnd = { dragging = null; dragY = 0f },
                                            onDragCancel = { dragging = null; dragY = 0f },
                                            onDrag = { change, amount ->
                                                change.consume()
                                                dragY += amount.y
                                                val idx = order.indexOf(key)
                                                if (dragY > rowPx / 2f && idx < order.lastIndex) {
                                                    order = order.toMutableList().also { it.add(idx + 1, it.removeAt(idx)) }
                                                    dragY -= rowPx
                                                } else if (dragY < -rowPx / 2f && idx > 0) {
                                                    order = order.toMutableList().also { it.add(idx - 1, it.removeAt(idx)) }
                                                    dragY += rowPx
                                                }
                                            }
                                        )
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Rounded.DragIndicator, contentDescription = "Drag to reorder", tint = Palette.TextSecondary, modifier = Modifier.size(22.dp))
                            }
                            Text(card.label, color = Palette.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                            RoundButton(Icons.Rounded.Remove, Palette.Consumption, "Remove ${card.label}") { order = order - key }
                            Spacer(Modifier.width(12.dp))
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))
                Text("More Cards", color = Palette.Text, fontSize = 19.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(12.dp))
                if (more.isEmpty()) {
                    Text("Nothing more to add.", color = Palette.TextSecondary, fontSize = 13.sp)
                }
                more.forEach { key ->
                    val card = cardOf(key) ?: return@forEach
                    Row(
                        Modifier
                            .padding(bottom = 8.dp)
                            .fillMaxWidth()
                            .height(54.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Palette.Card),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(card.label, color = Palette.Text, fontSize = 15.sp, modifier = Modifier.weight(1f).padding(start = 16.dp))
                        RoundButton(Icons.Rounded.Add, Palette.Battery, "Add ${card.label}") { order = order + key }
                        Spacer(Modifier.width(12.dp))
                    }
                }
            }
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Palette.Solar)
                        .clickable0 { onSave(order) },
                    contentAlignment = Alignment.Center
                ) {
                    Text("Save", color = Palette.Background, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun RoundButton(icon: ImageVector, tone: Color, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(30.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(tone.copy(alpha = 0.18f))
            .clickable0(onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = tone, modifier = Modifier.size(18.dp))
    }
}

private fun Modifier.clickable0(onClick: () -> Unit): Modifier = this.then(Modifier.clickable(onClick = onClick))
