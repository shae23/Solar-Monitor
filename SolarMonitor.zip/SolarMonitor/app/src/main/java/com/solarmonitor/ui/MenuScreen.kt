package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.UiState
import com.solarmonitor.data.Settings

@Composable
fun MenuScreen(state: UiState, onSettings: (Settings) -> Unit, onSignOut: () -> Unit) {
    val s = state.settings
    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Menu", color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)

        Card {
            Text("Account", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(state.email, color = Palette.TextSecondary, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onSignOut) { Text("Sign out") }
        }

        Card {
            Text("Refresh every", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 2, 5).forEach { m ->
                    FilterChip(
                        selected = s.refreshMinutes == m,
                        onClick = { onSettings(s.copy(refreshMinutes = m)) },
                        label = { Text("$m min") }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            val perHour = (60 / s.refreshMinutes) * 2
            Text(
                "${s.refreshMinutes} min uses about $perHour calls an hour while the app is open. " +
                    "The free plan allows about 540 a day. Near the daily limit the app slows down by itself.",
                color = Palette.TextSecondary, fontSize = 13.sp
            )
        }

        Card {
            SwitchRow("Show generator", "Draws the generator on the Home diagram", s.showGenerator) {
                onSettings(s.copy(showGenerator = it))
            }
            Spacer(Modifier.height(12.dp))
            SwitchRow(
                "Flip battery direction",
                "Turn on if charging shows as discharging, or the other way round",
                s.invertBattery
            ) { onSettings(s.copy(invertBattery = it)) }
        }
    }
}

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.Card)
            .padding(16.dp),
        content = { content() }
    )
}

@Composable
private fun SwitchRow(title: String, note: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(note, color = Palette.TextSecondary, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
