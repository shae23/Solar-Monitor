package com.solarmonitor.data

/** Group names and order for the inverter and logger readings, matching SOLARMAN's own app. The API sends no group, so this is matched by reading name. */
val InverterGroups: List<Pair<String, List<String>>> = listOf(
    "Basic Information" to listOf("SN", "Product Name", "PV Open Circuit Voltage", "PV Maximum Charging Current", "Rated Output Power", "Parallel Mode", "System Time"),
    "Version Information" to listOf("BMS Version1", "BMS Version2", "Software Version Number 1", "Software Version Number 2", "Hardware Version", "Software Version Number 4", "Upgrade Flag Bit", "Minor version number"),
    "Electricity Generation" to listOf("DC Voltage PV1", "DC Voltage PV2", "DC Current PV1", "DC Current PV2", "DC Power PV1", "DC Power PV2", "AC Voltage R/U/A", "AC Voltage S/V/B", "AC Current R/U/A", "AC Current S/V/B", "AC Output Frequency R", "Total AC Output Power (Active)", "Cumulative Production (Active)", "Daily Production (Active)", "PV Total Charging Power", "Total Charging Power (PV + Mains)"),
    "Grid" to listOf("Grid Status", "Grid Frequency", "Cumulative Grid Feed-in", "Cumulative Energy Purchased", "Daily Grid Feed-in", "Daily Energy Purchased", "Mains Charging Power", "Total Active Power Of The Grid", "Utility Charge Current", "Grid Code"),
    "Consumption" to listOf("Load Power L1", "Load Power L2", "Consumption Current R/U/A", "Cumulative Consumption", "Daily Consumption", "L1 Load Rate", "L2 Load Rate", "Load Rate Of Whole Machine", "L1 Load Apparent Power"),
    "Battery" to listOf("Battery Status", "Battery Charging Type", "Battery Voltage", "Battery Current", "Battery Power", "SoC", "Total Charging Energy", "Total Discharging Energy", "Daily Charging Energy", "Daily Discharging Energy", "Battery 1 Status"),
    "Battery2" to listOf("Bat2 Battery voltage", "Bat2 current", "Battery 2 power", "Bat2 SoC", "Bat2 BMS Status"),
    "BMS" to listOf("SOH", "Battery rated capacity", "Battery remain capacity", "Number of battery cycles", "Battery temperature", "Battery charge voltage", "Charge current limit", "Discharge current limit", "Alarms 1", "Alarms 2", "Protection 1", "Protection 2"),
    "Temperature" to listOf("Environment Temperature", "Inverter radiator temperature", "Temperature- Transformer", "PV radiator temperature"),
    "State" to listOf("Inverter status", "System Status"),
    "Generator" to listOf("Generator Operation Mode", "Total Generator Power", "Gen Voltage L1", "Gen Current L1", "Generator Active Power L1", "Generator Frequency", "Daily generator output", "Total generator output"),
    "Microinverter" to listOf("MI Power L1", "MI Power L2", "MI Power L3"),
    "Parallel Information" to listOf("Number Of Parallel Machines", "Total Local Load Power Of Parallel System", "Total Household Load Power Of Parallel System", "Total Grid Power Of Parallel System", "Total Oil Engine Port Power Of Parallel System")
)

val LoggerGroups: List<Pair<String, List<String>>> = listOf(
    "Basic Information" to listOf("Embedded Device SN"),
    "Version Information" to listOf("Module Version No"),
    "Operation Information" to listOf("Data Uploading Period", "Data Acquisition Period", "Max. No. of Connected Devices", "Signal Strength", "Module MAC Address", "Router SSID", "CSIP Control Capability Flag", "CSIP Scheduling Function Enable Flag", "Number Of CSIP Data Model Supports", "MESH-NETID", "MESH-NET-GROUP", "Policy Scheduling Enable Flag"),
    "State" to listOf("Quick Refresh Flag")
)
