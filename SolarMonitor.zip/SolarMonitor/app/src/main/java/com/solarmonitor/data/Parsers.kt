package com.solarmonitor.data

import org.json.JSONObject
import kotlin.math.abs

private fun JSONObject.num(vararg keys: String): Double? {
    for (k in keys) {
        if (has(k) && !isNull(k)) {
            val v = optDouble(k, Double.NaN)
            if (!v.isNaN()) return v
        }
    }
    return null
}

/**
 * Reads the plant live data reply. Battery power is positive while discharging and
 * negative while charging. If the reply only has a single battery power value, its
 * sign is taken as positive for discharging. The Menu has a switch to flip it.
 */
fun parseLive(json: JSONObject): PowerNow {
    val charge = json.num("chargePower")
    val discharge = json.num("dischargePower")
    val net = (discharge ?: 0.0) - (charge ?: 0.0)
    val battery = if (abs(net) >= 1.0) net else (json.num("batteryPower") ?: 0.0)

    val grid = json.num("purchasePower")
        ?: json.num("gridPower")?.coerceAtLeast(0.0)
        ?: 0.0

    val updated = json.num("lastUpdateTime")?.let {
        if (it > 1.0e11) (it / 1000.0).toLong() else it.toLong()
    }

    return PowerNow(
        solarW = json.num("generationPower") ?: 0.0,
        gridW = grid,
        batteryW = battery,
        generatorW = json.num("generatorPower", "genPower") ?: 0.0,
        loadW = json.num("usePower") ?: 0.0,
        soc = json.num("batterySoc") ?: 0.0,
        updatedEpochSec = updated
    )
}

/** Reads the daily history reply and returns the totals for the last item in it. */
fun parseDay(json: JSONObject): DayTotals {
    val items = json.optJSONArray("stationDataItems")
    val item = if (items != null && items.length() > 0) items.optJSONObject(items.length() - 1) else null
    if (item == null) return DayTotals(null, null, null, null)
    return DayTotals(
        productionKwh = item.num("generationValue"),
        usedKwh = item.num("useValue", "consumptionValue"),
        exportKwh = item.num("gridValue", "sellValue", "feedInValue"),
        purchaseKwh = item.num("buyValue", "purchaseValue")
    )
}
