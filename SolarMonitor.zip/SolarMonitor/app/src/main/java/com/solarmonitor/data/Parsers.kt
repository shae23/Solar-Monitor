package com.solarmonitor.data

import org.json.JSONObject
import kotlin.math.abs

private fun JSONObject.num(vararg keys: String): Double? {
    for (k in keys) {
        if (has(k) && !isNull(k)) {
            val v = optDouble(k, Double.NaN)
            if (!v.isNaN()) return v
        }
    }
    return null
}

/**
 * Reads the plant live data reply. SOLARMAN already sends charging as a negative number
 * (chargePower and batteryPower are both negative while charging), so battery power here is
 * positive while discharging and negative while charging. batteryPower is used when present.
 * If a large reading disagrees with the energy balance (solar + grid + generator - house),
 * the balance decides the direction.
 */
fun parseLive(json: JSONObject): PowerNow {
    val solar = json.num("generationPower") ?: 0.0
    val load = json.num("usePower") ?: 0.0
    val generator = json.num("generatorPower", "genPower") ?: 0.0
    val grid = json.num("purchasePower")
        ?: json.num("gridPower")?.coerceAtLeast(0.0)
        ?: 0.0

    val charge = json.num("chargePower")
    val discharge = json.num("dischargePower")
    var battery = json.num("batteryPower")
        ?: if ((discharge ?: 0.0) > 0.0) discharge!! else -abs(charge ?: 0.0)

    val surplus = solar + grid + generator - load
    if (abs(battery) > 300.0 && abs(surplus) > 300.0 && (battery > 0.0) == (surplus > 0.0)) {
        battery = -battery
    }

    val updated = json.num("lastUpdateTime")?.let {
        if (it > 1.0e11) (it / 1000.0).toLong() else it.toLong()
    }

    return PowerNow(
        solarW = solar,
        gridW = grid,
        batteryW = battery,
        generatorW = generator,
        loadW = load,
        soc = json.num("batterySoc") ?: 0.0,
        updatedEpochSec = updated
    )
}

/** Reads the daily history reply and returns the totals for the last item in it. */
fun parseDay(json: JSONObject): DayTotals {
    val items = json.optJSONArray("stationDataItems")
    val item = if (items != null && items.length() > 0) items.optJSONObject(items.length() - 1) else null
    if (item == null) return DayTotals(null, null, null, null)
    return DayTotals(
        productionKwh = item.num("generationValue"),
        usedKwh = item.num("useValue", "consumptionValue"),
        exportKwh = item.num("gridValue", "sellValue", "feedInValue"),
        purchaseKwh = item.num("buyValue", "purchaseValue")
    )
}
