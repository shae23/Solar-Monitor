package com.solarmonitor.data

import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs

private fun JSONObject.num(vararg keys: String): Double? {
    for (k in keys) {
        if (has(k) && !isNull(k)) {
            val v = optDouble(k, Double.NaN)
            if (!v.isNaN()) return v
        }
    }
    return null
}

/**
 * Battery power in watts, positive while discharging and negative while charging.
 * batteryPower is used when present. A large reading that disagrees with the energy
 * balance (solar + grid + generator - house) is flipped, because the balance is physics.
 */
fun batteryPowerOf(json: JSONObject, solar: Double, grid: Double, generator: Double, load: Double): Double {
    val charge = json.num("chargePower")
    val discharge = json.num("dischargePower")
    var battery = json.num("batteryPower")
        ?: if ((discharge ?: 0.0) > 0.0) discharge!! else -abs(charge ?: 0.0)
    val surplus = solar + grid + generator - load
    if (abs(battery) > 300.0 && abs(surplus) > 300.0 && (battery > 0.0) == (surplus > 0.0)) {
        battery = -battery
    }
    return battery
}

/**
 * Reads the plant live data reply. SOLARMAN already sends charging as a negative number
 * (chargePower and batteryPower are both negative while charging), so battery power here is
 * positive while discharging and negative while charging. batteryPower is used when present.
 * If a large reading disagrees with the energy balance (solar + grid + generator - house),
 * the balance decides the direction.
 */
fun parseLive(json: JSONObject): PowerNow {
    val solar = json.num("generationPower") ?: 0.0
    val load = json.num("usePower") ?: 0.0
    val generator = json.num("generatorPower", "genPower") ?: 0.0
    val grid = json.num("purchasePower")
        ?: json.num("gridPower")?.coerceAtLeast(0.0)
        ?: 0.0

    val battery = batteryPowerOf(json, solar, grid, generator, load)

    val updated = json.num("lastUpdateTime")?.let {
        if (it > 1.0e11) (it / 1000.0).toLong() else it.toLong()
    }

    return PowerNow(
        solarW = solar,
        gridW = grid,
        batteryW = battery,
        generatorW = generator,
        loadW = load,
        soc = json.num("batterySoc") ?: 0.0,
        updatedEpochSec = updated
    )
}

/** Reads the daily history reply and returns the totals for the last item in it. */
fun parseDay(json: JSONObject): DayTotals {
    val items = json.optJSONArray("stationDataItems")
    val item = if (items != null && items.length() > 0) items.optJSONObject(items.length() - 1) else null
    if (item == null) return DayTotals(null, null, null, null)
    return DayTotals(
        productionKwh = item.num("generationValue"),
        usedKwh = item.num("useValue", "consumptionValue"),
        exportKwh = item.num("gridValue", "sellValue", "feedInValue"),
        purchaseKwh = item.num("buyValue", "purchaseValue")
    )
}

private fun JSONObject.items(): List<JSONObject> {
    val arr = optJSONArray("stationDataItems") ?: return emptyList()
    val out = ArrayList<JSONObject>()
    for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { out.add(it) }
    return out
}

/**
 * Reads a day or month history reply into one point per item. The date comes from the
 * year, month and day fields. A month reply has no day, so it is taken as the 1st.
 */
fun parseDays(json: JSONObject): List<DayPoint> {
    val out = ArrayList<DayPoint>()
    for (it in json.items()) {
        val y = it.num("year")?.toInt() ?: continue
        val m = it.num("month")?.toInt() ?: continue
        val d = it.num("day")?.toInt() ?: 1
        val date = try { LocalDate.of(y, m, d) } catch (e: Exception) { continue }
        out.add(
            DayPoint(
                date = date,
                prodKwh = it.num("generationValue") ?: 0.0,
                useKwh = it.num("useValue", "consumptionValue") ?: 0.0,
                buyKwh = it.num("buyValue", "purchaseValue") ?: 0.0,
                gridKwh = it.num("gridValue", "sellValue", "feedInValue") ?: 0.0,
                chargeKwh = it.num("chargeValue") ?: 0.0,
                dischargeKwh = it.num("dischargeValue") ?: 0.0
            )
        )
    }
    return out.sortedBy { it.date }
}

private val FrameText = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

/** Turns a frame time (seconds, milliseconds or text) into a local date and time. */
fun frameTime(item: JSONObject, zone: ZoneId): LocalDateTime? {
    for (k in listOf("dateTime", "timeStamp", "time", "collectTime", "updateTime")) {
        if (!item.has(k) || item.isNull(k)) continue
        val n = item.optDouble(k, Double.NaN)
        if (!n.isNaN()) {
            val sec = if (n > 1.0e11) (n / 1000.0).toLong() else n.toLong()
            return LocalDateTime.ofInstant(Instant.ofEpochSecond(sec), zone)
        }
        val t = item.optString(k)
        try { return LocalDateTime.parse(t, FrameText) } catch (e: Exception) { }
        try { return LocalDateTime.parse(t.replace(' ', 'T')) } catch (e: Exception) { }
    }
    return null
}

/** Reads the timed readings for one day. invert flips the battery sign like the Menu switch. */
fun parseFrame(json: JSONObject, zone: ZoneId, invert: Boolean): List<IntraPoint> {
    val out = ArrayList<IntraPoint>()
    for (it in json.items()) {
        val at = frameTime(it, zone) ?: continue
        val solar = it.num("generationPower") ?: 0.0
        val load = it.num("usePower") ?: 0.0
        val grid = it.num("purchasePower") ?: it.num("gridPower")?.coerceAtLeast(0.0) ?: 0.0
        var batt = batteryPowerOf(it, solar, grid, 0.0, load)
        if (invert) batt = -batt
        out.add(
            IntraPoint(
                hour = at.hour + at.minute / 60f + at.second / 3600f,
                solarW = solar,
                loadW = load,
                gridW = grid,
                batteryW = batt,
                soc = it.num("batterySoc") ?: 0.0,
                generatorW = it.num("generatorPower") ?: it.num("generatorPowerW") ?: 0.0,
                upsW = it.num("upsLoadPower") ?: it.num("upsPower") ?: it.num("backupPower") ?: 0.0,
                pileW = it.num("chargingPilePower") ?: it.num("pilePower") ?: it.num("evPower") ?: 0.0,
                feedInW = it.num("feedInPower") ?: it.num("gridPower")?.let { g -> if (g < 0) -g else 0.0 } ?: 0.0
            )
        )
    }
    return out.sortedBy { it.hour }
}

/** A short sample of a history reply (first two items) for the Device tab. */
fun sampleOf(json: JSONObject): String {
    val arr = json.optJSONArray("stationDataItems") ?: return json.toString(2)
    val keep = org.json.JSONArray()
    for (i in 0 until minOf(2, arr.length())) keep.put(arr.opt(i))
    return JSONObject().put("total", arr.length()).put("firstItems", keep).toString(2)
}

/** The inverter's serial number from a plant device list. Prefers an inverter over a logger. */
fun pickInverterSn(json: JSONObject): String? {
    val arr = json.optJSONArray("deviceListItems") ?: json.optJSONArray("deviceList") ?: return null
    var fallback: String? = null
    for (i in 0 until arr.length()) {
        val d = arr.optJSONObject(i) ?: continue
        val sn = d.optString("deviceSn").takeIf { it.isNotBlank() } ?: continue
        if (d.optString("deviceType").contains("INVERTER", ignoreCase = true)) return sn
        if (fallback == null) fallback = sn
    }
    return fallback
}

/** The named readings in a device current-data reply. */
fun parseInverterItems(json: JSONObject): List<InverterItem> {
    val arr = json.optJSONArray("dataList") ?: return emptyList()
    val out = ArrayList<InverterItem>()
    for (i in 0 until arr.length()) {
        val d = arr.optJSONObject(i) ?: continue
        val key = d.optString("key")
        val name = d.optString("name").ifBlank { key }
        if (name.isBlank()) continue
        out.add(
            InverterItem(
                key = key, name = name,
                value = d.opt("value")?.toString().orEmpty(),
                unit = d.optString("unit"),
                group = d.optString("groupName")
            )
        )
    }
    return out
}
