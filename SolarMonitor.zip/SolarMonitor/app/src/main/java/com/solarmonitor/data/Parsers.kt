package com.solarmonitor.data

import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.abs

private fun JSONObject.num(vararg keys: String): Double? {
    for (k in keys) {
        if (has(k) && !isNull(k)) {
            val v = optDouble(k, Double.NaN)
            if (!v.isNaN()) return v
        }
    }
    return null
}

/**
 * Battery power in watts, positive while discharging and negative while charging.
 * batteryPower is used when present. A large reading that disagrees with the energy
 * balance (solar + grid + generator - house) is flipped, because the balance is physics.
 */
fun batteryPowerOf(json: JSONObject, solar: Double, grid: Double, generator: Double, load: Double): Double {
    val charge = json.num("chargePower")
    val discharge = json.num("dischargePower")
    var battery = json.num("batteryPower")
        ?: if ((discharge ?: 0.0) > 0.0) discharge!! else -abs(charge ?: 0.0)
    val surplus = solar + grid + generator - load
    if (abs(battery) > 300.0 && abs(surplus) > 300.0 && (battery > 0.0) == (surplus > 0.0)) {
        battery = -battery
    }
    return battery
}


/**
 * Power bought from the grid, always zero or more. SOLARMAN sometimes sends purchasePower as a
 * negative number while the house is plainly drawing from the grid. A negative reading is taken as
 * buying when the rest of the system cannot cover the house (house load minus solar, generator and
 * battery discharge is above zero). Otherwise a negative reading is exporting and counts as zero.
 */
fun gridImportOf(json: JSONObject, solar: Double, generator: Double, load: Double): Double {
    val raw = json.num("purchasePower") ?: return json.num("gridPower")?.coerceAtLeast(0.0) ?: 0.0
    if (raw >= 0.0) return raw
    val charge = json.num("chargePower")
    val discharge = json.num("dischargePower")
    val batt = json.num("batteryPower")
        ?: if ((discharge ?: 0.0) > 0.0) discharge!! else -abs(charge ?: 0.0)
    val deficit = load - solar - generator - batt
    return if (deficit >= 20.0) -raw else 0.0
}

/**
 * Reads the plant live data reply. SOLARMAN already sends charging as a negative number
 * (chargePower and batteryPower are both negative while charging), so battery power here is
 * positive while discharging and negative while charging. batteryPower is used when present.
 * If a large reading disagrees with the energy balance (solar + grid + generator - house),
 * the balance decides the direction.
 */
fun parseLive(json: JSONObject): PowerNow {
    val solar = json.num("generationPower") ?: 0.0
    val load = json.num("usePower") ?: 0.0
    val generator = json.num("generatorPower", "genPower") ?: 0.0
    val grid = gridImportOf(json, solar, generator, load)

    val battery = batteryPowerOf(json, solar, grid, generator, load)

    val updated = json.num("lastUpdateTime")?.let {
        if (it > 1.0e11) (it / 1000.0).toLong() else it.toLong()
    }

    return PowerNow(
        solarW = solar,
        gridW = grid,
        batteryW = battery,
        generatorW = generator,
        loadW = load,
        soc = json.num("batterySoc") ?: 0.0,
        updatedEpochSec = updated
    )
}

/** Reads the daily history reply and returns the totals for the last item in it. */
fun parseDay(json: JSONObject): DayTotals {
    val items = json.optJSONArray("stationDataItems")
    val item = if (items != null && items.length() > 0) items.optJSONObject(items.length() - 1) else null
    if (item == null) return DayTotals(null, null, null, null)
    return DayTotals(
        productionKwh = item.num("generationValue"),
        usedKwh = item.num("useValue", "consumptionValue"),
        exportKwh = item.num("gridValue", "sellValue", "feedInValue"),
        purchaseKwh = item.num("buyValue", "purchaseValue")
    )
}

private fun JSONObject.items(): List<JSONObject> {
    val arr = optJSONArray("stationDataItems") ?: return emptyList()
    val out = ArrayList<JSONObject>()
    for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { out.add(it) }
    return out
}

/**
 * Reads a day or month history reply into one point per item. The date comes from the
 * year, month and day fields. A month reply has no day, so it is taken as the 1st.
 */
fun parseDays(json: JSONObject): List<DayPoint> {
    val out = ArrayList<DayPoint>()
    for (it in json.items()) {
        val y = it.num("year")?.toInt() ?: continue
        val m = it.num("month")?.toInt() ?: continue
        val d = it.num("day")?.toInt() ?: 1
        val date = try { LocalDate.of(y, m, d) } catch (e: Exception) { continue }
        out.add(
            DayPoint(
                date = date,
                prodKwh = it.num("generationValue") ?: 0.0,
                useKwh = it.num("useValue", "consumptionValue") ?: 0.0,
                buyKwh = it.num("buyValue", "purchaseValue") ?: 0.0,
                gridKwh = it.num("gridValue", "sellValue", "feedInValue") ?: 0.0,
                chargeKwh = it.num("chargeValue") ?: 0.0,
                dischargeKwh = it.num("dischargeValue") ?: 0.0
            )
        )
    }
    return out.sortedBy { it.date }
}

private val FrameText = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

/** Turns a frame time (seconds, milliseconds or text) into a local date and time. */
fun frameTime(item: JSONObject, zone: ZoneId): LocalDateTime? {
    for (k in listOf("dateTime", "timeStamp", "time", "collectTime", "updateTime")) {
        if (!item.has(k) || item.isNull(k)) continue
        val n = item.optDouble(k, Double.NaN)
        if (!n.isNaN()) {
            val sec = if (n > 1.0e11) (n / 1000.0).toLong() else n.toLong()
            return LocalDateTime.ofInstant(Instant.ofEpochSecond(sec), zone)
        }
        val t = item.optString(k)
        try { return LocalDateTime.parse(t, FrameText) } catch (e: Exception) { }
        try { return LocalDateTime.parse(t.replace(' ', 'T')) } catch (e: Exception) { }
    }
    return null
}

/** Reads the timed readings for one day. invert flips the battery sign like the Menu switch. */
fun parseFrame(json: JSONObject, zone: ZoneId, invert: Boolean): List<IntraPoint> {
    val out = ArrayList<IntraPoint>()
    for (it in json.items()) {
        val at = frameTime(it, zone) ?: continue
        val solar = it.num("generationPower") ?: 0.0
        val load = it.num("usePower") ?: 0.0
        val grid = gridImportOf(it, solar, it.num("generatorPower") ?: 0.0, load)
        var batt = batteryPowerOf(it, solar, grid, 0.0, load)
        if (invert) batt = -batt
        out.add(
            IntraPoint(
                hour = at.hour + at.minute / 60f + at.second / 3600f,
                solarW = solar,
                loadW = load,
                gridW = grid,
                batteryW = batt,
                soc = it.num("batterySoc") ?: 0.0,
                generatorW = it.num("generatorPower") ?: it.num("generatorPowerW") ?: 0.0,
                upsW = it.num("upsLoadPower") ?: it.num("upsPower") ?: it.num("backupPower") ?: 0.0,
                pileW = it.num("chargingPilePower") ?: it.num("pilePower") ?: it.num("evPower") ?: 0.0,
                feedInW = it.num("feedInPower") ?: it.num("gridPower")?.let { g -> if (g < 0) -g else 0.0 } ?: 0.0
            )
        )
    }
    return out.sortedBy { it.hour }
}

/** A short sample of a history reply (first two items) for the Device tab. */
fun sampleOf(json: JSONObject): String {
    val arr = json.optJSONArray("stationDataItems") ?: return json.toString(2)
    val keep = org.json.JSONArray()
    for (i in 0 until minOf(2, arr.length())) keep.put(arr.opt(i))
    return JSONObject().put("total", arr.length()).put("firstItems", keep).toString(2)
}

/** The inverter's serial number from a plant device list. Prefers an inverter over a logger. */
fun pickInverterSn(json: JSONObject): String? {
    val arr = json.optJSONArray("deviceListItems") ?: json.optJSONArray("deviceList") ?: return null
    var fallback: String? = null
    for (i in 0 until arr.length()) {
        val d = arr.optJSONObject(i) ?: continue
        val sn = d.optString("deviceSn").takeIf { it.isNotBlank() } ?: continue
        if (d.optString("deviceType").contains("INVERTER", ignoreCase = true)) return sn
        if (fallback == null) fallback = sn
    }
    return fallback
}

/** The named readings in a device current-data reply. */
fun parseInverterItems(json: JSONObject): List<InverterItem> {
    val arr = json.optJSONArray("dataList") ?: return emptyList()
    val out = ArrayList<InverterItem>()
    for (i in 0 until arr.length()) {
        val d = arr.optJSONObject(i) ?: continue
        val key = d.optString("key")
        val name = d.optString("name").ifBlank { key }
        if (name.isBlank()) continue
        out.add(
            InverterItem(
                key = key, name = name,
                value = d.opt("value")?.toString().orEmpty(),
                unit = d.optString("unit"),
                group = d.optString("groupName")
            )
        )
    }
    return out
}

/** Every device SOLARMAN lists for the plant. */
fun parseDevices(json: JSONObject): List<DeviceRef> {
    val arr = json.optJSONArray("deviceListItems") ?: json.optJSONArray("deviceList") ?: return emptyList()
    val out = ArrayList<DeviceRef>()
    for (i in 0 until arr.length()) {
        val d = arr.optJSONObject(i) ?: continue
        val sn = d.optString("deviceSn").takeIf { it.isNotBlank() } ?: continue
        val online: Boolean? = when {
            d.has("connectStatus") && !d.isNull("connectStatus") -> d.optInt("connectStatus") == 1
            d.has("deviceState") && !d.isNull("deviceState") -> d.optInt("deviceState") == 1
            else -> null
        }
        out.add(DeviceRef(sn, d.optString("deviceType"), online))
    }
    return out
}

/** Sorts readings into SOLARMAN's groups. Readings the list does not know go last under Other. */
fun groupReadings(items: List<InverterItem>, groups: List<Pair<String, List<String>>>): List<Pair<String, List<InverterItem>>> {
    val byName = HashMap<String, InverterItem>()
    for (item in items) byName.putIfAbsent(item.name.trim().lowercase(), item)
    val used = HashSet<String>()
    val out = ArrayList<Pair<String, List<InverterItem>>>()
    for ((group, names) in groups) {
        val found = ArrayList<InverterItem>()
        for (n in names) {
            val k = n.trim().lowercase()
            val hit = byName[k]
            if (hit != null && used.add(k)) found.add(hit)
        }
        if (found.isNotEmpty()) out.add(group to found)
    }
    val rest = items.filter { it.name.trim().lowercase() !in used }
    if (rest.isNotEmpty()) out.add("Other" to rest)
    return out
}

/** Alarm flag and mains charging power from the inverter's readings. */
fun homeExtraOf(items: List<InverterItem>): HomeExtra {
    fun byName(n: String) = items.firstOrNull { it.name.equals(n, ignoreCase = true) }
    val flags = listOf("Alarms 1", "Alarms 2", "Protection 1", "Protection 2").mapNotNull { byName(it) }
    val alarm = flags.any { f ->
        val v = f.value.trim()
        val n = v.toDoubleOrNull()
        if (n != null) n != 0.0 else v.isNotEmpty() && !v.equals("none", true) && !v.equals("normal", true)
    }
    val mains = byName("Mains Charging Power")?.value?.trim()?.toDoubleOrNull()
    return HomeExtra(alarm, mains)
}
