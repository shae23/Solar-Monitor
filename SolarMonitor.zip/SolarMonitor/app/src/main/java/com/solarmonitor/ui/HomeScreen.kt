package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.UiState
import com.solarmonitor.logic.formatKwh
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(
    state: UiState,
    onRefresh: () -> Unit,
    onSelectPlant: (Long) -> Unit,
    onSaveBattery: (Double, Double) -> Unit,
    onOpenAlarm: () -> Unit = {}
) {
    var showPlants by rememberSaveable { mutableStateOf(false) }
    var showBattery by rememberSaveable { mutableStateOf(false) }

    val updated = state.live.updatedEpochSec?.let {
        DateTimeFormatter.ofPattern("h:mm a", Locale.US)
            .format(Instant.ofEpochSecond(it).atZone(ZoneId.systemDefault()))
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Column(Modifier.weight(1f, fill = false)) {
                Text(
                    state.plantName.ifBlank { "My solar" },
                    color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    when {
                        updated != null -> "Plant updated $updated"
                        state.loading -> "Loading..."
                        else -> "Waiting for data"
                    },
                    color = Palette.TextSecondary, fontSize = 13.sp
                )
            }
            IconButton(
                onClick = { showPlants = true },
                colors = IconButtonDefaults.iconButtonColors(containerColor = Palette.Card, contentColor = Palette.NavOn)
            ) {
                Icon(Icons.Rounded.SwapHoriz, contentDescription = "Switch plant")
            }
            Spacer(Modifier.weight(1f))
            if (state.loading) {
                CircularProgressIndicator(Modifier.size(24.dp), color = Palette.NavOn, strokeWidth = 2.dp)
                Spacer(Modifier.size(12.dp))
            } else {
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Refresh", tint = Palette.NavOn)
                }
            }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
        state.error?.let {
            Box(
                Modifier
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Palette.ErrorCard)
                    .padding(16.dp)
            ) {
                Text(it, color = Palette.ErrorText, fontSize = 14.sp)
            }
        }

        if (state.extra.alarm) {
            Row(
                Modifier
                    .padding(start = 20.dp, top = 4.dp, bottom = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Palette.ErrorCard)
                    .clickable(onClick = onOpenAlarm)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.NotificationsActive, contentDescription = null, tint = Palette.ErrorText, modifier = Modifier.size(18.dp))
                Spacer(Modifier.size(8.dp))
                Text("Has Alarm", color = Palette.ErrorText, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
        }

        // The diagram has no card around it and uses the full width of the screen.
        FlowDiagram(state.now, state.settings.showGenerator)

        Column(
            Modifier.padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val charging = maxOf(-state.now.batteryW, 0.0)
            // Solar and generator cover the house first. Whatever charging is left over comes from the grid.
            val spare = maxOf(state.now.solarW + state.now.generatorW - state.now.loadW, 0.0)
            val fromGrid = if (charging >= 20.0) minOf(maxOf(charging - spare, 0.0), maxOf(state.now.gridW, 0.0)) else 0.0
            RunOutCard(state.now, state.battery, state.hasData, onOpenSettings = { showBattery = true }, fromGridW = fromGrid)

            val d = state.day
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile("Daily production", formatKwh(d.productionKwh), Icons.Rounded.WbSunny, Palette.Solar, Modifier.weight(1f))
                Tile("Daily consumption", formatKwh(d.usedKwh), Icons.Rounded.Home, Palette.Text, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile("Grid export", formatKwh(d.exportKwh), Icons.Rounded.Power, Palette.Grid, Modifier.weight(1f))
                Tile("Grid purchase", formatKwh(d.purchaseKwh), Icons.Rounded.ShoppingCart, Palette.Grid, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
        }
        }
    }

    if (showPlants) {
        PlantSheet(state.plants, state.plantId, onSelectPlant, onDismiss = { showPlants = false })
    }
    if (showBattery) {
        BatterySheet(
            plantName = state.plantName.ifBlank { "this plant" },
            current = state.battery,
            onDismiss = { showBattery = false },
            onSave = { kwh, res ->
                onSaveBattery(kwh, res)
                showBattery = false
            }
        )
    }
}

@Composable
private fun Tile(label: String, value: String, icon: ImageVector, tint: Color, modifier: Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.Card)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(fontSize = 26.sp, fontWeight = FontWeight.Medium, color = Palette.Text)) { append(value) }
                    withStyle(SpanStyle(fontSize = 13.sp, color = Palette.TextSecondary)) { append(" kWh") }
                },
                maxLines = 1
            )
            Text(label, color = Palette.TextSecondary, fontSize = 14.sp)
        }
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(30.dp))
    }
}
