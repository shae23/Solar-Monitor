package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.UiState
import com.solarmonitor.data.Settings
import com.solarmonitor.logic.formatKwh
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun HomeScreen(
    state: UiState,
    onRefresh: () -> Unit,
    onSettings: (Settings) -> Unit
) {
    val updated = state.live.updatedEpochSec?.let {
        DateTimeFormatter.ofPattern("h:mm a", Locale.US)
            .format(Instant.ofEpochSecond(it).atZone(ZoneId.systemDefault()))
    }

    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    state.plantName.ifBlank { "My solar" },
                    color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold
                )
                Text(
                    when {
                        updated != null -> "Plant updated $updated"
                        state.loading -> "Loading..."
                        else -> "Waiting for data"
                    },
                    color = Palette.TextSecondary, fontSize = 13.sp
                )
            }
            if (state.loading) {
                CircularProgressIndicator(Modifier.size(24.dp), color = Palette.NavOn, strokeWidth = 2.dp)
                Spacer(Modifier.size(12.dp))
            } else {
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Refresh", tint = Palette.NavOn)
                }
            }
        }

        state.error?.let {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Palette.ErrorCard)
                    .padding(16.dp)
            ) {
                Text(it, color = Palette.ErrorText, fontSize = 14.sp)
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(Palette.Card)
                .padding(vertical = 16.dp, horizontal = 8.dp)
        ) {
            FlowDiagram(state.now, state.settings.showGenerator)
        }

        RunOutCard(state.now, state.settings, state.hasData, onSettings)

        val d = state.day
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("Production", formatKwh(d.productionKwh), Palette.Solar, Modifier.weight(1f))
            Tile("Used", formatKwh(d.usedKwh), Palette.Text, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("Grid export", formatKwh(d.exportKwh), Palette.Grid, Modifier.weight(1f))
            Tile("Grid purchase", formatKwh(d.purchaseKwh), Palette.Grid, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun Tile(label: String, value: String, dot: Color, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.Card)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
            Spacer(Modifier.size(8.dp))
            Text(label, color = Palette.TextSecondary, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = Palette.Text, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.size(4.dp))
            Text("kWh", color = Palette.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
        }
    }
}
