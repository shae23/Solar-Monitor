package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.Plant
import com.solarmonitor.data.PlantBattery

private val SheetColor = androidx.compose.ui.graphics.Color(0xFF1F2024)

/** Hidden menu for the battery size and reserve. Saved separately for each plant. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatterySheet(
    plantName: String,
    current: PlantBattery?,
    onDismiss: () -> Unit,
    onSave: (Double, Double) -> Unit
) {
    var size by remember { mutableStateOf(current?.let { numText(it.kwh) } ?: "") }
    var reserve by remember { mutableStateOf(current?.let { numText(it.reservePct) } ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = SheetColor,
        contentColor = Palette.Text
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .imePadding()
                .padding(start = 16.dp, end = 16.dp, bottom = 24.dp)
        ) {
            Text("Battery settings", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Palette.Text)
            Text("Saved for $plantName", fontSize = 13.sp, color = Palette.TextSecondary)
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = size,
                onValueChange = { size = it; error = null },
                label = { Text("Battery size (kWh)") },
                placeholder = { Text("e.g. 32") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = reserve,
                onValueChange = { reserve = it; error = null },
                label = { Text("Reserve (%)") },
                placeholder = { Text("e.g. 20") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "The run-out time counts down to this charge level.",
                fontSize = 12.sp, color = Palette.TextSecondary
            )
            error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, fontSize = 13.sp, color = Palette.ErrorText)
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(52.dp)) {
                    Text("Cancel", color = Palette.NavOn)
                }
                Button(
                    onClick = {
                        val kwh = size.trim().toDoubleOrNull()
                        val res = reserve.trim().toDoubleOrNull()
                        when {
                            kwh == null || kwh < 1.0 || kwh > 200.0 ->
                                error = "Enter the battery size in kWh, between 1 and 200."
                            res == null || res < 0.0 || res > 90.0 ->
                                error = "Enter the reserve as a percentage, between 0 and 90."
                            else -> onSave(kwh, res)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Palette.NavOn, contentColor = Palette.Background),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) { Text("Save") }
            }
        }
    }
}

/** The plant list, opened by the swap button beside the plant name. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlantSheet(
    plants: List<Plant>,
    selectedId: Long,
    onSelect: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = SheetColor,
        contentColor = Palette.Text
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(start = 16.dp, end = 16.dp, bottom = 24.dp)
        ) {
            Text("Switch plant", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Palette.Text)
            Text(
                "Plants on your SOLARMAN account. Tap one to show it here.",
                fontSize = 13.sp, color = Palette.TextSecondary
            )
            Spacer(Modifier.height(14.dp))
            if (plants.isEmpty()) {
                Text("No plants have been loaded yet. Pull a refresh on Home first.", color = Palette.TextSecondary, fontSize = 14.sp)
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                plants.forEach { p ->
                    val selected = p.id == selectedId
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(if (selected) Palette.NavPill else Color26)
                            .clickable { onSelect(p.id); onDismiss() }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Palette.IdleLine),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Home, contentDescription = null, tint = Palette.NavOn, modifier = Modifier.size(28.dp))
                        }
                        Column(Modifier.weight(1f)) {
                            Text(
                                p.name, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                                color = if (selected) Palette.NavOn else Palette.Text
                            )
                            if (p.address.isNotBlank()) {
                                Text(p.address, fontSize = 13.sp, color = Palette.TextSecondary)
                            }
                        }
                        if (selected) {
                            Icon(Icons.Rounded.Check, contentDescription = "Selected", tint = Palette.NavOn)
                        }
                    }
                }
            }
        }
    }
}

private val Color26 = androidx.compose.ui.graphics.Color(0xFF26282D)
