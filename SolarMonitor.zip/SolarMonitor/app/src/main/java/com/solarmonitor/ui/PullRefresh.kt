package com.solarmonitor.ui

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.pullToRefresh
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Android's own pull to refresh, with one fix. A pull that ends before the trigger distance
 * is sent back up and hidden the moment the finger lifts, so the spinner cannot get stuck.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PullRefresh(
    refreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val state = rememberPullToRefreshState()
    val scope = rememberCoroutineScope()
    // The app skips a refresh that comes too soon after the last one, and then nothing tells the
    // spinner to stop. So after a pull the spinner always shows for a moment on its own.
    var holding by remember { mutableStateOf(false) }
    val shown = refreshing || holding
    val shownNow by rememberUpdatedState(shown)

    Box(
        modifier
            .pullToRefresh(
                isRefreshing = shown,
                state = state,
                onRefresh = {
                    holding = true
                    onRefresh()
                    scope.launch {
                        delay(900)
                        holding = false
                    }
                }
            )
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    do {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                    } while (event.changes.any { it.pressed })
                    // Finger is up. If the pull fell short and nothing is refreshing, hide the spinner.
                    scope.launch {
                        if (!shownNow && state.distanceFraction < 1f) {
                            state.animateToHidden()
                        }
                    }
                }
            }
    ) {
        content()
        PullToRefreshDefaults.Indicator(
            state = state,
            isRefreshing = shown,
            modifier = Modifier.align(Alignment.TopCenter)
        )
    }
}
