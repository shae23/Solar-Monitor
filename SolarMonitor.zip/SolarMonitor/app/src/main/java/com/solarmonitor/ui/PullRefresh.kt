package com.solarmonitor.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.CircleShape
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Pull down from the top to refresh. A short pull springs back and disappears. A pull past the
 * trigger distance starts a refresh and shows the spinner until refreshing turns false.
 */
@Composable
fun PullRefresh(
    refreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val density = LocalDensity.current
    val trigger = with(density) { 72.dp.toPx() }
    val rest = with(density) { 56.dp.toPx() }
    val scope = rememberCoroutineScope()
    val pull = remember { Animatable(0f) }
    val refreshingNow by rememberUpdatedState(refreshing)
    val onRefreshNow by rememberUpdatedState(onRefresh)

    // While refreshing the spinner rests a little below the top. Afterwards it slides away.
    LaunchedEffect(refreshing) {
        pull.animateTo(if (refreshing) rest else 0f)
    }

    val connection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.UserInput) return Offset.Zero
                if (pull.value > 0f && available.y < 0f && !refreshingNow) {
                    val next = (pull.value + available.y).coerceAtLeast(0f)
                    val used = next - pull.value
                    scope.launch { pull.snapTo(next) }
                    return Offset(0f, used)
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (source != NestedScrollSource.UserInput) return Offset.Zero
                if (available.y > 0f && !refreshingNow) {
                    val next = (pull.value + available.y * 0.5f).coerceAtMost(trigger * 1.6f)
                    scope.launch { pull.snapTo(next) }
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Velocity): Velocity {
                if (!refreshingNow && pull.value > 0f) {
                    if (pull.value >= trigger) {
                        onRefreshNow()
                        pull.animateTo(rest)
                    } else {
                        pull.animateTo(0f)
                    }
                }
                return Velocity.Zero
            }
        }
    }

    Box(modifier.nestedScroll(connection)) {
        content()
        val shown = pull.value
        if (shown > 1f) {
            val ready = (shown / trigger).coerceIn(0f, 1f)
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .offset { IntOffset(0, (shown - with(density) { 40.dp.toPx() }).roundToInt()) }
                    .graphicsLayer { alpha = ready }
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Palette.NavPill),
                contentAlignment = Alignment.Center
            ) {
                if (refreshing) {
                    CircularProgressIndicator(Modifier.size(22.dp), color = Palette.NavOn, strokeWidth = 2.dp)
                } else {
                    CircularProgressIndicator(
                        progress = { ready },
                        modifier = Modifier.size(22.dp),
                        color = Palette.NavOn,
                        strokeWidth = 2.dp
                    )
                }
            }
        }
    }
}
