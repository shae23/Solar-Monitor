package com.solarmonitor.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.List
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.UiState
import com.solarmonitor.data.InverterItem
import com.solarmonitor.data.InverterGroups
import com.solarmonitor.data.LoggerGroups
import com.solarmonitor.data.groupReadings
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Good = Color(0xFF6EE7A8)
private val SheetColor = Color(0xFF1F2024)

private const val LIST = "list"
private const val INVERTER = "inverter"
private const val LOGGER = "logger"
private const val INVERTER_INFO = "inverter-info"
private const val LOGGER_INFO = "logger-info"

private fun parentOf(view: String): String = when (view) {
    INVERTER_INFO -> INVERTER
    LOGGER_INFO -> LOGGER
    else -> LIST
}

@Composable
fun DeviceScreen(state: UiState, onLoad: () -> Unit) {
    val inv = state.inverter
    var view by rememberSaveable { mutableStateOf(LIST) }
    var health by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = view != LIST) { view = parentOf(view) }

    LaunchedEffect(state.plantId) {
        if (state.plantId != 0L && !inv.loadedOnce && !inv.loading) onLoad()
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        when (view) {
            INVERTER -> InverterPage(
                state, onBack = { view = LIST }, onHealth = { health = INVERTER }, onMore = { view = INVERTER_INFO }
            )
            LOGGER -> LoggerPage(
                state, onBack = { view = LIST }, onHealth = { health = LOGGER },
                onMore = { view = LOGGER_INFO }, onInverter = { view = INVERTER }
            )
            INVERTER_INFO -> InfoPage(
                title = "Inverter ${inv.deviceSn}",
                groups = remember(inv.items) { groupReadings(inv.items, InverterGroups) },
                note = null,
                onBack = { view = INVERTER }
            )
            LOGGER_INFO -> {
                val groups = remember(inv.loggerItems, inv.loggerSn) {
                    val g = groupReadings(inv.loggerItems, LoggerGroups)
                    if (g.isNotEmpty()) g else if (inv.loggerSn.isBlank()) emptyList() else listOf(
                        "Basic Information" to listOf(InverterItem("sn", "Embedded Device SN", inv.loggerSn, "", ""))
                    )
                }
                InfoPage(
                    title = "Logger ${inv.loggerSn}",
                    groups = groups,
                    note = if (inv.loggerItems.isEmpty()) (inv.loggerError ?: "SOLARMAN did not send more logger details.") else null,
                    onBack = { view = LOGGER }
                )
            }
            else -> ListPage(state, onRefresh = onLoad, onInverter = { view = INVERTER }, onLogger = { view = LOGGER })
        }
    }

    val h = health
    if (h != null) HealthSheet(h, state, onDismiss = { health = null })
}

// ---------------------------------------------------------------- list

@Composable
private fun ListPage(state: UiState, onRefresh: () -> Unit, onInverter: () -> Unit, onLogger: () -> Unit) {
    val inv = state.inverter
    var openInv by rememberSaveable { mutableStateOf(true) }
    var openLog by rememberSaveable { mutableStateOf(true) }
    var openMore by rememberSaveable { mutableStateOf(false) }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("Devices", color = Palette.Text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        IconButton(onClick = onRefresh, enabled = !inv.loading && state.plantId != 0L) {
            if (inv.loading) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Palette.NavOn, strokeWidth = 2.dp)
            } else {
                Icon(Icons.Rounded.Refresh, contentDescription = "Refresh", tint = Palette.NavOn)
            }
        }
    }
    Spacer(Modifier.height(8.dp))

    inv.error?.let { ErrorBox(it); Spacer(Modifier.height(12.dp)) }

    GroupCard("Inverter", openInv, onToggle = { openInv = !openInv }) {
        DeviceRow(isLogger = false, name = "Inverter", online = inv.inverterOnline, sn = inv.deviceSn, onClick = onInverter)
    }
    Spacer(Modifier.height(12.dp))
    GroupCard("Logger", openLog, onToggle = { openLog = !openLog }) {
        DeviceRow(isLogger = true, name = "Logger", online = inv.loggerOnline, sn = inv.loggerSn, onClick = onLogger)
    }
    Spacer(Modifier.height(10.dp))
    UpdatedLine(inv.updatedMs)
    Spacer(Modifier.height(18.dp))

    GroupCard("App details", openMore, onToggle = { openMore = !openMore }) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Line("Plant", state.plantName.ifBlank { "-" })
            Line("Plant ID", if (state.plantId == 0L) "-" else state.plantId.toString())
            Line("API calls today", "${state.callsToday} of about 540")
            Spacer(Modifier.height(8.dp))
            RawBlock("Inverter readings (raw)", inv.raw)
            Spacer(Modifier.height(12.dp))
            RawBlock("Logger readings (raw)", inv.loggerRaw)
            Spacer(Modifier.height(12.dp))
            RawBlock("Live data (raw)", state.rawLive)
            Spacer(Modifier.height(12.dp))
            RawBlock("Daily totals (raw)", state.rawDay)
            Spacer(Modifier.height(12.dp))
            RawBlock("Report, timed readings (first items)", state.report.rawFrame)
            Spacer(Modifier.height(12.dp))
            RawBlock("Report, period totals (first items)", state.report.rawPeriod)
            Spacer(Modifier.height(8.dp))
            Text(
                "If a number looks wrong, copy these and send them over so the field names can be fixed.",
                color = Palette.TextSecondary, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun GroupCard(title: String, open: Boolean, onToggle: () -> Unit, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.Card)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggle)
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(title, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Icon(
                if (open) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                contentDescription = if (open) "Collapse" else "Expand", tint = Palette.TextSecondary
            )
        }
        if (open) content()
    }
}

@Composable
private fun DeviceRow(isLogger: Boolean, name: String, online: Boolean?, sn: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)).background(Palette.RunCard),
            contentAlignment = Alignment.Center
        ) { DeviceArt(isLogger, Modifier.size(44.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(2.dp))
            StatusText(online)
            Text(if (sn.isBlank()) "SN: -" else "SN: $sn", color = Palette.TextSecondary, fontSize = 13.sp)
        }
        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Palette.TextSecondary)
    }
}

@Composable
private fun StatusText(online: Boolean?) {
    val (text, color) = when (online) {
        true -> "Online" to Good
        false -> "Offline" to Palette.ErrorText
        null -> "Status unknown" to Palette.TextSecondary
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, color = color, fontSize = 13.sp)
    }
}

@Composable
private fun DeviceArt(isLogger: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (!isLogger) {
            val w = size.width * 0.78f
            val h = size.height * 0.92f
            val x = (size.width - w) / 2f
            val y = (size.height - h) / 2f
            drawRoundRect(Palette.InverterBody, Offset(x, y), Size(w, h), CornerRadius(8.dp.toPx()))
            drawRoundRect(Palette.InverterEdge, Offset(x, y), Size(w, h), CornerRadius(8.dp.toPx()), style = androidx.compose.ui.graphics.drawscope.Stroke(1.5.dp.toPx()))
            drawRoundRect(Palette.InverterScreen, Offset(x + w * 0.16f, y + h * 0.14f), Size(w * 0.68f, h * 0.28f), CornerRadius(3.dp.toPx()))
            drawCircle(Palette.LedOn, 2.5.dp.toPx(), Offset(x + w * 0.3f, y + h * 0.62f))
            drawCircle(Palette.LedOff, 2.5.dp.toPx(), Offset(x + w * 0.5f, y + h * 0.62f))
            drawCircle(Palette.LedOff, 2.5.dp.toPx(), Offset(x + w * 0.7f, y + h * 0.62f))
        } else {
            val w = size.width * 0.5f
            val h = size.height * 0.8f
            val x = (size.width - w) / 2f
            val y = size.height * 0.16f
            drawRoundRect(Palette.InverterEdge, Offset(x + w * 0.38f, 0f), Size(w * 0.24f, y + 2.dp.toPx()), CornerRadius(2.dp.toPx()))
            drawRoundRect(Palette.InverterBody, Offset(x, y), Size(w, h), CornerRadius(6.dp.toPx()))
            drawRoundRect(Palette.InverterEdge, Offset(x, y), Size(w, h), CornerRadius(6.dp.toPx()), style = androidx.compose.ui.graphics.drawscope.Stroke(1.5.dp.toPx()))
            drawCircle(Palette.LedOn, 2.5.dp.toPx(), Offset(size.width / 2f, y + h * 0.5f))
        }
    }
}

// ---------------------------------------------------------------- inverter

@Composable
private fun TopBack(onBack: () -> Unit) {
    IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Palette.Text)
    }
}

@Composable
private fun Hero(title: String, sn: String, online: Boolean?, isLogger: Boolean, onHealth: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Palette.Text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(8.dp))
                Icon(
                    Icons.Rounded.Wifi, contentDescription = null, modifier = Modifier.size(20.dp),
                    tint = when (online) { true -> Good; false -> Palette.ErrorText; null -> Palette.TextSecondary }
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(if (sn.isBlank()) "SN: -" else "SN: $sn", color = Palette.TextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(Palette.NavPill)
                    .clickable(onClick = onHealth)
                    .padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Health", color = Palette.NavOn, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Palette.NavOn, modifier = Modifier.size(18.dp))
            }
        }
        DeviceArt(isLogger, Modifier.size(96.dp))
    }
}

private fun find(items: List<InverterItem>, vararg names: String): InverterItem? {
    for (n in names) {
        val hit = items.firstOrNull { it.name.equals(n, ignoreCase = true) }
        if (hit != null) return hit
    }
    return null
}

private fun shown(item: InverterItem?): String? {
    if (item == null || item.value.isBlank()) return null
    return if (item.unit.isBlank()) item.value else "${item.value} ${item.unit}"
}

@Composable
private fun InverterPage(state: UiState, onBack: () -> Unit, onHealth: () -> Unit, onMore: () -> Unit) {
    val inv = state.inverter
    var cursor by remember { mutableStateOf<Float?>(null) }
    val daily = find(inv.items, "Daily Production (Active)", "Daily Production")
    val total = find(inv.items, "Cumulative Production (Active)", "Total Production")
    val lastHour = inv.points.lastOrNull()?.hour ?: 12f
    val at = cursor ?: lastHour
    val atPoint = nearestPoint(inv.points, at)

    TopBack(onBack)
    Hero("Inverter", inv.deviceSn, inv.inverterOnline, false, onHealth)
    Spacer(Modifier.height(12.dp))

    Card {
        Row(Modifier.fillMaxWidth().padding(16.dp)) {
            StatBox("Daily Production", daily, Modifier.weight(1f))
            StatBox("Total Production", total, Modifier.weight(1f))
        }
    }
    Spacer(Modifier.height(12.dp))

    Card {
        Column(Modifier.padding(16.dp)) {
            Text(
                "Power: ${if (atPoint == null) "-" else "${Math.round(atPoint.solarW)} W"}",
                color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium
            )
            Spacer(Modifier.height(6.dp))
            if (inv.points.isEmpty()) {
                Text(
                    if (inv.loading) "Loading today's power..." else "No readings for today yet.",
                    color = Palette.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(vertical = 40.dp).fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            } else {
                DevicePowerChart(
                    points = inv.points, cursorHour = at, onCursor = { cursor = it },
                    modifier = Modifier.fillMaxWidth().height(200.dp)
                )
            }
        }
    }
    Spacer(Modifier.height(12.dp))

    Card { MoreRow(onMore) }
    Spacer(Modifier.height(10.dp))
    UpdatedLine(inv.updatedMs)
}

@Composable
private fun StatBox(label: String, item: InverterItem?, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(Palette.NavPill),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.WbSunny, contentDescription = null, tint = Palette.Solar, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(10.dp))
        Column {
            val v = item
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    if (v == null || v.value.isBlank()) "-" else v.value,
                    color = Palette.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold
                )
                if (v != null && v.unit.isNotBlank()) {
                    Spacer(Modifier.width(4.dp))
                    Text(v.unit, color = Palette.Text, fontSize = 13.sp, modifier = Modifier.padding(bottom = 2.dp))
                }
            }
            Text(label, color = Palette.TextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun MoreRow(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.AutoMirrored.Rounded.List, contentDescription = null, tint = Palette.NavOn)
        Spacer(Modifier.width(14.dp))
        Text("More device information", color = Palette.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Palette.TextSecondary)
    }
}

// ---------------------------------------------------------------- logger

@Composable
private fun LoggerPage(
    state: UiState, onBack: () -> Unit, onHealth: () -> Unit, onMore: () -> Unit, onInverter: () -> Unit
) {
    val inv = state.inverter
    TopBack(onBack)
    Hero("Logger", inv.loggerSn, inv.loggerOnline, true, onHealth)
    Spacer(Modifier.height(12.dp))
    Card {
        Column {
            Text(
                "Connected Devices", color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 4.dp)
            )
            DeviceRow(isLogger = false, name = "Inverter", online = inv.inverterOnline, sn = inv.deviceSn, onClick = onInverter)
        }
    }
    Spacer(Modifier.height(12.dp))
    Card { MoreRow(onMore) }
    Spacer(Modifier.height(10.dp))
    UpdatedLine(inv.updatedMs)
}

// ---------------------------------------------------------------- more device information

@Composable
private fun InfoPage(
    title: String,
    groups: List<Pair<String, List<InverterItem>>>,
    note: String?,
    onBack: () -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val open = remember { mutableStateMapOf<String, Boolean>() }
    val q = query.trim().lowercase()

    Row(verticalAlignment = Alignment.CenterVertically) {
        TopBack(onBack)
        Text(title, color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
    Spacer(Modifier.height(4.dp))
    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        placeholder = { Text("Search readings", color = Palette.TextSecondary) },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = Palette.TextSecondary) },
        singleLine = true,
        keyboardOptions = KeyboardOptions.Default,
        shape = RoundedCornerShape(50),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Palette.Text,
            unfocusedTextColor = Palette.Text,
            focusedBorderColor = Palette.NavOn,
            unfocusedBorderColor = Palette.IdleLine,
            cursorColor = Palette.NavOn,
            focusedContainerColor = Palette.Card,
            unfocusedContainerColor = Palette.Card
        ),
        modifier = Modifier.fillMaxWidth()
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        TextButton(onClick = { groups.forEach { open[it.first] = true } }) { Text("Expand all", color = Palette.NavOn) }
        TextButton(onClick = { groups.forEach { open[it.first] = false } }) { Text("Collapse all", color = Palette.NavOn) }
    }

    note?.let {
        Text(it, color = Palette.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp))
    }

    var any = false
    groups.forEachIndexed { index, (name, rows) ->
        val hits = if (q.isEmpty()) rows else rows.filter { (it.name + " " + (shown(it) ?: "")).lowercase().contains(q) }
        if (hits.isEmpty()) return@forEachIndexed
        any = true
        val isOpen = q.isNotEmpty() || (open[name] ?: (index < 2))
        GroupCard(name, isOpen, onToggle = { open[name] = !isOpen }) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                hits.forEach { Line(it.name, shown(it) ?: "-") }
                Spacer(Modifier.height(6.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
    }
    if (!any) {
        Text(
            if (groups.isEmpty()) "No readings yet. Go back and refresh." else "No readings match that.",
            color = Palette.TextSecondary, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(24.dp),
            textAlign = TextAlign.Center
        )
    }
}

// ---------------------------------------------------------------- health

private class HealthRow(val label: String, val value: String, val good: Boolean)

private fun healthRows(which: String, state: UiState): List<HealthRow> {
    val inv = state.inverter
    val rows = ArrayList<HealthRow>()
    if (which == INVERTER) {
        val online = inv.inverterOnline
        rows.add(HealthRow("Connection", when (online) { true -> "Online"; false -> "Offline"; null -> "Unknown" }, online == true))
        val a1 = find(inv.items, "Alarms 1")
        val a2 = find(inv.items, "Alarms 2")
        if (a1 != null || a2 != null) {
            val none = listOfNotNull(a1, a2).all { it.value.trim() == "0" }
            rows.add(HealthRow("Alarms", if (none) "None" else "Active", none))
        }
        val p1 = find(inv.items, "Protection 1")
        val p2 = find(inv.items, "Protection 2")
        if (p1 != null || p2 != null) {
            val none = listOfNotNull(p1, p2).all { it.value.trim() == "0" }
            rows.add(HealthRow("Protection trips", if (none) "None" else "Tripped", none))
        }
        shown(find(inv.items, "SOH"))?.let { rows.add(HealthRow("Battery health (SOH)", it, true)) }
        shown(find(inv.items, "Number of battery cycles"))?.let { rows.add(HealthRow("Battery cycles", it, false)) }
        shown(find(inv.items, "Battery temperature"))?.let { rows.add(HealthRow("Battery temperature", it, false)) }
        shown(find(inv.items, "Inverter radiator temperature"))?.let { rows.add(HealthRow("Inverter radiator", it, false)) }
        shown(find(inv.items, "Temperature- Transformer", "Temperature - Transformer"))?.let { rows.add(HealthRow("Transformer", it, false)) }
    } else {
        val online = inv.loggerOnline
        rows.add(HealthRow("Connection", when (online) { true -> "Online"; false -> "Offline"; null -> "Unknown" }, online == true))
        shown(find(inv.loggerItems, "Signal Strength"))?.let { rows.add(HealthRow("Signal strength", it, true)) }
        shown(find(inv.loggerItems, "Data Uploading Period"))?.let { rows.add(HealthRow("Upload period", it, false)) }
        shown(find(inv.loggerItems, "Router SSID"))?.let { rows.add(HealthRow("Router", it, false)) }
    }
    return rows
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HealthSheet(which: String, state: UiState, onDismiss: () -> Unit) {
    val rows = remember(which, state.inverter) { healthRows(which, state) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = SheetColor,
        contentColor = Palette.Text
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Text("Health", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Palette.Text)
            Text(
                if (which == INVERTER) "Read from the inverter. Nothing here changes it." else "Read from the data logger.",
                color = Palette.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
            )
            rows.forEach { r ->
                Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(r.label, color = Palette.TextSecondary, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Text(r.value, color = if (r.good) Good else Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Palette.NavOn, contentColor = Palette.Background)
            ) { Text("Close") }
        }
    }
}

// ---------------------------------------------------------------- shared bits

@Composable
private fun Card(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.Card),
        content = { content() }
    )
}

@Composable
private fun ErrorBox(text: String) {
    Text(
        text, color = Palette.ErrorText, fontSize = 13.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Palette.ErrorCard)
            .padding(12.dp)
    )
}

@Composable
private fun UpdatedLine(ms: Long) {
    if (ms == 0L) return
    val fmt = remember { DateTimeFormatter.ofPattern("yyyy/MM/dd hh:mm a 'UTC'xxx", Locale.ENGLISH) }
    val text = remember(ms) { fmt.format(Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())) }
    Text("Updated $text", color = Palette.TextSecondary, fontSize = 12.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
}

@Composable
private fun Line(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = Palette.TextSecondary, fontSize = 14.sp, modifier = Modifier.weight(1f).padding(end = 12.dp))
        Text(value, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun RawBlock(title: String, text: String) {
    val clipboard = LocalClipboardManager.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        IconButton(onClick = { clipboard.setText(AnnotatedString(text)) }, enabled = text.isNotBlank()) {
            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy", tint = Palette.NavOn)
        }
    }
    Text(
        text.ifBlank { "Nothing yet." }.take(1500),
        color = Palette.TextSecondary,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Palette.RunCard)
            .padding(10.dp)
    )
}
