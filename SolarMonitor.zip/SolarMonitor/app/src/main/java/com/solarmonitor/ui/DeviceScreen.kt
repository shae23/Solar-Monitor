package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.UiState

@Composable
fun DeviceScreen(state: UiState) {
    Column(
        Modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Device", color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))

        InfoCard {
            Line("Plant", state.plantName.ifBlank { "-" })
            Line("Plant ID", if (state.plantId == 0L) "-" else state.plantId.toString())
            Line("API calls today", "${state.callsToday} of about 540")
        }
        Spacer(Modifier.height(16.dp))

        RawBlock("Live data (raw)", state.rawLive)
        Spacer(Modifier.height(16.dp))
        RawBlock("Daily totals (raw)", state.rawDay)
        Spacer(Modifier.height(16.dp))
        RawBlock("Report, timed readings (first items)", state.report.rawFrame)
        Spacer(Modifier.height(16.dp))
        RawBlock("Report, period totals (first items)", state.report.rawPeriod)
        Spacer(Modifier.height(8.dp))
        Text(
            "If a number on Home looks wrong, copy these and send them over so the field names can be fixed.",
            color = Palette.TextSecondary, fontSize = 12.sp
        )
    }
}

@Composable
private fun InfoCard(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.Card)
            .padding(16.dp),
        content = { content() }
    )
}

@Composable
private fun Line(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label, color = Palette.TextSecondary, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = Palette.Text, fontSize = 14.sp)
    }
}

@Composable
private fun RawBlock(title: String, text: String) {
    val clipboard = LocalClipboardManager.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        IconButton(onClick = { clipboard.setText(AnnotatedString(text)) }, enabled = text.isNotBlank()) {
            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy", tint = Palette.NavOn)
        }
    }
    Text(
        text.ifBlank { "Nothing yet. Open Home to load data." },
        color = Palette.TextSecondary,
        fontSize = 12.sp,
        fontFamily = FontFamily.Monospace,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Palette.Card)
            .padding(12.dp)
    )
}
