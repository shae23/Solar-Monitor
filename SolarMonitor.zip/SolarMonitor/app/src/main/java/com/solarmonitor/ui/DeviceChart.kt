package com.solarmonitor.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.IntraPoint
import kotlin.math.abs
import kotlin.math.max

private const val LEFT_DP = 34
private const val RIGHT_DP = 12

/** Today's solar power for the Inverter page. Numbers sit outside the plot. Drag or tap to move the cursor. */
@Composable
fun DevicePowerChart(
    points: List<IntraPoint>,
    cursorHour: Float,
    onCursor: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val measurer = rememberTextMeasurer()
    val grey = TextStyle(color = Palette.TextSecondary, fontSize = 11.sp)
    val pill = TextStyle(color = Palette.NavOn, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    val onCursorNow by rememberUpdatedState(onCursor)

    Canvas(
        modifier
            .pointerInput(Unit) {
                val left = LEFT_DP.dp.toPx()
                val right = RIGHT_DP.dp.toPx()
                detectTapGestures { o ->
                    val pw = size.width - left - right
                    onCursorNow(((o.x - left) / pw * 24f).coerceIn(0f, 24f))
                }
            }
            .pointerInput(Unit) {
                val left = LEFT_DP.dp.toPx()
                val right = RIGHT_DP.dp.toPx()
                detectDragGestures { change, _ ->
                    val pw = size.width - left - right
                    onCursorNow(((change.position.x - left) / pw * 24f).coerceIn(0f, 24f))
                }
            }
    ) {
        val l = LEFT_DP.dp.toPx()
        val r = RIGHT_DP.dp.toPx()
        val t = 30.dp.toPx()
        val b = 24.dp.toPx()
        val pw = size.width - l - r
        val ph = size.height - t - b

        var topKw = 0.0
        for (p in points) topKw = max(topKw, p.solarW / 1000.0)
        val (top, divs) = niceAxis(max(topKw, 0.5))
        fun xOf(h: Float): Float = l + h / 24f * pw
        fun yOf(kw: Double): Float = (t + ph * (1.0 - kw / top)).toFloat()

        val step = top / divs
        var v = 0.0
        while (v <= top + 0.0001) {
            val y = yOf(v)
            drawLine(Palette.IdleLine.copy(alpha = 0.6f), Offset(l, y), Offset(l + pw, y), strokeWidth = 1.dp.toPx())
            val txt = if (abs(v - Math.round(v)) < 0.001) String.format("%.0f", v) else String.format("%.1f", v)
            val w = measurer.measure(txt, grey).size.width
            drawText(measurer, txt, Offset(l - 6.dp.toPx() - w, y - 7.dp.toPx()), grey)
            v += step
        }
        val kw = measurer.measure("kW", grey).size.width
        drawText(measurer, "kW", Offset(l - 6.dp.toPx() - kw, t - 22.dp.toPx()), grey)

        var h = 0f
        while (h <= 24.001f) {
            val txt = hourLabel(h)
            val w = measurer.measure(txt, grey).size.width
            val x = (xOf(h) - w / 2f).coerceIn(0f, size.width - w)
            drawLine(Palette.IdleLine.copy(alpha = 0.6f), Offset(xOf(h), t), Offset(xOf(h), t + ph + 4.dp.toPx()), strokeWidth = 1.dp.toPx())
            drawText(measurer, txt, Offset(x, size.height - 18.dp.toPx()), grey)
            h += 6f
        }
        drawRect(Palette.IdleLine.copy(alpha = 0.8f), Offset(l, t), Size(pw, ph), style = Stroke(1.dp.toPx()))

        // Runs, so a gap in the readings stays a gap
        val runs = ArrayList<MutableList<IntraPoint>>()
        for (p in points) {
            val last = runs.lastOrNull()
            if (last == null || p.hour - last.last().hour > 0.34f) runs.add(mutableListOf(p)) else last.add(p)
        }
        clipRect(left = l, top = 0f, right = l + pw, bottom = size.height) {
            for (run in runs) {
                val pts = run.filterIndexed { i, p -> i == 0 || p.hour - run[i - 1].hour > 0.001f }
                if (pts.size < 2) continue
                val xs = FloatArray(pts.size) { xOf(pts[it].hour) }
                val ys = FloatArray(pts.size) { yOf(pts[it].solarW / 1000.0) }
                val line = monotone(xs, ys)
                val area = Path()
                area.addPath(line)
                area.lineTo(xs.last(), yOf(0.0))
                area.lineTo(xs.first(), yOf(0.0))
                area.close()
                drawPath(area, Brush.verticalGradient(listOf(Palette.Solar.copy(alpha = 0.30f), Color.Transparent), startY = t, endY = yOf(0.0)))
                drawPath(line, Palette.Solar, style = Stroke(1.75.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }

        val p = nearestPoint(points, cursorHour)
        val cx = xOf(cursorHour.coerceIn(0f, 24f))
        drawLine(Palette.Text.copy(alpha = 0.35f), Offset(cx, t - 4.dp.toPx()), Offset(cx, t + ph), strokeWidth = 1.dp.toPx())
        if (p != null && abs(p.hour - cursorHour) < 0.5f) {
            val y = yOf(p.solarW / 1000.0)
            drawCircle(Palette.Card, 5.dp.toPx(), Offset(xOf(p.hour), y))
            drawCircle(Palette.Solar, 3.dp.toPx(), Offset(xOf(p.hour), y))
        }
        val txt = hourLabel(cursorHour, true)
        val sz = measurer.measure(txt, pill).size
        val pillW = sz.width + 20.dp.toPx()
        val px = (cx - pillW / 2f).coerceIn(0f, size.width - pillW)
        drawRoundRect(Palette.NavPill, Offset(px, 0f), Size(pillW, 22.dp.toPx()), CornerRadius(11.dp.toPx(), 11.dp.toPx()))
        drawText(measurer, txt, Offset(px + 10.dp.toPx(), 11.dp.toPx() - sz.height / 2f), pill)
    }
}
