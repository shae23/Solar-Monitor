package com.solarmonitor.logic

import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/** Power below this many watts counts as "not flowing". */
const val ACTIVE_W = 20.0

enum class Source { SOLAR, GRID, BATTERY, GENERATOR }

data class Share(val source: Source, val watts: Double, val percent: Int)

sealed class BatteryOutlook {
    data class RunsOut(val at: Instant, val minutes: Long) : BatteryOutlook()
    data class FullAt(val at: Instant, val minutes: Long) : BatteryOutlook()
    object Idle : BatteryOutlook()
    object AtReserve : BatteryOutlook()
}

/**
 * batteryW is positive while the battery is discharging and negative while charging.
 * The estimate assumes the current power stays the same.
 */
fun batteryOutlook(
    now: Instant,
    socPct: Double,
    capacityKwh: Double,
    reservePct: Double,
    batteryW: Double
): BatteryOutlook {
    if (capacityKwh <= 0.0 || abs(batteryW) < ACTIVE_W) return BatteryOutlook.Idle
    if (batteryW > 0.0) {
        val usableKwh = (socPct - reservePct) / 100.0 * capacityKwh
        if (usableKwh <= 0.0) return BatteryOutlook.AtReserve
        val minutes = (usableKwh * 1000.0 / batteryW * 60.0).roundToLong()
        return BatteryOutlook.RunsOut(now.plusSeconds(minutes * 60L), minutes)
    }
    val neededKwh = (100.0 - socPct) / 100.0 * capacityKwh
    if (neededKwh <= 0.0) return BatteryOutlook.Idle
    val minutes = (neededKwh * 1000.0 / -batteryW * 60.0).roundToLong()
    return BatteryOutlook.FullAt(now.plusSeconds(minutes * 60L), minutes)
}

/** Share of the power feeding the house that comes from each source, in whole percent adding up to 100. */
fun shares(solarW: Double, gridW: Double, batteryW: Double, generatorW: Double): List<Share> {
    val active = listOf(
        Source.SOLAR to solarW,
        Source.GRID to gridW,
        Source.BATTERY to maxOf(batteryW, 0.0),
        Source.GENERATOR to generatorW
    ).filter { it.second >= ACTIVE_W }
    val total = active.sumOf { it.second }
    if (active.isEmpty() || total <= 0.0) return emptyList()

    val exact = active.map { it.second / total * 100.0 }
    val whole = exact.map { floor(it).toInt() }.toMutableList()
    var left = 100 - whole.sum()
    val order = exact.indices.sortedByDescending { exact[it] - whole[it] }
    for (i in order) {
        if (left <= 0) break
        whole[i] = whole[i] + 1
        left--
    }
    return active.mapIndexed { i, p -> Share(p.first, p.second, whole[i]) }
}

fun formatClock(at: Instant, now: Instant, zone: ZoneId): String {
    val t = at.atZone(zone)
    val time = DateTimeFormatter.ofPattern("h:mm a", Locale.US).format(t)
    return if (t.toLocalDate() == now.atZone(zone).toLocalDate()) {
        "Today $time"
    } else {
        DateTimeFormatter.ofPattern("EEE", Locale.US).format(t) + " " + time
    }
}

fun formatDuration(minutes: Long): String {
    val h = minutes / 60L
    val m = minutes % 60L
    return if (h == 0L) "$m min" else "$h h ${"%02d".format(m)} min"
}

fun formatPower(watts: Double): String {
    val a = abs(watts)
    return when {
        a < 1.0 -> "0 W"
        a < 1000.0 -> "${a.roundToInt()} W"
        else -> String.format(Locale.US, "%.2f kW", a / 1000.0)
    }
}

fun formatKwh(value: Double?): String = when {
    value == null -> "-"
    value == 0.0 -> "0"
    else -> String.format(Locale.US, "%.1f", value)
}
