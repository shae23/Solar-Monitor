package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.solarmonitor.MainViewModel
import kotlinx.coroutines.delay

private const val NEAR_LIMIT_CALLS = 450

private data class Tab(val label: String, val icon: ImageVector)

private val Tabs = listOf(
    Tab("Home", Icons.Rounded.Home),
    Tab("Device", Icons.Rounded.Memory),
    Tab("Report", Icons.Rounded.BarChart),
    Tab("Menu", Icons.Rounded.Menu)
)

@Composable
fun App(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current

    // Refresh while the app is on screen, then wait for the chosen interval.
    LaunchedEffect(state.signedIn, state.settings.refreshMinutes) {
        if (!state.signedIn) return@LaunchedEffect
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            while (true) {
                vm.refresh(false)
                // Near the free plan's daily limit, slow down so the app cannot be locked out.
                val nearLimit = vm.state.value.callsToday >= NEAR_LIMIT_CALLS
                val minutes = if (nearLimit) maxOf(state.settings.refreshMinutes, 5) else state.settings.refreshMinutes
                delay(minutes * 60_000L)
            }
        }
    }

    if (!state.signedIn) {
        Box(Modifier.fillMaxSize().background(Palette.Background).statusBarsPadding()) {
            SignInScreen(state, vm::signIn)
        }
        return
    }

    Scaffold(
        containerColor = Palette.Background,
        bottomBar = {
            NavigationBar(containerColor = Palette.NavBar) {
                Tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Palette.NavOn,
                            selectedTextColor = Palette.NavOn,
                            indicatorColor = Palette.NavPill,
                            unselectedIconColor = Palette.TextSecondary,
                            unselectedTextColor = Palette.TextSecondary
                        )
                    )
                }
            }
        }
    ) { inner ->
        Box(
            Modifier
                .fillMaxSize()
                .background(Palette.Background)
                .padding(inner)
        ) {
            when (tab) {
                0 -> PullRefresh(
                    refreshing = state.loading,
                    onRefresh = { vm.refresh(true) },
                    modifier = Modifier.fillMaxSize()
                ) {
                    HomeScreen(
                        state,
                        onRefresh = { vm.refresh(true) },
                        onSelectPlant = vm::selectPlant,
                        onSaveBattery = vm::saveBattery,
                        onOpenAlarm = { tab = 1 }
                    )
                }
                1 -> PullRefresh(
                    refreshing = state.inverter.loading,
                    onRefresh = vm::inverterLoad,
                    modifier = Modifier.fillMaxSize()
                ) {
                    DeviceScreen(state, onLoad = vm::inverterLoad)
                }
                2 -> PullRefresh(
                    refreshing = state.report.loading,
                    onRefresh = vm::reportRefresh,
                    modifier = Modifier.fillMaxSize()
                ) {
                    ReportScreen(
                        state,
                        onLoad = { vm.reportLoad(false) },
                        onTab = vm::reportTab,
                        onShift = vm::reportShift,
                        onRefresh = vm::reportRefresh,
                        onSaveBill = vm::saveBill
                    )
                }
                else -> MenuScreen(state, onSettings = vm::updateSettings, onSignOut = vm::signOut)
            }
        }
    }
}
