package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.PowerNow
import com.solarmonitor.data.Settings
import com.solarmonitor.logic.BatteryOutlook
import com.solarmonitor.logic.batteryOutlook
import com.solarmonitor.logic.formatClock
import com.solarmonitor.logic.formatDuration
import java.time.Instant
import java.time.ZoneId

private fun numText(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()

@Composable
fun RunOutCard(
    now: PowerNow,
    settings: Settings,
    hasData: Boolean,
    onSettings: (Settings) -> Unit,
    modifier: Modifier = Modifier
) {
    val instant = Instant.now()
    val zone = ZoneId.systemDefault()
    val outlook = batteryOutlook(instant, now.soc, settings.batteryKwh, settings.reservePct, now.batteryW)

    val accent: Color
    val title: String
    val big: String
    val sub: String
    when (outlook) {
        is BatteryOutlook.RunsOut -> {
            accent = Palette.Battery
            title = "Battery runs out"
            big = formatClock(outlook.at, instant, zone)
            sub = formatDuration(outlook.minutes) + " left at the current draw"
        }
        is BatteryOutlook.FullAt -> {
            accent = Palette.Solar
            title = "Battery full at"
            big = formatClock(outlook.at, instant, zone)
            sub = formatDuration(outlook.minutes) + " to go at the current charge rate"
        }
        BatteryOutlook.AtReserve -> {
            accent = Palette.Generator
            title = "Battery at reserve"
            big = "Reserve reached"
            sub = "Charge is at or below the ${numText(settings.reservePct)}% reserve"
        }
        BatteryOutlook.Idle -> {
            accent = Palette.TextSecondary
            title = "Battery idle"
            big = if (hasData) "Steady" else "Waiting"
            sub = if (hasData) "The battery is not charging or discharging" else "No data yet"
        }
    }

    var sizeText by remember { mutableStateOf(numText(settings.batteryKwh)) }
    var reserveText by remember { mutableStateOf(numText(settings.reservePct)) }

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Palette.RunCard)
            .padding(20.dp)
    ) {
        Text(title, color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(big, color = Palette.Text, fontSize = 32.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(2.dp))
        Text(sub, color = Palette.TextSecondary, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))

        val soc = (now.soc / 100.0).toFloat().coerceIn(0f, 1f)
        val reserve = (settings.reservePct / 100.0).toFloat().coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().height(18.dp), contentAlignment = Alignment.CenterStart) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Palette.IdleLine)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(soc)
                        .fillMaxHeight()
                        .background(accent)
                )
            }
            Box(Modifier.fillMaxWidth(reserve).height(18.dp), contentAlignment = Alignment.CenterEnd) {
                Box(Modifier.width(2.dp).height(18.dp).background(Palette.Text))
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Charge ${now.soc.toInt()}%", color = Palette.TextSecondary, fontSize = 12.sp)
            Text("Reserve ${numText(settings.reservePct)}%", color = Palette.TextSecondary, fontSize = 12.sp)
        }

        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = sizeText,
                onValueChange = { text ->
                    sizeText = text
                    val v = text.toDoubleOrNull()
                    if (v != null && v >= 1.0 && v <= 200.0) onSettings(settings.copy(batteryKwh = v))
                },
                label = { Text("Battery size (kWh)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = reserveText,
                onValueChange = { text ->
                    reserveText = text
                    val v = text.toDoubleOrNull()
                    if (v != null && v >= 0.0 && v <= 90.0) onSettings(settings.copy(reservePct = v))
                },
                label = { Text("Reserve (%)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f)
            )
        }
    }
}
