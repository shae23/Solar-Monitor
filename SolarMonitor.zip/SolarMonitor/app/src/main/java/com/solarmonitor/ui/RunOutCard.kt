package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.PlantBattery
import com.solarmonitor.data.PowerNow
import com.solarmonitor.logic.BatteryOutlook
import com.solarmonitor.logic.batteryOutlook
import com.solarmonitor.logic.formatClock
import com.solarmonitor.logic.formatDuration
import com.solarmonitor.logic.formatPower
import java.time.Instant
import java.time.ZoneId

internal fun numText(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()

/**
 * The run-out card. The battery size and reserve are not edited here. The small button in the
 * corner opens the Battery settings sheet, which keeps this card uncluttered.
 */
@Composable
fun RunOutCard(
    now: PowerNow,
    battery: PlantBattery?,
    hasData: Boolean,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val instant = Instant.now()
    val zone = ZoneId.systemDefault()

    val accent: Color
    val title: String
    val big: String
    val sub: String
    var stats: List<Pair<String, String>> = emptyList()
    if (battery == null) {
        accent = Palette.TextSecondary
        title = "Battery runs out"
        big = "Not set yet"
        sub = "Add your battery size and reserve to see this."
    } else {
        when (val outlook = batteryOutlook(instant, now.soc, battery.kwh, battery.reservePct, now.batteryW)) {
            is BatteryOutlook.RunsOut -> {
                accent = Palette.Battery
                title = "Battery runs out"
                big = formatClock(outlook.at, instant, zone)
                sub = ""
                stats = listOf(
                    "Lasts" to formatDuration(outlook.minutes),
                    "Drawing" to formatPower(now.batteryW)
                )
            }
            is BatteryOutlook.FullAt -> {
                accent = Palette.Solar
                title = "Battery full at"
                big = formatClock(outlook.at, instant, zone)
                sub = ""
                stats = listOf(
                    "Left to charge" to formatDuration(outlook.minutes),
                    "Charging at" to formatPower(now.batteryW)
                )
            }
            BatteryOutlook.AtReserve -> {
                accent = Palette.Generator
                title = "Battery at reserve"
                big = "Reserve reached"
                sub = "Charge is at or below the ${numText(battery.reservePct)}% reserve"
            }
            BatteryOutlook.Idle -> {
                accent = Palette.TextSecondary
                title = "Battery idle"
                big = if (hasData) "Steady" else "Waiting"
                sub = if (hasData) "The battery is not charging or discharging" else "No data yet"
            }
        }
    }

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Palette.RunCard)
            .padding(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            IconButton(
                onClick = onOpenSettings,
                colors = IconButtonDefaults.iconButtonColors(containerColor = Palette.InverterBody, contentColor = Palette.NavOn),
                modifier = Modifier.padding(top = 0.dp)
            ) {
                Icon(Icons.Rounded.Tune, contentDescription = "Battery settings")
            }
        }
        Text(big, color = Palette.Text, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
        if (sub.isNotEmpty()) Text(sub, color = Palette.TextSecondary, fontSize = 14.sp)
        if (stats.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                stats.forEach { (label, value) ->
                    Column {
                        Text(label, color = Palette.TextSecondary, fontSize = 12.sp)
                        Text(value, color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        if (battery == null) {
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onOpenSettings,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.NavPill, contentColor = Palette.NavOn)
            ) { Text("Set battery") }
        }

        Spacer(Modifier.height(14.dp))
        val soc = (now.soc / 100.0).toFloat().coerceIn(0f, 1f)
        val reserve = ((battery?.reservePct ?: 0.0) / 100.0).toFloat().coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().height(14.dp), contentAlignment = Alignment.CenterStart) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Palette.Background)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(soc)
                        .fillMaxHeight()
                        .background(if (battery == null) Palette.IdleIcon else accent)
                )
            }
            if (battery != null) {
                Box(Modifier.fillMaxWidth(reserve).height(14.dp), contentAlignment = Alignment.CenterEnd) {
                    Box(Modifier.width(2.dp).height(14.dp).background(Palette.Text))
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${now.soc.toInt()}% now", color = Palette.TextSecondary, fontSize = 12.sp)
            if (battery != null) {
                Text("${numText(battery.reservePct)}% reserve", color = Palette.TextSecondary, fontSize = 12.sp)
            }
        }
    }
}
