package com.solarmonitor.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.PlantBattery
import com.solarmonitor.data.PowerNow
import com.solarmonitor.logic.BatteryOutlook
import com.solarmonitor.logic.batteryOutlook
import com.solarmonitor.logic.formatDate
import com.solarmonitor.logic.formatDuration
import com.solarmonitor.logic.formatPower
import com.solarmonitor.logic.formatTime
import java.time.Instant
import java.time.ZoneId
import java.util.Locale
import kotlin.math.roundToInt

internal fun numText(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()

private class Stat(val label: String, val value: String, val sub: String, val weight: Float)

/**
 * The battery card. A tag says whether the battery is charging or discharging and at what rate.
 * Three figures sit under it: time remaining, energy left, and when it is full or depleted.
 * The battery size and reserve are edited in the Battery settings sheet, opened from the button.
 */
@Composable
fun RunOutCard(
    now: PowerNow,
    battery: PlantBattery?,
    hasData: Boolean,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val instant = Instant.now()
    val zone = ZoneId.systemDefault()

    var accent: Color = Palette.TextSecondary
    var tag = "Battery idle"
    var rate = ""
    var note = ""
    var stats: List<Stat> = emptyList()

    if (battery == null) {
        tag = "Battery not set up"
        note = "Add your battery size and reserve."
    } else {
        when (val outlook = batteryOutlook(instant, now.soc, battery.kwh, battery.reservePct, now.batteryW)) {
            is BatteryOutlook.RunsOut -> {
                accent = Palette.Battery
                tag = "Discharging"
                rate = formatPower(now.batteryW)
                val aboveCutoff = (now.soc - battery.cutoffPct) / 100.0 * battery.kwh
                val cutMinutes = (aboveCutoff * 1000.0 / now.batteryW * 60.0).toLong()
                val cutAt = instant.plusSeconds(cutMinutes * 60L)
                val hasCutoff = battery.cutoffPct > 0.0 && battery.cutoffPct < battery.reservePct && aboveCutoff > 0.0
                stats = listOf(
                    Stat("Remaining", formatDuration(outlook.minutes), "to reserve", 1f),
                    Stat("Reaches reserve at", formatTime(outlook.at, zone), formatDate(outlook.at, zone), 1.1f),
                    if (hasCutoff) Stat("Cuts off at", formatTime(cutAt, zone), formatDate(cutAt, zone), 1f)
                    else Stat("Left to discharge", kwhText((now.soc - battery.reservePct) / 100.0 * battery.kwh), "", 1f)
                )
            }
            is BatteryOutlook.FullAt -> {
                accent = Palette.Battery
                tag = "Charging"
                rate = formatPower(now.batteryW)
                val left = (100.0 - now.soc) / 100.0 * battery.kwh
                stats = listOf(
                    Stat("Remaining", formatDuration(outlook.minutes), "", 1f),
                    Stat("Left to charge", kwhText(left), "", 1f),
                    Stat("Fully charged at", formatTime(outlook.at, zone), formatDate(outlook.at, zone), 1.15f)
                )
            }
            BatteryOutlook.AtReserve -> {
                accent = Palette.Generator
                tag = "At reserve"
                note = "Charge is at or below the ${numText(battery.reservePct)}% reserve."
            }
            BatteryOutlook.Idle -> {
                note = if (hasData) "Not charging or discharging" else "No data yet"
            }
        }
    }

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.RunCard)
            .padding(start = 14.dp, end = 12.dp, top = 12.dp, bottom = 14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(
                Modifier
                    .height(30.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(if (stats.isNotEmpty() || accent != Palette.TextSecondary) accent.copy(alpha = 0.16f) else Palette.InverterBody)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                Spacer(Modifier.width(8.dp))
                Text(tag, color = accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                if (rate.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Text(rate, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.size(40.dp),
                colors = IconButtonDefaults.iconButtonColors(containerColor = Palette.InverterBody, contentColor = Palette.NavOn)
            ) {
                Icon(Icons.Rounded.Tune, contentDescription = "Battery settings", modifier = Modifier.size(20.dp))
            }
        }

        if (note.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(note, color = Palette.TextSecondary, fontSize = 14.sp)
        }

        if (stats.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                stats.forEachIndexed { i, s ->
                    Column(horizontalAlignment = if (i == stats.lastIndex) Alignment.End else Alignment.Start) {
                        Text(s.label, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
                        Text(s.value, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(if (s.sub.isEmpty()) " " else s.sub, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }

        if (battery == null) {
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onOpenSettings,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.NavPill, contentColor = Palette.NavOn)
            ) { Text("Set battery") }
        }

        Spacer(Modifier.height(10.dp))
        val soc = (now.soc / 100.0).toFloat().coerceIn(0f, 1f)
        val reserve = ((battery?.reservePct ?: 0.0) / 100.0).toFloat().coerceIn(0f, 1f)
        val cutoff = ((battery?.cutoffPct ?: 0.0) / 100.0).toFloat().coerceIn(0f, reserve)
        val hasBattery = battery != null
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.weight(1f).height(8.dp)) {
            val h = 4.dp.toPx()
            val top = (size.height - h) / 2f
            val w = size.width
            val track = Path().apply {
                addRoundRect(RoundRect(0f, top, w, top + h, CornerRadius(h / 2f, h / 2f)))
            }
            fun seg(a: Float, b: Float, c: Color, alpha: Float) {
                if (b > a) drawRect(c.copy(alpha = alpha), Offset(a * w, top), Size((b - a) * w, h))
            }
            clipPath(track) {
                drawRect(Palette.Background, Offset(0f, top), Size(w, h))
                if (hasBattery) {
                    seg(0f, cutoff, Palette.Consumption, 0.28f)
                    seg(cutoff, reserve, Palette.Generator, 0.28f)
                    seg(0f, minOf(soc, cutoff), Palette.Consumption, 1f)
                    seg(cutoff, minOf(soc, reserve), Palette.Generator, 1f)
                    seg(reserve, soc, Palette.Battery, 1f)
                } else {
                    seg(0f, soc, Palette.IdleIcon, 1f)
                }
            }
            if (hasBattery) {
                val tick = 2.dp.toPx()
                if (cutoff > 0f) drawRect(Palette.Consumption, Offset(cutoff * w - tick / 2f, 0f), Size(tick, size.height))
                drawRect(Palette.Generator, Offset(reserve * w - tick / 2f, 0f), Size(tick, size.height))
            }
        }
        if (battery != null) {
            Spacer(Modifier.width(12.dp))
            Text(kwhUnit(battery.kwh), color = Palette.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        }

        if (battery != null) {
            val cap = battery.kwh
            val stored = cap * now.soc / 100.0
            val resKwh = cap * battery.reservePct / 100.0
            val cutKwh = cap * battery.cutoffPct / 100.0
            val usableTotal = maxOf(cap - resKwh, 0.0)
            val usableNow = maxOf(stored - resKwh, 0.0)
            Spacer(Modifier.height(10.dp))
            CapLine("Usable", "${numText(100.0 - battery.reservePct)}%", usableNow, usableTotal, Palette.Battery)
            CapLine("Reserve", "${numText(battery.reservePct)}%", minOf(stored, resKwh), resKwh, Palette.Generator)
            CapLine("Cutoff", "${numText(battery.cutoffPct)}%", minOf(stored, cutKwh), cutKwh, Palette.Consumption)
        }
    }
}

private fun kwhUnit(v: Double): String = String.format(Locale.US, "%.1f kWh", v.coerceAtLeast(0.0))

/** One line under the capacity heading: name, share of the battery, how full that part is, and the kWh in it now. */
@Composable
private fun CapLine(label: String, pct: String, have: Double, total: Double, tone: Color) {
    val frac = if (total > 0.0) (have / total).toFloat().coerceIn(0f, 1f) else 0f
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = tone, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.width(62.dp))
        Text(pct, color = tone, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, textAlign = TextAlign.End, modifier = Modifier.width(40.dp))
        Box(
            Modifier
                .weight(1f)
                .padding(horizontal = 12.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Palette.Background)
        ) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(tone))
        }
        Text(kwhNumber(have), color = tone, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, textAlign = TextAlign.End, modifier = Modifier.width(38.dp))
        Text("/", color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Center, modifier = Modifier.width(12.dp))
        Text(kwhNumber(total), color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Start, modifier = Modifier.width(38.dp))
        Text("kWh", color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.End, modifier = Modifier.width(30.dp))
    }
}

private fun kwhNumber(v: Double): String = String.format(Locale.US, "%.1f", v.coerceAtLeast(0.0))

private fun kwhText(v: Double): String = String.format(Locale.US, "%.1f kWh", v.coerceAtLeast(0.0))
