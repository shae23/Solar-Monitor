package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.PlantBattery
import com.solarmonitor.data.PowerNow
import com.solarmonitor.logic.BatteryOutlook
import com.solarmonitor.logic.batteryOutlook
import com.solarmonitor.logic.formatDate
import com.solarmonitor.logic.formatDuration
import com.solarmonitor.logic.formatPower
import com.solarmonitor.logic.formatTime
import java.time.Instant
import java.time.ZoneId
import java.util.Locale
import kotlin.math.roundToInt

internal fun numText(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()

private class Stat(val label: String, val value: String, val sub: String, val weight: Float)

/**
 * The battery card. A tag says whether the battery is charging or discharging and at what rate.
 * Three figures sit under it: time remaining, energy left, and when it is full or depleted.
 * The battery size and reserve are edited in the Battery settings sheet, opened from the button.
 */
@Composable
fun RunOutCard(
    now: PowerNow,
    battery: PlantBattery?,
    hasData: Boolean,
    onOpenSettings: () -> Unit,
    fromGridW: Double = 0.0,
    modifier: Modifier = Modifier
) {
    val instant = Instant.now()
    val zone = ZoneId.systemDefault()

    var accent: Color = Palette.TextSecondary
    var tag = "Battery idle"
    var rate = ""
    var note = ""
    var stats: List<Stat> = emptyList()

    if (battery == null) {
        tag = "Battery not set up"
        note = "Add your battery size and reserve."
    } else {
        when (val outlook = batteryOutlook(instant, now.soc, battery.kwh, battery.reservePct, now.batteryW)) {
            is BatteryOutlook.RunsOut -> {
                accent = Palette.Battery
                tag = "Discharging"
                rate = formatPower(now.batteryW)
                val left = (now.soc - battery.reservePct) / 100.0 * battery.kwh
                stats = listOf(
                    Stat("Remaining", formatDuration(outlook.minutes), "", 1f),
                    Stat("Left to discharge", kwhText(left), "", 1f),
                    Stat("Reaches reserve at", formatTime(outlook.at, zone), formatDate(outlook.at, zone), 1.15f)
                )
            }
            is BatteryOutlook.FullAt -> {
                accent = Palette.Battery
                tag = "Charging"
                rate = formatPower(now.batteryW)
                val left = (100.0 - now.soc) / 100.0 * battery.kwh
                stats = listOf(
                    Stat("Remaining", formatDuration(outlook.minutes), "", 1f),
                    Stat("Left to charge", kwhText(left), "", 1f),
                    Stat("Fully charged at", formatTime(outlook.at, zone), formatDate(outlook.at, zone), 1.15f)
                )
            }
            BatteryOutlook.AtReserve -> {
                accent = Palette.Generator
                tag = "At reserve"
                note = "Charge is at or below the ${numText(battery.reservePct)}% reserve."
            }
            BatteryOutlook.Idle -> {
                note = if (hasData) "Not charging or discharging" else "No data yet"
            }
        }
    }

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.RunCard)
            .padding(start = 14.dp, end = 12.dp, top = 12.dp, bottom = 14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(
                Modifier
                    .height(30.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(if (stats.isNotEmpty() || accent != Palette.TextSecondary) accent.copy(alpha = 0.16f) else Palette.InverterBody)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                Spacer(Modifier.width(8.dp))
                Text(tag, color = accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                if (rate.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Text(rate, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.size(40.dp),
                colors = IconButtonDefaults.iconButtonColors(containerColor = Palette.InverterBody, contentColor = Palette.NavOn)
            ) {
                Icon(Icons.Rounded.Tune, contentDescription = "Battery settings", modifier = Modifier.size(20.dp))
            }
        }

        if (fromGridW >= 20.0 && now.batteryW <= -20.0) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Palette.Grid))
                Spacer(Modifier.width(8.dp))
                Text("${formatPower(fromGridW)} of this is from the grid", color = Palette.Grid, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
        }

        if (note.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(note, color = Palette.TextSecondary, fontSize = 14.sp)
        }

        if (stats.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                stats.forEach { s ->
                    Column(Modifier.weight(s.weight)) {
                        Text(s.label, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
                        Text(s.value, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(if (s.sub.isEmpty()) " " else s.sub, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }

        if (battery == null) {
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onOpenSettings,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.NavPill, contentColor = Palette.NavOn)
            ) { Text("Set battery") }
        }

        Spacer(Modifier.height(10.dp))
        val soc = (now.soc / 100.0).toFloat().coerceIn(0f, 1f)
        val reserve = ((battery?.reservePct ?: 0.0) / 100.0).toFloat().coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().height(8.dp), contentAlignment = Alignment.CenterStart) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Palette.Background)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(soc)
                        .fillMaxHeight()
                        .background(if (battery == null) Palette.IdleIcon else Palette.Battery)
                )
            }
            if (battery != null) {
                Box(Modifier.fillMaxWidth(reserve).height(8.dp), contentAlignment = Alignment.CenterEnd) {
                    Box(Modifier.width(2.dp).height(8.dp).background(Palette.Text))
                }
            }
        }

        if (battery != null) {
            val stored = battery.kwh * now.soc / 100.0
            val reserveKwh = battery.kwh * battery.reservePct / 100.0
            val usable = maxOf(stored - reserveKwh, 0.0)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CapColumn("Reserve", kwhNumber(reserveKwh), "${numText(battery.reservePct)}% minimum", Alignment.Start, Modifier.weight(1f))
                CapColumn("Stored", kwhNumber(stored), "${now.soc.roundToInt()}% charged", Alignment.CenterHorizontally, Modifier.weight(1f))
                CapColumn("Battery size", kwhNumber(battery.kwh), kwhNumber(usable) + " usable", Alignment.End, Modifier.weight(1f))
            }
        }
    }
}

private fun kwhNumber(v: Double): String = String.format(Locale.US, "%.1f", v.coerceAtLeast(0.0))

@Composable
private fun CapColumn(label: String, value: String, sub: String, align: Alignment.Horizontal, modifier: Modifier) {
    Column(modifier, horizontalAlignment = align) {
        Text(label, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Spacer(Modifier.width(3.dp))
            Text("kWh", color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(bottom = 1.dp))
        }
        Text(sub, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
    }
}

private fun kwhText(v: Double): String = String.format(Locale.US, "%.1f kWh", v.coerceAtLeast(0.0))
