package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.PlantBattery
import com.solarmonitor.data.PowerNow
import com.solarmonitor.logic.ACTIVE_W
import com.solarmonitor.logic.formatPower
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

internal fun numText(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()

private const val EPS = 0.005

/**
 * The battery card. The top line says what the battery is doing and at what rate, and turns into a
 * warning once the reserve or the cutoff is being used. Below it is one big countdown, then a bar
 * with live kWh inside the cutoff, reserve and usable zones. The battery size, reserve and cutoff are
 * edited in the Battery settings sheet, opened from the button.
 */
@Composable
fun RunOutCard(
    now: PowerNow,
    battery: PlantBattery?,
    hasData: Boolean,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val instant = Instant.now()
    val zone = ZoneId.systemDefault()

    var accent: Color = Palette.TextSecondary
    var tint: Color = Color.Transparent
    var tag = "Battery idle"
    var warn = false
    var rate = ""
    var heroWord: String? = null
    var minutes: Long? = null
    var whenText = ""
    var note = ""
    var noteColor: Color = Palette.TextSecondary
    var charging = false

    val cap = battery?.kwh ?: 0.0
    val stored = cap * now.soc / 100.0
    val resK = cap * (battery?.reservePct ?: 0.0) / 100.0
    val cutK = cap * minOf(battery?.cutoffPct ?: 0.0, battery?.reservePct ?: 0.0) / 100.0

    if (battery == null) {
        tag = "Battery not set up"
        note = "Add your battery size and reserve."
    } else {
        val kw = abs(now.batteryW) / 1000.0
        val active = cap > 0.0 && abs(now.batteryW) >= ACTIVE_W
        if (active && now.batteryW > 0.0) {
            rate = formatPower(now.batteryW)
            val useNow = stored - resK
            when {
                useNow > EPS -> {
                    accent = Palette.Battery; tint = Palette.Battery.copy(alpha = 0.15f)
                    tag = "Discharging"
                    minutes = (useNow / kw * 60.0).roundToLong(); whenText = "until reserve"
                }
                cutK > EPS && stored - cutK > EPS -> {
                    accent = Palette.Generator; tint = Palette.Generator.copy(alpha = 0.17f); warn = true
                    tag = "Discharging reserve"
                    minutes = ((stored - cutK) / kw * 60.0).roundToLong(); whenText = "until cutoff"
                }
                stored > EPS -> {
                    val atCutoff = cutK > EPS
                    accent = if (atCutoff) Palette.Consumption else Palette.Generator
                    tint = accent.copy(alpha = 0.2f); warn = true
                    tag = if (atCutoff) "Discharging cutoff" else "Discharging reserve"
                    minutes = (stored / kw * 60.0).roundToLong(); whenText = "until empty"
                }
                else -> {
                    accent = Palette.Consumption; tint = Palette.Consumption.copy(alpha = 0.2f); warn = true
                    tag = "Discharging cutoff"
                    heroWord = "Empty"; whenText = "Battery is depleted"
                }
            }
        } else if (active) {
            charging = true
            accent = Palette.Battery; tint = Palette.Battery.copy(alpha = 0.15f)
            tag = "Charging"; rate = formatPower(now.batteryW)
            val needed = cap - stored
            if (needed <= EPS) {
                heroWord = "Full"; whenText = "Battery is fully charged"
            } else {
                minutes = (needed / kw * 60.0).roundToLong(); whenText = "until full"
            }
        } else if (!hasData) {
            note = "No data yet"
        } else {
            val onGrid = now.gridW >= ACTIVE_W
            val atReserve = stored <= resK + EPS
            if (onGrid && atReserve) {
                accent = Palette.Generator; tint = Palette.Generator.copy(alpha = 0.17f)
                tag = "On grid"
                heroWord = "Switched to grid"; whenText = "battery held at reserve"
                note = "Grid has taken over. Reserve is being saved."; noteColor = Palette.Generator
            } else if (onGrid) {
                accent = Palette.Generator
                tag = "On grid"
                heroWord = "Battery idle"; whenText = "home is on grid"
            } else {
                heroWord = "Battery idle"; whenText = if (atReserve) "held at reserve" else "not charging or discharging"
            }
        }
    }

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.RunCard)
            .background(Brush.radialGradient(listOf(tint, Color.Transparent), center = Offset.Zero, radius = 900f))
            .padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(Modifier.height(40.dp), verticalAlignment = Alignment.CenterVertically) {
                if (warn) Icon(Icons.Rounded.Warning, contentDescription = "Warning", tint = accent, modifier = Modifier.size(18.dp))
                else Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                Spacer(Modifier.width(8.dp))
                Text(tag, color = accent, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                if (rate.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Text(rate, color = Palette.TextSecondary, fontSize = 14.sp, maxLines = 1)
                }
            }
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.size(40.dp),
                colors = IconButtonDefaults.iconButtonColors(containerColor = Palette.InverterBody, contentColor = Palette.NavOn)
            ) {
                Icon(Icons.Rounded.Tune, contentDescription = "Battery settings", modifier = Modifier.size(20.dp))
            }
        }

        if (heroWord != null || minutes != null) {
            Spacer(Modifier.height(6.dp))
            Text(
                heroText(heroWord, minutes, whenText, instant, zone),
                maxLines = 1,
                softWrap = false
            )
        }

        if (note.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(note, color = noteColor, fontSize = 13.sp)
        }

        if (battery == null) {
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onOpenSettings,
                colors = ButtonDefaults.buttonColors(containerColor = Palette.NavPill, contentColor = Palette.NavOn)
            ) { Text("Set battery") }
        } else if (cap > 0.0) {
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(kwhHead("Stored", stored, 2), color = Palette.TextSecondary, fontSize = 13.sp, maxLines = 1)
                Text(kwhHead("Capacity", cap, 1), color = Palette.TextSecondary, fontSize = 13.sp, maxLines = 1)
            }
            Spacer(Modifier.height(6.dp))
            ZoneBar(stored, cap, battery.reservePct, minOf(battery.cutoffPct, battery.reservePct), charging)
        }
    }
}

/** "07h 59m until reserve, at 10:10 PM", or one bold word with a short line after it. */
private fun heroText(word: String?, minutes: Long?, whenText: String, instant: Instant, zone: ZoneId) = buildAnnotatedString {
    val dim = Palette.TextSecondary
    if (word != null) {
        withStyle(SpanStyle(color = Palette.Text, fontSize = 26.sp, fontWeight = FontWeight.Medium)) { append(word) }
        withStyle(SpanStyle(color = dim, fontSize = 13.sp)) { append("  $whenText") }
        return@buildAnnotatedString
    }
    val m = minutes ?: 0L
    val at = instant.plusSeconds(m * 60L)
    val days = java.time.temporal.ChronoUnit.DAYS.between(instant.atZone(zone).toLocalDate(), at.atZone(zone).toLocalDate())
    val later = days >= 1L
    val dayWord = if (days == 1L) "tomorrow" else DateTimeFormatter.ofPattern("EEE", Locale.US).format(at.atZone(zone))
    val time = DateTimeFormatter.ofPattern("h:mm a", Locale.US).format(at.atZone(zone))
    val num = SpanStyle(color = Palette.Text, fontSize = 26.sp, fontWeight = FontWeight.Medium)
    val unit = SpanStyle(color = dim, fontSize = 13.sp)
    withStyle(num) { append("%02d".format(m / 60L)) }
    withStyle(unit) { append("h ") }
    withStyle(num) { append("%02d".format(m % 60L)) }
    withStyle(unit) { append("m   $whenText, ${if (later) "" else "at "}") }
    withStyle(SpanStyle(color = Palette.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium)) { append(time) }
    if (later) withStyle(SpanStyle(color = dim, fontSize = 10.sp)) { append(" $dayWord") }
}

private fun kwhHead(label: String, v: Double, decimals: Int) = buildAnnotatedString {
    append("$label ")
    withStyle(SpanStyle(color = Palette.Text, fontWeight = FontWeight.Medium)) {
        append(String.format(Locale.US, "%.${decimals}f", v.coerceAtLeast(0.0)))
    }
    append(" kWh")
}

/**
 * Cutoff, reserve and usable drawn side by side with the kWh inside each. Cutoff and reserve are drawn
 * wider than their true share so their numbers fit, and the charge marker is placed zone by zone.
 */
@Composable
private fun ZoneBar(stored: Double, cap: Double, resPct: Double, cutPct: Double, charging: Boolean) {
    val soc = (stored / cap * 100.0).coerceIn(0.0, 100.0)
    val wc = if (cutPct > 0.0) 21f else 0f
    val wr = if (resPct - cutPct > 0.0) 24f else 0f
    val wu = 100f - wc - wr

    fun fillOf(a: Double, b: Double): Float =
        if (b > a) ((soc.coerceAtMost(b) - a).coerceAtLeast(0.0) / (b - a)).toFloat() else 0f

    val kx = when {
        cutPct > 0.0 && soc <= cutPct -> (soc / cutPct).toFloat() * wc
        resPct > cutPct && soc <= resPct -> wc + ((soc - cutPct) / (resPct - cutPct)).toFloat() * wr
        else -> wc + wr + ((soc - resPct) / (100.0 - resPct)).toFloat() * wu
    } / 100f

    val live = when {
        cutPct > 0.0 && soc <= cutPct -> 0
        resPct > cutPct && soc <= resPct -> 1
        else -> 2
    }
    val twoDecimals = !charging || stored < cap - EPS

    val cutK = cap * cutPct / 100.0
    val resK = cap * resPct / 100.0
    val cutNow = minOf(stored, cutK)
    val resNow = (minOf(stored, resK) - cutK).coerceAtLeast(0.0)
    val useNow = (stored - resK).coerceAtLeast(0.0)

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val w = maxWidth
        Column {
            Box(Modifier.fillMaxWidth().height(36.dp)) {
                val segs = listOf(
                    Triple(0f, wc, Triple(Palette.Consumption, fillOf(0.0, cutPct), cutNow)),
                    Triple(wc, wr, Triple(Palette.Generator, fillOf(cutPct, resPct), resNow)),
                    Triple(wc + wr, wu, Triple(Palette.Battery, fillOf(resPct, 100.0), useNow))
                )
                segs.forEachIndexed { i, s ->
                    if (s.second > 0f) {
                        ZoneSeg(
                            Modifier.offset(x = w * (s.first / 100f) + 1.dp, y = 5.dp).width(w * (s.second / 100f) - 2.dp),
                            s.third.first, s.third.second, s.third.third,
                            if (i == live && twoDecimals) 2 else 1
                        )
                    }
                }
                Box(
                    Modifier
                        .offset(x = w * kx - 4.dp, y = (-2).dp)
                        .size(width = 8.dp, height = 40.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Palette.RunCard),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(width = 4.dp, height = 36.dp).clip(RoundedCornerShape(2.dp)).background(Palette.Text))
                }
            }
            Spacer(Modifier.height(5.dp))
            Box(Modifier.fillMaxWidth().height(36.dp)) {
                if (wc > 0f) ZoneLabel(Modifier.offset(x = w * 0f).width(w * (wc / 100f)), "Cutoff", numText(cutPct), Palette.Consumption)
                if (wr > 0f) ZoneLabel(Modifier.offset(x = w * (wc / 100f)).width(w * (wr / 100f)), "Reserve", numText(resPct - cutPct), Palette.Generator)
                ZoneLabel(Modifier.offset(x = w * ((wc + wr) / 100f)).width(w * (wu / 100f)), "Usable", numText(100.0 - resPct), Palette.Battery)
            }
        }
    }
}

@Composable
private fun ZoneSeg(modifier: Modifier, color: Color, fill: Float, kwh: Double, decimals: Int) {
    Box(
        modifier.height(26.dp).clip(RoundedCornerShape(8.dp)).background(color.copy(alpha = 0.28f)),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(fill.coerceIn(0f, 1f)).background(color))
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold)) {
                    append(String.format(Locale.US, "%.${decimals}f", kwh.coerceAtLeast(0.0)))
                }
                withStyle(SpanStyle(fontSize = 10.sp, fontWeight = FontWeight.Medium)) { append(" kWh") }
            },
            color = if (fill >= 0.5f) Palette.Background else color,
            maxLines = 1,
            softWrap = false
        )
    }
}

@Composable
private fun ZoneLabel(modifier: Modifier, name: String, pct: String, color: Color) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(name, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, textAlign = TextAlign.Center)
        Text("$pct%", color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}
