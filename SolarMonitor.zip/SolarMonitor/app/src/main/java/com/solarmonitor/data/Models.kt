package com.solarmonitor.data

import java.time.LocalDate

data class Credentials(
    val appId: String,
    val appSecret: String,
    val email: String,
    val passwordHash: String
)

data class Plant(val id: Long, val name: String, val address: String = "")

/** Battery size and reserve, saved separately for each plant. */
data class PlantBattery(val kwh: Double, val reservePct: Double, val cutoffPct: Double = 0.0)

data class PowerNow(
    val solarW: Double,
    val gridW: Double,
    val batteryW: Double,
    val generatorW: Double,
    val loadW: Double,
    val soc: Double,
    val updatedEpochSec: Long?
) {
    companion object {
        val Empty = PowerNow(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null)
    }
}

data class DayTotals(
    val productionKwh: Double?,
    val usedKwh: Double?,
    val exportKwh: Double?,
    val purchaseKwh: Double?,
    val chargeKwh: Double? = null,
    val dischargeKwh: Double? = null
)

data class Settings(
    val refreshMinutes: Int = 1,
    val showGenerator: Boolean = true,
    val invertBattery: Boolean = false,
    val billStartDay: Int = 19
)

/** Energy for one day (or one month on the Year tab), in kWh. */
data class DayPoint(
    val date: LocalDate,
    val prodKwh: Double,
    val useKwh: Double,
    val buyKwh: Double,
    val gridKwh: Double,
    val chargeKwh: Double,
    val dischargeKwh: Double
)

/** One timed reading from the day chart. Battery power is positive while discharging. */
data class IntraPoint(
    val hour: Float,
    val solarW: Double,
    val loadW: Double,
    val gridW: Double,
    val batteryW: Double,
    val soc: Double,
    val generatorW: Double = 0.0,
    val upsW: Double = 0.0,
    val pileW: Double = 0.0,
    val feedInW: Double = 0.0
)

/** Figures typed in from a utility bill. Kept as text so the boxes behave while typing. */
data class BillEntry(val units: String = "", val amount: String = "")

/** One named reading from the inverter, as SOLARMAN lists it. */
data class InverterItem(val key: String, val name: String, val value: String, val unit: String, val group: String)

/** Extra Home facts read from the inverter: any alarm or protection trip, and power drawn from the grid to charge the battery. */
data class HomeExtra(val alarm: Boolean = false, val gridChargeW: Double? = null)

/** One device in the plant: the inverter or the data logger. online is null when SOLARMAN does not say. */
data class DeviceRef(val sn: String, val type: String, val online: Boolean?) {
    val isLogger: Boolean get() = type.contains("COLLECTOR", true) || type.contains("LOGGER", true)
    val isInverter: Boolean get() = type.contains("INVERTER", true)
}
