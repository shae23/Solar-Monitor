package com.solarmonitor.data

data class Credentials(
    val appId: String,
    val appSecret: String,
    val email: String,
    val passwordHash: String
)

data class PowerNow(
    val solarW: Double,
    val gridW: Double,
    val batteryW: Double,
    val generatorW: Double,
    val loadW: Double,
    val soc: Double,
    val updatedEpochSec: Long?
) {
    companion object {
        val Empty = PowerNow(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null)
    }
}

data class DayTotals(
    val productionKwh: Double?,
    val usedKwh: Double?,
    val exportKwh: Double?,
    val purchaseKwh: Double?
)

data class Settings(
    val batteryKwh: Double = 16.0,
    val reservePct: Double = 20.0,
    val refreshMinutes: Int = 10,
    val showGenerator: Boolean = true,
    val invertBattery: Boolean = false
)
