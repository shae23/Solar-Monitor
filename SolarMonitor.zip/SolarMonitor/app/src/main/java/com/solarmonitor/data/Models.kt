package com.solarmonitor.data

data class Credentials(
    val appId: String,
    val appSecret: String,
    val email: String,
    val passwordHash: String
)

data class Plant(val id: Long, val name: String, val address: String = "")

/** Battery size and reserve, saved separately for each plant. */
data class PlantBattery(val kwh: Double, val reservePct: Double)

data class PowerNow(
    val solarW: Double,
    val gridW: Double,
    val batteryW: Double,
    val generatorW: Double,
    val loadW: Double,
    val soc: Double,
    val updatedEpochSec: Long?
) {
    companion object {
        val Empty = PowerNow(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, null)
    }
}

data class DayTotals(
    val productionKwh: Double?,
    val usedKwh: Double?,
    val exportKwh: Double?,
    val purchaseKwh: Double?
)

data class Settings(
    val refreshMinutes: Int = 5,
    val showGenerator: Boolean = true,
    val invertBattery: Boolean = false
)
