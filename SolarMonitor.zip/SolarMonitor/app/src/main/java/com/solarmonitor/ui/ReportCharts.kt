package com.solarmonitor.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.IntraPoint
import kotlin.math.abs
import kotlin.math.max

enum class Series(val label: String, val color: Color) {
    SOLAR("Solar", Palette.Solar),
    USED("Used", Palette.Consumption),
    SOC("Battery SOC", Palette.Battery),
    BATTERY("Battery power", Palette.Battery),
    GRID("Grid purchase", Palette.Grid)
}

val DefaultSeries: Set<Series> = setOf(Series.SOLAR, Series.USED, Series.SOC)

/** A round axis maximum and how many gaps to draw, for a largest value of v. */
fun niceAxis(v: Double): Pair<Double, Int> {
    val base = listOf(1 to 2, 2 to 2, 3 to 3, 4 to 4, 5 to 5, 6 to 3, 8 to 4, 10 to 5)
    var mag = 0.1
    while (mag < 1.0e7) {
        for ((b, d) in base) {
            if (b * mag >= v) return (b * mag) to d
        }
        mag *= 10.0
    }
    return v to 4
}

private fun axisText(v: Double): String =
    if (abs(v - Math.round(v)) < 0.001) String.format("%.0f", v) else String.format("%.1f", v)

fun nearestPoint(points: List<IntraPoint>, hour: Float): IntraPoint? =
    points.minByOrNull { abs(it.hour - hour) }

private fun TextMeasurer.width(text: String, style: TextStyle): Int = measure(text, style).size.width

/**
 * The day chart. Power series use the left axis in kW, battery charge uses the right axis in %.
 * Touch or drag along it to move the cursor.
 */
@Composable
fun IntradayChart(
    points: List<IntraPoint>,
    show: Set<Series>,
    cursorHour: Float?,
    onCursor: (Float?) -> Unit,
    modifier: Modifier = Modifier
) {
    val measurer = rememberTextMeasurer()
    val grey = TextStyle(color = Palette.TextSecondary, fontSize = 11.sp)
    val green = TextStyle(color = Palette.Battery, fontSize = 11.sp)

    Canvas(
        modifier
            .pointerInput(points) {
                val left = 36.dp.toPx()
                val right = 36.dp.toPx()
                fun toHour(x: Float): Float =
                    ((x - left) / (size.width - left - right) * 24f).coerceIn(0f, 24f)
                detectTapGestures(onTap = { onCursor(toHour(it.x)) })
            }
            .pointerInput(points) {
                val left = 36.dp.toPx()
                val right = 36.dp.toPx()
                fun toHour(x: Float): Float =
                    ((x - left) / (size.width - left - right) * 24f).coerceIn(0f, 24f)
                detectHorizontalDragGestures(
                    onDragStart = { onCursor(toHour(it.x)) },
                    onHorizontalDrag = { change, _ -> onCursor(toHour(change.position.x)) }
                )
            }
    ) {
        val l = 36.dp.toPx()
        val r = 36.dp.toPx()
        val t = 14.dp.toPx()
        val b = 24.dp.toPx()
        val pw = size.width - l - r
        val ph = size.height - t - b

        val powerSeries = show.filter { it == Series.SOLAR || it == Series.USED || it == Series.GRID || it == Series.BATTERY }
        var topKw = 0.0
        var bottomKw = 0.0
        for (p in points) {
            for (s in powerSeries) {
                val kw = value(p, s) / 1000.0
                topKw = max(topKw, kw)
                bottomKw = minOf(bottomKw, kw)
            }
        }
        val (top, divs) = niceAxis(max(topKw, 0.5))
        val negative = bottomKw < -0.01
        val low = if (negative) -niceAxis(-bottomKw).first else 0.0
        val span = top - low
        fun yKw(kw: Double): Float = (t + ph * (1.0 - (kw - low) / span)).toFloat()
        fun ySoc(pct: Double): Float = (t + ph * (1.0 - pct / 100.0)).toFloat()
        fun xOf(h: Float): Float = l + h / 24f * pw

        // Grid lines and left labels
        val step = top / divs
        var v = low
        while (v <= top + 0.0001) {
            val y = yKw(v)
            drawLine(Palette.IdleLine, Offset(l, y), Offset(l + pw, y), strokeWidth = 1.dp.toPx())
            val txt = axisText(v)
            drawText(measurer, txt, Offset(l - 6.dp.toPx() - measurer.width(txt, grey), y - 7.dp.toPx()), grey)
            v += step
        }
        drawText(measurer, "kW", Offset(2.dp.toPx(), 0f), grey)
        if (Series.SOC in show) {
            for (s in listOf(0, 25, 50, 75, 100)) {
                drawText(measurer, "$s", Offset(l + pw + 6.dp.toPx(), ySoc(s.toDouble()) - 7.dp.toPx()), green)
            }
        }
        for (h in listOf(0, 6, 12, 18, 24)) {
            val txt = String.format("%02d:00", h)
            val w = measurer.width(txt, grey)
            val x = (xOf(h.toFloat()) - w / 2f).coerceIn(0f, size.width - w)
            drawText(measurer, txt, Offset(x, size.height - 18.dp.toPx()), grey)
        }

        fun runs(): List<List<IntraPoint>> {
            val out = ArrayList<MutableList<IntraPoint>>()
            for (p in points) {
                val last = out.lastOrNull()
                if (last == null || p.hour - last.last().hour > 0.34f) out.add(mutableListOf(p)) else last.add(p)
            }
            return out
        }
        val allRuns = runs()

        fun drawSeries(s: Series, y: (IntraPoint) -> Float, fill: Boolean) {
            for (run in allRuns) {
                if (run.size < 2) continue
                val path = Path()
                run.forEachIndexed { i, p ->
                    if (i == 0) path.moveTo(xOf(p.hour), y(p)) else path.lineTo(xOf(p.hour), y(p))
                }
                if (fill) {
                    val area = Path()
                    area.addPath(path)
                    area.lineTo(xOf(run.last().hour), yKw(0.0))
                    area.lineTo(xOf(run.first().hour), yKw(0.0))
                    area.close()
                    drawPath(area, s.color.copy(alpha = 0.16f), style = Fill)
                }
                drawPath(path, s.color, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
        if (Series.GRID in show) drawSeries(Series.GRID, { yKw(it.gridW / 1000.0) }, false)
        if (Series.BATTERY in show) drawSeries(Series.BATTERY, { yKw(it.batteryW / 1000.0) }, false)
        if (Series.USED in show) drawSeries(Series.USED, { yKw(it.loadW / 1000.0) }, false)
        if (Series.SOLAR in show) drawSeries(Series.SOLAR, { yKw(it.solarW / 1000.0) }, true)
        if (Series.SOC in show) drawSeries(Series.SOC, { ySoc(it.soc) }, false)

        if (cursorHour != null) {
            val p = nearestPoint(points, cursorHour)
            if (p != null) {
                val x = xOf(p.hour)
                drawLine(Palette.Text.copy(alpha = 0.55f), Offset(x, t), Offset(x, t + ph), strokeWidth = 1.dp.toPx())
                for (s in show) {
                    val y = if (s == Series.SOC) ySoc(p.soc) else yKw(value(p, s) / 1000.0)
                    drawCircle(Palette.Card, 5.5.dp.toPx(), Offset(x, y))
                    drawCircle(s.color, 3.5.dp.toPx(), Offset(x, y))
                }
            }
        }
    }
}

/** The reading of one series at one point: watts, or percent for the charge. */
fun value(p: IntraPoint, s: Series): Double = when (s) {
    Series.SOLAR -> p.solarW
    Series.USED -> p.loadW
    Series.GRID -> p.gridW
    Series.BATTERY -> p.batteryW
    Series.SOC -> p.soc
}

class BarGroup(val slot: Int, val a: Double, val b: Double)

/** Paired bars (produced and used). slots is how many positions the axis has, for example the days in the month. */
@Composable
fun PairBarChart(
    slots: Int,
    bars: List<BarGroup>,
    labels: Map<Int, String>,
    colorA: Color,
    colorB: Color,
    modifier: Modifier = Modifier
) {
    val measurer = rememberTextMeasurer()
    val grey = TextStyle(color = Palette.TextSecondary, fontSize = 11.sp)
    Canvas(modifier) {
        val l = 34.dp.toPx()
        val t = 8.dp.toPx()
        val b = 22.dp.toPx()
        val pw = size.width - l - 4.dp.toPx()
        val ph = size.height - t - b
        val biggest = bars.maxOfOrNull { max(it.a, it.b) } ?: 0.0
        val (top, divs) = niceAxis(max(biggest, 1.0))
        for (i in 0..divs) {
            val value = top / divs * i
            val y = t + ph * (1f - (value / top).toFloat())
            drawLine(Palette.IdleLine, Offset(l, y), Offset(l + pw, y), strokeWidth = 1.dp.toPx())
            val txt = axisText(value)
            drawText(measurer, txt, Offset(l - 6.dp.toPx() - measurer.width(txt, grey), y - 7.dp.toPx()), grey)
        }
        val slotW = pw / slots
        for (g in bars) {
            val x0 = l + slotW * g.slot
            val bw = slotW * 0.38f
            val radius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            val ha = (g.a / top).toFloat() * ph
            val hb = (g.b / top).toFloat() * ph
            if (ha > 0f) drawRoundRect(colorA, Offset(x0 + slotW * 0.08f, t + ph - ha), Size(bw, ha), radius)
            if (hb > 0f) drawRoundRect(colorB, Offset(x0 + slotW * 0.08f + bw + 1.dp.toPx(), t + ph - hb), Size(bw, hb), radius)
        }
        for ((slot, txt) in labels) {
            val w = measurer.width(txt, grey)
            val x = (l + slotW * slot + slotW / 2f - w / 2f).coerceIn(0f, size.width - w)
            drawText(measurer, txt, Offset(x, size.height - 18.dp.toPx()), grey)
        }
    }
}
