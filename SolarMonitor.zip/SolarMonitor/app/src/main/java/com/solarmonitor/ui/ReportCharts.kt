package com.solarmonitor.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.IntraPoint
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

enum class Series(val label: String, val color: Color) {
    SOLAR("Solar", Palette.Solar),
    USED("Used", Palette.Consumption),
    SOC("Battery SOC", Palette.Battery),
    BATTERY("Battery power", Palette.Battery),
    GRID("Grid purchase", Palette.Grid)
}

val DefaultSeries: Set<Series> = setOf(Series.SOLAR, Series.USED, Series.SOC)

/** A round axis maximum and how many gaps to draw, for a largest value of v. */
fun niceAxis(v: Double): Pair<Double, Int> {
    val base = listOf(1 to 2, 2 to 2, 3 to 3, 4 to 4, 5 to 5, 6 to 3, 8 to 4, 10 to 5)
    var mag = 0.1
    while (mag < 1.0e7) {
        for ((b, d) in base) {
            if (b * mag >= v) return (b * mag) to d
        }
        mag *= 10.0
    }
    return v to 4
}

private fun axisText(v: Double): String =
    if (abs(v - Math.round(v)) < 0.001) String.format("%.0f", v) else String.format("%.1f", v)

fun nearestPoint(points: List<IntraPoint>, hour: Float): IntraPoint? =
    points.minByOrNull { abs(it.hour - hour) }

private fun TextMeasurer.width(text: String, style: TextStyle): Int = measure(text, style).size.width

/** Smooth curve through the points that never overshoots between them. */
private fun monotone(xs: FloatArray, ys: FloatArray): Path {
    val n = xs.size
    val path = Path()
    if (n == 0) return path
    path.moveTo(xs[0], ys[0])
    if (n == 1) return path
    val d = FloatArray(n - 1) { (ys[it + 1] - ys[it]) / (xs[it + 1] - xs[it]) }
    val m = FloatArray(n)
    m[0] = d[0]
    m[n - 1] = d[n - 2]
    for (i in 1 until n - 1) m[i] = if (d[i - 1] * d[i] <= 0f) 0f else (d[i - 1] + d[i]) / 2f
    for (i in 0 until n - 1) {
        if (d[i] == 0f) {
            m[i] = 0f
            m[i + 1] = 0f
        } else {
            val a = m[i] / d[i]
            val b = m[i + 1] / d[i]
            val q = a * a + b * b
            if (q > 9f) {
                val t = 3f / sqrt(q)
                m[i] = t * a * d[i]
                m[i + 1] = t * b * d[i]
            }
        }
    }
    for (i in 0 until n - 1) {
        val h = xs[i + 1] - xs[i]
        path.cubicTo(xs[i] + h / 3f, ys[i] + m[i] * h / 3f, xs[i + 1] - h / 3f, ys[i + 1] - m[i + 1] * h / 3f, xs[i + 1], ys[i + 1])
    }
    return path
}

/** Clock text for an hour of the day, like 6 AM or 10:15 AM. */
fun hourLabel(hour: Float, withMinutes: Boolean = false): String {
    val total = Math.round(hour * 60f).coerceIn(0, 24 * 60)
    val h = (total / 60) % 24
    val m = total % 60
    val h12 = if (h % 12 == 0) 12 else h % 12
    val ampm = if (h < 12) "AM" else "PM"
    return if (m == 0 && !withMinutes) "$h12 $ampm" else String.format("%d:%02d %s", h12, m, ampm)
}

private const val PLOT_LEFT_DP = 36
private const val PLOT_RIGHT_DP = 36

/**
 * The day chart. One chart, thin smooth lines. Power uses the left axis in kW and battery charge the
 * right axis in %. Pinch to zoom, drag to scroll, tap to move the cursor.
 */
@Composable
fun IntradayChart(
    points: List<IntraPoint>,
    show: Set<Series>,
    cursorHour: Float?,
    onCursor: (Float?) -> Unit,
    viewStart: Float,
    viewEnd: Float,
    onView: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val measurer = rememberTextMeasurer()
    val grey = TextStyle(color = Palette.TextSecondary, fontSize = 11.sp)
    val green = TextStyle(color = Palette.Battery, fontSize = 11.sp)
    val pillStyle = TextStyle(color = Palette.NavOn, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    val viewNow by rememberUpdatedState(viewStart to viewEnd)
    val onViewNow by rememberUpdatedState(onView)
    val onCursorNow by rememberUpdatedState(onCursor)

    Canvas(
        modifier
            .pointerInput(Unit) {
                val left = PLOT_LEFT_DP.dp.toPx()
                val right = PLOT_RIGHT_DP.dp.toPx()
                detectTapGestures(onTap = { o ->
                    val (vs, ve) = viewNow
                    val pw = size.width - left - right
                    onCursorNow((vs + (o.x - left) / pw * (ve - vs)).coerceIn(0f, 24f))
                })
            }
            .pointerInput(Unit) {
                val left = PLOT_LEFT_DP.dp.toPx()
                val right = PLOT_RIGHT_DP.dp.toPx()
                detectTransformGestures { centroid, pan, zoom, _ ->
                    val (vs, ve) = viewNow
                    val pw = size.width - left - right
                    val span = ve - vs
                    val frac = ((centroid.x - left) / pw).coerceIn(0f, 1f)
                    val anchor = vs + frac * span
                    val newSpan = (span / zoom).coerceIn(1f, 24f)
                    var ns = anchor - frac * newSpan
                    ns -= pan.x / pw * newSpan
                    ns = ns.coerceIn(0f, 24f - newSpan)
                    onViewNow(ns, ns + newSpan)
                }
            }
    ) {
        val l = PLOT_LEFT_DP.dp.toPx()
        val r = PLOT_RIGHT_DP.dp.toPx()
        val t = 30.dp.toPx()
        val b = 24.dp.toPx()
        val pw = size.width - l - r
        val ph = size.height - t - b
        val vs = viewStart
        val ve = viewEnd
        val span = ve - vs

        val powerSeries = show.filter { it == Series.SOLAR || it == Series.USED || it == Series.GRID || it == Series.BATTERY }
        var topKw = 0.0
        var bottomKw = 0.0
        for (p in points) {
            for (s in powerSeries) {
                val kw = value(p, s) / 1000.0
                topKw = max(topKw, kw)
                bottomKw = minOf(bottomKw, kw)
            }
        }
        val (top, divs) = niceAxis(max(topKw, 0.5))
        val negative = bottomKw < -0.01
        val low = if (negative) -niceAxis(-bottomKw).first else 0.0
        val range = top - low
        fun yKw(kw: Double): Float = (t + ph * (1.0 - (kw - low) / range)).toFloat()
        fun ySoc(pct: Double): Float = (t + ph * (1.0 - pct / 100.0)).toFloat()
        fun xOf(h: Float): Float = l + (h - vs) / span * pw

        // Quiet grid and left labels
        val step = top / divs
        var v = low
        while (v <= top + 0.0001) {
            val y = yKw(v)
            drawLine(Palette.IdleLine.copy(alpha = 0.6f), Offset(l, y), Offset(l + pw, y), strokeWidth = 1.dp.toPx())
            val txt = axisText(v)
            drawText(measurer, txt, Offset(l - 6.dp.toPx() - measurer.width(txt, grey), y - 7.dp.toPx()), grey)
            v += step
        }
        drawText(measurer, "kW", Offset(2.dp.toPx(), 4.dp.toPx()), grey)
        if (Series.SOC in show) {
            for (s in listOf(0, 25, 50, 75, 100)) {
                drawText(measurer, "$s", Offset(l + pw + 6.dp.toPx(), ySoc(s.toDouble()) - 7.dp.toPx()), green)
            }
        }

        // Time labels, spaced by how far in the chart is zoomed
        val tick = when {
            span > 14f -> 6f
            span > 7f -> 2f
            span > 3f -> 1f
            else -> 0.5f
        }
        var h = Math.ceil((vs / tick).toDouble()).toFloat() * tick
        while (h <= ve + 0.001f) {
            val txt = hourLabel(h)
            val w = measurer.width(txt, grey)
            val x = (xOf(h) - w / 2f).coerceIn(0f, size.width - w)
            drawText(measurer, txt, Offset(x, size.height - 18.dp.toPx()), grey)
            h += tick
        }

        // Only the points in view, in runs so gaps in the data stay gaps
        val visible = points.filter { it.hour >= vs - 0.5f && it.hour <= ve + 0.5f }
        val allRuns = ArrayList<MutableList<IntraPoint>>()
        for (p in visible) {
            val last = allRuns.lastOrNull()
            if (last == null || p.hour - last.last().hour > 0.34f) allRuns.add(mutableListOf(p)) else last.add(p)
        }

        fun drawSeries(s: Series, y: (IntraPoint) -> Float, fill: Boolean) {
            for (run in allRuns) {
                val pts = run.filterIndexed { i, p -> i == 0 || p.hour - run[i - 1].hour > 0.001f }
                if (pts.size < 2) continue
                val xs = FloatArray(pts.size) { xOf(pts[it].hour) }
                val ys = FloatArray(pts.size) { y(pts[it]) }
                val line = monotone(xs, ys)
                if (fill) {
                    val area = Path()
                    area.addPath(line)
                    area.lineTo(xs.last(), yKw(0.0))
                    area.lineTo(xs.first(), yKw(0.0))
                    area.close()
                    drawPath(
                        area,
                        Brush.verticalGradient(listOf(s.color.copy(alpha = 0.22f), Color.Transparent), startY = t, endY = yKw(0.0))
                    )
                }
                drawPath(line, s.color, style = Stroke(1.75.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
        clipRect(left = l, top = 0f, right = l + pw, bottom = size.height) {
            if (Series.GRID in show) drawSeries(Series.GRID, { yKw(it.gridW / 1000.0) }, false)
            if (Series.BATTERY in show) drawSeries(Series.BATTERY, { yKw(it.batteryW / 1000.0) }, false)
            if (Series.USED in show) drawSeries(Series.USED, { yKw(it.loadW / 1000.0) }, false)
            if (Series.SOLAR in show) drawSeries(Series.SOLAR, { yKw(it.solarW / 1000.0) }, true)
            if (Series.SOC in show) drawSeries(Series.SOC, { ySoc(it.soc) }, false)
        }

        if (cursorHour != null && cursorHour >= vs && cursorHour <= ve) {
            val p = nearestPoint(points, cursorHour)
            if (p != null) {
                val x = xOf(p.hour)
                drawLine(Palette.Text.copy(alpha = 0.3f), Offset(x, t - 4.dp.toPx()), Offset(x, t + ph), strokeWidth = 1.dp.toPx())
                for (s in show) {
                    val y = if (s == Series.SOC) ySoc(p.soc) else yKw(value(p, s) / 1000.0)
                    drawCircle(Palette.Card, 5.dp.toPx(), Offset(x, y))
                    drawCircle(s.color, 3.dp.toPx(), Offset(x, y))
                }
                val txt = hourLabel(p.hour, true)
                val size1 = measurer.measure(txt, pillStyle).size
                val pillW = size1.width + 20.dp.toPx()
                val px = (x - pillW / 2f).coerceIn(0f, size.width - pillW)
                drawRoundRect(Palette.NavPill, Offset(px, 0f), Size(pillW, 22.dp.toPx()), CornerRadius(11.dp.toPx(), 11.dp.toPx()))
                drawText(measurer, txt, Offset(px + 10.dp.toPx(), 11.dp.toPx() - size1.height / 2f), pillStyle)
            }
        }
    }
}

/** The whole day in miniature. The bright window is what the chart above shows. Drag it or tap to move it. */
@Composable
fun DayOverview(
    points: List<IntraPoint>,
    viewStart: Float,
    viewEnd: Float,
    onView: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val viewNow by rememberUpdatedState(viewStart to viewEnd)
    val onViewNow by rememberUpdatedState(onView)
    Canvas(
        modifier
            .pointerInput(Unit) {
                val left = PLOT_LEFT_DP.dp.toPx()
                val right = PLOT_RIGHT_DP.dp.toPx()
                detectTapGestures(onTap = { o ->
                    val (vs, ve) = viewNow
                    val pw = size.width - left - right
                    val span = ve - vs
                    val centre = ((o.x - left) / pw * 24f).coerceIn(0f, 24f)
                    val ns = (centre - span / 2f).coerceIn(0f, 24f - span)
                    onViewNow(ns, ns + span)
                })
            }
            .pointerInput(Unit) {
                val left = PLOT_LEFT_DP.dp.toPx()
                val right = PLOT_RIGHT_DP.dp.toPx()
                detectDragGestures { change, drag ->
                    change.consume()
                    val (vs, ve) = viewNow
                    val pw = size.width - left - right
                    val span = ve - vs
                    val ns = (vs + drag.x / pw * 24f).coerceIn(0f, 24f - span)
                    onViewNow(ns, ns + span)
                }
            }
    ) {
        val l = PLOT_LEFT_DP.dp.toPx()
        val pw = size.width - l - PLOT_RIGHT_DP.dp.toPx()
        val pad = 4.dp.toPx()
        val peak = max(points.maxOfOrNull { max(it.solarW, it.loadW) } ?: 1.0, 500.0)
        fun xOf(h: Float): Float = l + h / 24f * pw
        fun yOf(w: Double): Float = (pad + (size.height - 2 * pad) * (1.0 - w / peak)).toFloat()
        fun faint(color: Color, pick: (IntraPoint) -> Double) {
            val pts = points.filterIndexed { i, p -> i == 0 || p.hour - points[i - 1].hour > 0.001f }
            if (pts.size < 2) return
            val path = Path()
            pts.forEachIndexed { i, p ->
                if (i == 0) path.moveTo(xOf(p.hour), yOf(pick(p))) else path.lineTo(xOf(p.hour), yOf(pick(p)))
            }
            drawPath(path, color.copy(alpha = 0.55f), style = Stroke(1.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        faint(Palette.Solar) { it.solarW }
        faint(Palette.Consumption) { it.loadW }
        val x0 = xOf(viewStart)
        val x1 = xOf(viewEnd)
        drawRect(Palette.Background.copy(alpha = 0.6f), Offset(l, 0f), Size(x0 - l, size.height))
        drawRect(Palette.Background.copy(alpha = 0.6f), Offset(x1, 0f), Size(l + pw - x1, size.height))
        drawRoundRect(
            Palette.NavOn.copy(alpha = 0.06f), Offset(x0, 1.dp.toPx()), Size(x1 - x0, size.height - 2.dp.toPx()),
            CornerRadius(8.dp.toPx(), 8.dp.toPx())
        )
        drawRoundRect(
            Palette.NavOn.copy(alpha = 0.7f), Offset(x0, 1.dp.toPx()), Size(x1 - x0, size.height - 2.dp.toPx()),
            CornerRadius(8.dp.toPx(), 8.dp.toPx()), style = Stroke(1.5.dp.toPx())
        )
        for (x in listOf(x0, x1)) {
            drawRoundRect(
                Palette.NavOn, Offset(x - 2.5.dp.toPx(), size.height / 2f - 8.dp.toPx()), Size(5.dp.toPx(), 16.dp.toPx()),
                CornerRadius(2.5.dp.toPx(), 2.5.dp.toPx())
            )
        }
    }
}

/** The reading of one series at one point: watts, or percent for the charge. */
fun value(p: IntraPoint, s: Series): Double = when (s) {
    Series.SOLAR -> p.solarW
    Series.USED -> p.loadW
    Series.GRID -> p.gridW
    Series.BATTERY -> p.batteryW
    Series.SOC -> p.soc
}

class BarGroup(val slot: Int, val a: Double, val b: Double)

/** Paired bars (produced and used). slots is how many positions the axis has, for example the days in the month. */
@Composable
fun PairBarChart(
    slots: Int,
    bars: List<BarGroup>,
    labels: Map<Int, String>,
    colorA: Color,
    colorB: Color,
    modifier: Modifier = Modifier
) {
    val measurer = rememberTextMeasurer()
    val grey = TextStyle(color = Palette.TextSecondary, fontSize = 11.sp)
    Canvas(modifier) {
        val l = 34.dp.toPx()
        val t = 8.dp.toPx()
        val b = 22.dp.toPx()
        val pw = size.width - l - 4.dp.toPx()
        val ph = size.height - t - b
        val biggest = bars.maxOfOrNull { max(it.a, it.b) } ?: 0.0
        val (top, divs) = niceAxis(max(biggest, 1.0))
        for (i in 0..divs) {
            val value = top / divs * i
            val y = t + ph * (1f - (value / top).toFloat())
            drawLine(Palette.IdleLine, Offset(l, y), Offset(l + pw, y), strokeWidth = 1.dp.toPx())
            val txt = axisText(value)
            drawText(measurer, txt, Offset(l - 6.dp.toPx() - measurer.width(txt, grey), y - 7.dp.toPx()), grey)
        }
        val slotW = pw / slots
        for (g in bars) {
            val x0 = l + slotW * g.slot
            val bw = slotW * 0.38f
            val radius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            val ha = (g.a / top).toFloat() * ph
            val hb = (g.b / top).toFloat() * ph
            if (ha > 0f) drawRoundRect(colorA, Offset(x0 + slotW * 0.08f, t + ph - ha), Size(bw, ha), radius)
            if (hb > 0f) drawRoundRect(colorB, Offset(x0 + slotW * 0.08f + bw + 1.dp.toPx(), t + ph - hb), Size(bw, hb), radius)
        }
        for ((slot, txt) in labels) {
            val w = measurer.width(txt, grey)
            val x = (l + slotW * slot + slotW / 2f - w / 2f).coerceIn(0f, size.width - w)
            drawText(measurer, txt, Offset(x, size.height - 18.dp.toPx()), grey)
        }
    }
}
