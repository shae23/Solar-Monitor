package com.solarmonitor.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.solarmonitor.logic.Source

object Palette {
    val Background = Color(0xFF0F1012)
    val Card = Color(0xFF1A1B1F)
    val RunCard = Color(0xFF212328)
    val Text = Color(0xFFECEDEF)
    val TextSecondary = Color(0xFFA0A4AD)
    val IdleLine = Color(0xFF34363C)
    val IdleIcon = Color(0xFF6E727B)
    val InverterBody = Color(0xFF2B2D33)
    val InverterEdge = Color(0xFF43464E)
    val InverterScreen = Color(0xFF16171A)
    val LedOff = Color(0xFF5A5D66)
    val LedOn = Color(0xFF6EE7A8)
    val NavBar = Color(0xFF15161A)
    val NavPill = Color(0xFF2B3150)
    val NavOn = Color(0xFFDCE1FF)
    val Solar = Color(0xFFF5B83D)
    val Grid = Color(0xFF6C8CFF)
    val Battery = Color(0xFF33C7E6)
    val Generator = Color(0xFFFF7A59)
    val ErrorCard = Color(0xFF3A1F1F)
    val ErrorText = Color(0xFFFFB4A8)
}

fun sourceColor(s: Source): Color = when (s) {
    Source.SOLAR -> Palette.Solar
    Source.GRID -> Palette.Grid
    Source.BATTERY -> Palette.Battery
    Source.GENERATOR -> Palette.Generator
}

private val Scheme = darkColorScheme(
    primary = Color(0xFFB8C4FF),
    onPrimary = Color(0xFF0F1012),
    secondaryContainer = Palette.NavPill,
    onSecondaryContainer = Palette.NavOn,
    background = Palette.Background,
    onBackground = Palette.Text,
    surface = Palette.Card,
    onSurface = Palette.Text,
    surfaceVariant = Palette.RunCard,
    onSurfaceVariant = Palette.TextSecondary,
    outline = Palette.IdleLine,
    error = Color(0xFFFF8A80)
)

@Composable
fun SolarTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
