package com.solarmonitor.logic

import com.solarmonitor.data.DayPoint
import com.solarmonitor.data.IntraPoint
import java.time.LocalDate
import kotlin.math.floor
import kotlin.math.max

/** Energy added up over a period, in kWh. */
data class Energy(
    val prod: Double,
    val use: Double,
    val buy: Double,
    val grid: Double,
    val charge: Double,
    val discharge: Double
) {
    /** Where the solar went. */
    val toGrid: Double get() = grid
    val toBattery: Double get() = charge
    val toLoad: Double get() = max(prod - charge - grid, 0.0)

    /** Where the house energy came from. */
    val fromGrid: Double get() = buy
    val fromBattery: Double get() = discharge
    val fromSolar: Double get() = max(use - buy - discharge, 0.0)

    companion object {
        val Zero = Energy(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    }
}

fun List<DayPoint>.total(): Energy = Energy(
    prod = sumOf { it.prodKwh },
    use = sumOf { it.useKwh },
    buy = sumOf { it.buyKwh },
    grid = sumOf { it.gridKwh },
    charge = sumOf { it.chargeKwh },
    discharge = sumOf { it.dischargeKwh }
)

/** Whole percentages that add up to 100 (largest remainder). All zero when the total is zero. */
fun percentSplit(values: List<Double>): List<Int> {
    val total = values.sumOf { max(it, 0.0) }
    if (total <= 0.0) return values.map { 0 }
    val exact = values.map { max(it, 0.0) / total * 100.0 }
    val whole = exact.map { floor(it).toInt() }.toMutableList()
    var left = 100 - whole.sum()
    for (i in exact.indices.sortedByDescending { exact[it] - whole[it] }) {
        if (left <= 0) break
        whole[i] = whole[i] + 1
        left--
    }
    return whole
}

/** First and last day of the billing cycle that contains the given date. */
fun billCycle(anchor: LocalDate, startDay: Int): Pair<LocalDate, LocalDate> {
    fun startIn(month: LocalDate): LocalDate = month.withDayOfMonth(minOf(startDay, month.lengthOfMonth()))
    val thisStart = startIn(anchor.withDayOfMonth(1))
    val start = if (anchor >= thisStart) thisStart else startIn(anchor.withDayOfMonth(1).minusMonths(1))
    val nextStart = startIn(start.withDayOfMonth(1).plusMonths(1))
    return start to nextStart.minusDays(1)
}

/** Energy in kWh worked out from timed power readings. Gaps over 20 minutes are ignored. */
fun integrateKwh(points: List<IntraPoint>, pick: (IntraPoint) -> Double): Double {
    var kwh = 0.0
    for (i in 1 until points.size) {
        val dtH = (points[i].hour - points[i - 1].hour).toDouble()
        if (dtH <= 0.0 || dtH > 1.0 / 3.0) continue
        kwh += pick(points[i - 1]) * dtH / 1000.0
    }
    return kwh
}

/** Difference between the app's grid figure and the bill, as a share of the bill. */
fun billGapPercent(billUnits: Double, appUnits: Double): Double =
    if (billUnits <= 0.0) 0.0 else (billUnits - appUnits) / billUnits * 100.0
