package com.solarmonitor.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.PowerNow
import com.solarmonitor.logic.ACTIVE_W
import com.solarmonitor.logic.Share
import com.solarmonitor.logic.Source
import com.solarmonitor.logic.formatPower
import com.solarmonitor.logic.shares
import kotlin.math.sqrt

private const val W = 358f
private const val H = 428f
private const val NODE = 64f

private data class Pt(val x: Float, val y: Float)

private class Link(
    val points: List<Pt>,
    val colors: List<Color>,
    val arrow: Boolean
)

private val PvNode = Pt(30f, 36f)
private val GridNode = Pt(264f, 36f)
private val BatNode = Pt(30f, 284f)
private val GenNode = Pt(147f, 284f)
private val HouseNode = Pt(264f, 284f)
private val Inverter = Pt(131f, 154f)

private val PvPath = listOf(Pt(62f, 100f), Pt(62f, 130f), Pt(147f, 130f), Pt(147f, 154f))
private val GridPath = listOf(Pt(296f, 100f), Pt(296f, 130f), Pt(211f, 130f), Pt(211f, 154f))
private val BatPath = listOf(Pt(147f, 236f), Pt(147f, 262f), Pt(62f, 262f), Pt(62f, 284f))
private val GenPath = listOf(Pt(179f, 236f), Pt(179f, 284f))
private val HousePath = listOf(Pt(211f, 236f), Pt(211f, 262f), Pt(296f, 262f), Pt(296f, 284f))

@Composable
fun FlowDiagram(now: PowerNow, showGenerator: Boolean, modifier: Modifier = Modifier) {
    val solarOn = now.solarW >= ACTIVE_W
    val gridOn = now.gridW >= ACTIVE_W
    val genOn = showGenerator && now.generatorW >= ACTIVE_W
    val discharging = now.batteryW >= ACTIVE_W
    val charging = now.batteryW <= -ACTIVE_W

    val houseShares = shares(
        now.solarW, now.gridW, now.batteryW, if (showGenerator) now.generatorW else 0.0
    )
    val houseColors = houseShares.map { sourceColor(it.source) }
    val inputColors = buildList {
        if (solarOn) add(Palette.Solar)
        if (gridOn) add(Palette.Grid)
        if (genOn) add(Palette.Generator)
    }

    val links = buildList {
        add(Link(PvPath, listOf(Palette.Solar), solarOn))
        add(Link(GridPath, listOf(Palette.Grid), gridOn))
        if (discharging) {
            add(Link(BatPath.reversed(), listOf(Palette.Battery), true))
        } else if (charging) {
            add(Link(BatPath, if (inputColors.isEmpty()) listOf(Palette.Battery) else inputColors, true))
        } else {
            add(Link(BatPath, listOf(Palette.Battery), false))
        }
        if (showGenerator) add(Link(GenPath.reversed(), listOf(Palette.Generator), genOn))
        add(Link(HousePath, houseColors.ifEmpty { listOf(Palette.IdleLine) }, houseShares.isNotEmpty()))
    }
    // Battery links are stored hub to node. When discharging the energy leaves the battery
    // toward the inverter, so that link is drawn node to hub.
    val anyActive = solarOn || gridOn || genOn || discharging || charging

    val transition = rememberInfiniteTransition(label = "flow")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )

    BoxWithConstraints(modifier.fillMaxWidth(), contentAlignment = Alignment.TopCenter) {
        val scale = minOf(1f, maxWidth.value / W)
        Box(Modifier.size((W * scale).dp, (H * scale).dp)) {
            Canvas(Modifier.fillMaxSize()) {
                val u = size.width / W
                links.forEach { drawLink(it, u, t) }
                drawInverter(u, anyActive)
            }

            Placed(Inverter.x + 10f, Inverter.y + 10f, 76f, 24f, scale) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Inverter",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (anyActive) Palette.LedOn else Palette.TextSecondary
                    )
                }
            }

            Node(PvNode, scale, Icons.Rounded.WbSunny, "Solar", formatPower(now.solarW),
                listOf(Share(Source.SOLAR, now.solarW, 100)).filter { solarOn }, labelAbove = true)
            Node(GridNode, scale, Icons.Rounded.Power, "Grid", formatPower(now.gridW),
                listOf(Share(Source.GRID, now.gridW, 100)).filter { gridOn }, labelAbove = true)
            Node(
                BatNode, scale, Icons.Rounded.BatteryChargingFull, "Battery",
                formatPower(now.batteryW) + "  " + now.soc.toInt() + "%",
                if (discharging || charging) listOf(Share(Source.BATTERY, now.batteryW, 100)) else emptyList(),
                labelAbove = false
            )
            if (showGenerator) {
                Node(GenNode, scale, Icons.Rounded.LocalGasStation, "Generator", formatPower(now.generatorW),
                    listOf(Share(Source.GENERATOR, now.generatorW, 100)).filter { genOn }, labelAbove = false)
            }
            Node(HouseNode, scale, Icons.Rounded.Home, "House", formatPower(now.loadW), houseShares,
                labelAbove = false, isHouse = true)

            if (houseShares.isNotEmpty()) {
                Placed(198f, 392f, 160f, 24f, scale) {
                    Row(
                        Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.End),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        houseShares.forEach { PercentPill(it) }
                    }
                }
            }
        }
    }
}

@Composable
private fun Placed(x: Float, y: Float, w: Float, h: Float, scale: Float, content: @Composable () -> Unit) {
    Box(
        Modifier
            .offset((x * scale).dp, (y * scale).dp)
            .size((w * scale).dp, (h * scale).dp)
    ) { content() }
}

@Composable
private fun PercentPill(share: Share) {
    val c = sourceColor(share.source)
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(c.copy(alpha = 0.18f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text("${share.percent}%", color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Node(
    at: Pt,
    scale: Float,
    icon: ImageVector,
    name: String,
    value: String,
    arcs: List<Share>,
    labelAbove: Boolean,
    isHouse: Boolean = false
) {
    val active = arcs.isNotEmpty()
    val iconColor = when {
        !active -> Palette.IdleIcon
        isHouse -> Palette.Text
        else -> sourceColor(arcs.first().source)
    }
    Placed(at.x, at.y, NODE, NODE, scale) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(Palette.RunCard)
                .drawBehind { drawRing(arcs) },
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = name, tint = iconColor, modifier = Modifier.size(28.dp))
        }
    }
    val labelY = if (labelAbove) at.y - 34f else at.y + NODE + 4f
    Placed(at.x + NODE / 2f - 50f, labelY, 100f, 32f, scale) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = if (labelAbove) Arrangement.Bottom else Arrangement.Top
        ) {
            Text(name, fontSize = 11.sp, color = Palette.TextSecondary, textAlign = TextAlign.Center)
            Text(
                value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                color = if (active) Palette.Text else Palette.TextSecondary, textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

private fun DrawScope.drawRing(arcs: List<Share>) {
    val stroke = 4.dp.toPx()
    val inset = stroke / 2f
    val arcSize = Size(size.width - stroke, size.height - stroke)
    val topLeft = Offset(inset, inset)
    if (arcs.isEmpty()) {
        drawArc(Palette.IdleLine, 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
        return
    }
    val total = arcs.sumOf { it.percent }.coerceAtLeast(1)
    var start = -90f
    arcs.forEach {
        val sweep = 360f * it.percent / total
        drawArc(sourceColor(it.source), start, sweep, false, topLeft, arcSize, style = Stroke(stroke))
        start += sweep
    }
}

private fun DrawScope.drawInverter(u: Float, active: Boolean) {
    val x = Inverter.x * u
    val y = Inverter.y * u
    val body = Size(96f * u, 82f * u)
    val r = androidx.compose.ui.geometry.CornerRadius(14f * u, 14f * u)
    drawRoundRect(Palette.InverterBody, Offset(x, y), body, r)
    drawRoundRect(Palette.InverterEdge, Offset(x, y), body, r, style = Stroke(1.5f * u))
    drawRoundRect(
        Palette.InverterScreen, Offset(x + 10f * u, y + 10f * u), Size(76f * u, 24f * u),
        androidx.compose.ui.geometry.CornerRadius(6f * u, 6f * u)
    )
    val led = if (active) Palette.LedOn else Palette.LedOff
    for (i in 0..2) {
        drawCircle(led, 3f * u, Offset(x + (16f + i * 12f) * u, y + 56f * u))
    }
    for (i in 0..2) {
        val vy = y + (50f + i * 6f) * u
        drawLine(Palette.InverterEdge, Offset(x + 54f * u, vy), Offset(x + 84f * u, vy), 2f * u, StrokeCap.Round)
    }
}

private fun DrawScope.drawLink(link: Link, u: Float, t: Float) {
    val path = Path().apply {
        link.points.forEachIndexed { i, p ->
            if (i == 0) moveTo(p.x * u, p.y * u) else lineTo(p.x * u, p.y * u)
        }
    }
    val width = 4f * u
    if (!link.arrow) {
        drawPath(path, Palette.IdleLine, style = Stroke(width, cap = StrokeCap.Butt))
        return
    }
    val n = link.colors.size
    val on = if (n == 1) 7f else 6f
    val period = if (n == 1) 14f else n * on
    link.colors.forEachIndexed { i, c ->
        val phase = (1f - t) * period - i * on
        val effect = PathEffect.dashPathEffect(floatArrayOf(on * u, (period - on) * u), phase * u)
        drawPath(path, c, style = Stroke(width, cap = StrokeCap.Butt, pathEffect = effect))
    }
    val end = link.points.last()
    val prev = link.points[link.points.size - 2]
    var dx = end.x - prev.x
    var dy = end.y - prev.y
    val len = sqrt(dx * dx + dy * dy)
    if (len == 0f) return
    dx /= len
    dy /= len
    val tip = Offset(end.x * u, end.y * u)
    val baseCenter = Offset(tip.x - dx * 10f * u, tip.y - dy * 10f * u)
    val px = -dy
    val py = dx
    val head = Path().apply {
        moveTo(tip.x, tip.y)
        lineTo(baseCenter.x + px * 6f * u, baseCenter.y + py * 6f * u)
        lineTo(baseCenter.x - px * 6f * u, baseCenter.y - py * 6f * u)
        close()
    }
    drawPath(head, link.colors.first(), style = Fill)
}
