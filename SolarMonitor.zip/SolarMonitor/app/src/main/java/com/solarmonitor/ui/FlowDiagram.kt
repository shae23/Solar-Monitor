package com.solarmonitor.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LocalGasStation
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.data.PowerNow
import com.solarmonitor.logic.ACTIVE_W
import com.solarmonitor.logic.Share
import com.solarmonitor.logic.Source
import com.solarmonitor.logic.shares
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.abs
import kotlin.math.roundToInt

// Everything below is in dp. The diagram is 444 dp tall and uses the full width of the screen.
private const val H = 444f
private const val NODE = 64f
private const val DY = 16f
private const val CYCLE_MS = 3250

/** Gap between arrows that travel together, as a fraction of one cycle (0.35 s). */
private const val TRAIN_STEP = 0.35f / 3.25f

private enum class Route { PV_IN, GRID_IN, BAT_IN, BAT_OUT, GEN_IN, HOUSE_OUT }

/** The fixed dotted paths. w is the diagram width in dp and u is pixels per dp. */
private fun routePath(route: Route, w: Float, u: Float): Path {
    val left = 48f
    val right = w - 48f
    val mid = w / 2f
    val invL = mid - 36f
    val invR = mid + 36f
    fun x(v: Float) = v * u
    fun y(v: Float) = (v + DY) * u
    return Path().apply {
        when (route) {
            Route.PV_IN -> {
                moveTo(x(left), y(100f)); lineTo(x(left), y(154f))
                quadraticBezierTo(x(left), y(174f), x(left + 20f), y(174f)); lineTo(x(invL), y(174f))
            }
            Route.GRID_IN -> {
                moveTo(x(right), y(100f)); lineTo(x(right), y(154f))
                quadraticBezierTo(x(right), y(174f), x(right - 20f), y(174f)); lineTo(x(invR), y(174f))
            }
            Route.BAT_IN -> {
                moveTo(x(left), y(284f)); lineTo(x(left), y(236f))
                quadraticBezierTo(x(left), y(216f), x(left + 20f), y(216f)); lineTo(x(invL), y(216f))
            }
            Route.BAT_OUT -> {
                moveTo(x(invL), y(216f)); lineTo(x(left + 20f), y(216f))
                quadraticBezierTo(x(left), y(216f), x(left), y(236f)); lineTo(x(left), y(284f))
            }
            Route.GEN_IN -> {
                moveTo(x(mid), y(284f)); lineTo(x(mid), y(225f))
            }
            Route.HOUSE_OUT -> {
                moveTo(x(invR), y(216f)); lineTo(x(right - 20f), y(216f))
                quadraticBezierTo(x(right), y(216f), x(right), y(236f)); lineTo(x(right), y(284f))
            }
        }
    }
}

/** One arrow with a short trail travelling along a route, then gone until the next cycle. */
private class Comet(val route: Route, val color: Color, val outbound: Boolean, val offset: Float)

private fun fparts(w: Double): Pair<String, String> {
    val a = abs(w)
    return if (a >= 1000.0) String.format(Locale.US, "%.2f", a / 1000.0) to "kW" else a.roundToInt().toString() to "W"
}

@Composable
fun FlowDiagram(now: PowerNow, showGenerator: Boolean, modifier: Modifier = Modifier) {
    val solarOn = now.solarW >= ACTIVE_W
    val gridOn = now.gridW >= ACTIVE_W
    val genW = if (showGenerator) now.generatorW else 0.0
    val genOn = genW >= ACTIVE_W
    val discharging = now.batteryW >= ACTIVE_W
    val charging = now.batteryW <= -ACTIVE_W

    val houseShares = shares(now.solarW, now.gridW, now.batteryW, genW)
    val inputColors = buildList {
        if (solarOn) add(Palette.Solar)
        if (gridOn) add(Palette.Grid)
        if (genOn) add(Palette.Generator)
    }

    val comets = buildList {
        if (solarOn) add(Comet(Route.PV_IN, Palette.Solar, false, 0f))
        if (gridOn) add(Comet(Route.GRID_IN, Palette.Grid, false, 0f))
        if (genOn) add(Comet(Route.GEN_IN, Palette.Generator, false, 0f))
        if (discharging) add(Comet(Route.BAT_IN, Palette.Battery, false, 0f))
        if (charging) {
            val cols = inputColors.ifEmpty { listOf(Palette.Battery) }
            cols.forEachIndexed { i, c -> add(Comet(Route.BAT_OUT, c, true, TRAIN_STEP * i)) }
        }
        houseShares.forEachIndexed { i, s ->
            add(Comet(Route.HOUSE_OUT, sourceColor(s.source), true, TRAIN_STEP * i))
        }
    }

    // One light per source, always in the same order. A light is lit in its source colour while it runs.
    val ledColors: List<Color?> = listOf(
        if (solarOn) Palette.Solar else null,
        if (gridOn) Palette.Grid else null,
        if (discharging || charging) Palette.Battery else null,
        if (genOn) Palette.Generator else null
    )

    val transition = rememberInfiniteTransition(label = "flow")
    val t by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(CYCLE_MS, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )

    BoxWithConstraints(modifier.fillMaxWidth().height(H.dp)) {
        val w = maxWidth.value
        val mid = w / 2f
        Box(Modifier.fillMaxSize()) {
            Canvas(Modifier.fillMaxSize()) {
                val u = density
                Route.values().forEach { drawTrack(routePath(it, w, u), u) }
                comets.forEach { drawComet(it, w, u, t) }
                drawInverter(mid - 36f, u, ledColors)
            }

            Placed(mid - 36f + 6f, 165f + DY + 6f, 56f, 18f) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Inverter", fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Color(0xFFDDE0E6), maxLines = 1)
                }
            }

            NodeBlock(16f, 36f, w, Icons.Rounded.WbSunny, "Solar", fparts(now.solarW), null,
                listOf(Share(Source.SOLAR, now.solarW, 100)).filter { solarOn }, true, Align.Start)
            NodeBlock(w - 80f, 36f, w, Icons.Rounded.Power, "Grid", fparts(now.gridW), null,
                listOf(Share(Source.GRID, now.gridW, 100)).filter { gridOn }, true, Align.End)
            NodeBlock(16f, 284f, w, Icons.Rounded.BatteryChargingFull, "Battery", fparts(now.batteryW),
                now.soc.roundToInt(),
                if (discharging || charging) listOf(Share(Source.BATTERY, now.batteryW, 100)) else emptyList(),
                false, Align.Start)
            if (showGenerator) {
                NodeBlock(mid - 32f, 284f, w, Icons.Rounded.LocalGasStation, "Generator", fparts(genW), null,
                    listOf(Share(Source.GENERATOR, genW, 100)).filter { genOn }, false, Align.Center)
            }
            NodeBlock(w - 80f, 284f, w, Icons.Rounded.Home, "House", fparts(now.loadW), null, houseShares,
                false, Align.End, isHouse = true)
        }
    }
}

private enum class Align { Start, Center, End }

@Composable
private fun Placed(x: Float, y: Float, w: Float, h: Float, content: @Composable () -> Unit) {
    Box(
        Modifier
            .offset(x.dp, y.dp)
            .size(w.dp, h.dp)
    ) { content() }
}

/** A circle with its icon and the name and value label, above or below it. */
@Composable
private fun NodeBlock(
    x: Float,
    y: Float,
    width: Float,
    icon: ImageVector,
    name: String,
    value: Pair<String, String>,
    soc: Int?,
    arcs: List<Share>,
    labelAbove: Boolean,
    align: Align,
    isHouse: Boolean = false
) {
    val active = arcs.isNotEmpty()
    val iconColor = when {
        !active -> Palette.IdleIcon
        isHouse -> Palette.Text
        else -> sourceColor(arcs.first().source)
    }
    Placed(x, y + DY, NODE, NODE) {
        Box(
            Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(Palette.Background)
                .drawBehind { drawRing(arcs) },
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = name, tint = iconColor, modifier = Modifier.size(28.dp))
        }
    }

    val labelTop = if (labelAbove) y + DY - 48f else y + DY + 68f
    val labelLeft = when (align) {
        Align.Start -> 16f
        Align.End -> width - 16f - 130f
        Align.Center -> width / 2f - 65f
    }
    val horizontal = when (align) {
        Align.Start -> Alignment.Start
        Align.End -> Alignment.End
        Align.Center -> Alignment.CenterHorizontally
    }
    val textAlign = when (align) {
        Align.Start -> TextAlign.Start
        Align.End -> TextAlign.End
        Align.Center -> TextAlign.Center
    }
    Placed(labelLeft, labelTop, 130f, 46f) {
        Column(
            Modifier
                .fillMaxWidth()
                .wrapContentHeight(align = if (labelAbove) Alignment.Bottom else Alignment.Top, unbounded = true),
            horizontalAlignment = horizontal
        ) {
            Text(name, fontSize = 13.sp, color = Palette.TextSecondary, textAlign = textAlign, maxLines = 1)
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Palette.Text)) {
                        append(value.first)
                    }
                    withStyle(SpanStyle(fontSize = 12.sp, color = Palette.TextSecondary)) { append(" " + value.second) }
                    if (soc != null) {
                        withStyle(SpanStyle(fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Palette.Text)) {
                            append(" \u00B7 $soc")
                        }
                        withStyle(SpanStyle(fontSize = 12.sp, color = Palette.TextSecondary)) { append(" %") }
                    }
                },
                textAlign = textAlign,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

private fun DrawScope.drawRing(arcs: List<Share>) {
    val stroke = 3.dp.toPx()
    val inset = stroke / 2f
    val arcSize = Size(size.width - stroke, size.height - stroke)
    val topLeft = Offset(inset, inset)
    if (arcs.isEmpty()) {
        drawArc(Palette.IdleLine, 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
        return
    }
    val total = arcs.sumOf { it.percent }.coerceAtLeast(1)
    var start = -90f
    arcs.forEach {
        val sweep = 360f * it.percent / total
        drawArc(sourceColor(it.source), start, sweep, false, topLeft, arcSize, style = Stroke(stroke))
        start += sweep
    }
}

private fun DrawScope.drawInverter(left: Float, u: Float, leds: List<Color?>) {
    val x = left * u
    val y = (165f + DY) * u
    val body = Size(72f * u, 60f * u)
    val corner = CornerRadius(12f * u, 12f * u)
    drawRoundRect(Palette.InverterBody, Offset(x, y), body, corner)
    drawRoundRect(Palette.InverterEdge, Offset(x, y), body, corner, style = Stroke(2f * u))
    drawRoundRect(
        Palette.InverterScreen, Offset(x + 6f * u, y + 6f * u), Size(56f * u, 18f * u),
        CornerRadius(5f * u, 5f * u)
    )
    for (i in 0..3) {
        val c = leds.getOrNull(i) ?: Palette.LedOff
        drawCircle(c, 3f * u, Offset(x + (11f + 12f * i + 3f) * u, y + 35f * u))
    }
    for (i in 0..1) {
        val vy = y + (45f + 5f * i) * u
        drawLine(Palette.InverterEdge, Offset(x + 10f * u, vy), Offset(x + 58f * u, vy), 2f * u, StrokeCap.Round)
    }
}

/** The fixed dotted grey path that every arrow runs along. */
private fun DrawScope.drawTrack(path: Path, u: Float) {
    drawPath(
        path,
        Color(0xFF50535C),
        style = Stroke(
            width = 3f * u,
            cap = StrokeCap.Round,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(0.1f, 9f * u), 0f)
        )
    )
}

private fun DrawScope.drawComet(comet: Comet, w: Float, u: Float, t: Float) {
    val measure = PathMeasure()
    measure.setPath(routePath(comet.route, w, u), false)
    val length = measure.length
    if (length <= 0f) return

    // Inbound arrows run in the first half of the cycle and outbound ones in the second half,
    // so a flow reads as one trip through the inverter.
    fun progressAt(time: Float): Float {
        var p = (time - comet.offset) % 1f
        if (p < 0f) p += 1f
        return if (!comet.outbound) {
            if (p < 0.03f || p > 0.44f) -1f else ((p - 0.03f) / 0.37f).coerceIn(0f, 1f)
        } else {
            if (p < 0.55f) -1f else ((p - 0.58f) / 0.38f * 0.98f).coerceIn(0f, 1f)
        }
    }

    val lagStep = 0.085f / (CYCLE_MS / 1000f)
    val trailSizes = floatArrayOf(3.25f, 2.75f, 2.25f, 1.75f)
    val trailAlpha = floatArrayOf(0.8f, 0.6f, 0.4f, 0.25f)
    for (k in 4 downTo 1) {
        val p = progressAt(t - lagStep * k)
        if (p < 0f) continue
        val pos = measure.getPosition(length * p)
        drawCircle(comet.color.copy(alpha = trailAlpha[k - 1]), trailSizes[k - 1] * u, pos)
    }

    val p = progressAt(t)
    if (p < 0f) return
    val pos = measure.getPosition(length * p)
    val tan = measure.getTangent(length * p)
    val angle = (atan2(tan.y, tan.x) * 180.0 / PI).toFloat()
    val head = Path().apply {
        moveTo(7f * u, 0f)
        lineTo(-7f * u, -6f * u)
        lineTo(-7f * u, 6f * u)
        close()
    }
    withTransform({
        translate(pos.x, pos.y)
        rotate(angle, Offset.Zero)
    }) {
        drawPath(head, comet.color, style = Fill)
    }
}
