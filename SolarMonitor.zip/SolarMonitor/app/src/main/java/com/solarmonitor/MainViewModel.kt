package com.solarmonitor

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.solarmonitor.data.BillEntry
import com.solarmonitor.data.Credentials
import com.solarmonitor.data.DayPoint
import com.solarmonitor.data.IntraPoint
import com.solarmonitor.data.InverterItem
import com.solarmonitor.data.HomeExtra
import com.solarmonitor.data.homeExtraOf
import com.solarmonitor.data.parseDevices
import com.solarmonitor.data.parseInverterItems
import com.solarmonitor.data.pickInverterSn
import com.solarmonitor.data.parseDays
import com.solarmonitor.data.parseFrame
import com.solarmonitor.data.sampleOf
import com.solarmonitor.logic.billCycle
import com.solarmonitor.data.DayTotals
import com.solarmonitor.data.Plant
import com.solarmonitor.data.PlantBattery
import com.solarmonitor.data.PowerNow
import com.solarmonitor.data.Settings
import com.solarmonitor.data.SolarmanApi
import com.solarmonitor.data.SolarmanException
import com.solarmonitor.data.Store
import com.solarmonitor.data.parseDay
import com.solarmonitor.data.parseLive
import com.solarmonitor.data.sha256Lower
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId

private val NoDay = DayTotals(null, null, null, null)

/** What the Report tab is showing. tab: 0 Day, 1 Month, 2 Year, 3 Bill. */
data class ReportState(
    val tab: Int = 0,
    val day: LocalDate = LocalDate.now(),
    val month: YearMonth = YearMonth.now(),
    val year: Int = LocalDate.now().year,
    val cycleAnchor: LocalDate = LocalDate.now(),
    val loading: Boolean = false,
    val error: String? = null,
    val intra: List<IntraPoint> = emptyList(),
    val points: List<DayPoint> = emptyList(),
    val bill: BillEntry = BillEntry(),
    val rawFrame: String = "",
    val rawPeriod: String = "",
    val loadedOnce: Boolean = false
)

/** What the Devices tab shows from the inverter and logger. Read only. */
data class InverterState(
    val loading: Boolean = false,
    val error: String? = null,
    val items: List<InverterItem> = emptyList(),
    val raw: String = "",
    val deviceSn: String = "",
    val inverterOnline: Boolean? = null,
    val loggerSn: String = "",
    val loggerOnline: Boolean? = null,
    val loggerItems: List<InverterItem> = emptyList(),
    val loggerRaw: String = "",
    val loggerError: String? = null,
    val points: List<IntraPoint> = emptyList(),
    val updatedMs: Long = 0L,
    val loadedOnce: Boolean = false
)

data class UiState(
    val signedIn: Boolean = false,
    val email: String = "",
    val plantName: String = "",
    val plantId: Long = 0L,
    val plants: List<Plant> = emptyList(),
    val battery: PlantBattery? = null,
    val live: PowerNow = PowerNow.Empty,
    val day: DayTotals = NoDay,
    val settings: Settings = Settings(),
    val loading: Boolean = false,
    val hasData: Boolean = false,
    val error: String? = null,
    val callsToday: Int = 0,
    val rawLive: String = "",
    val rawDay: String = "",
    val signingIn: Boolean = false,
    val signInError: String? = null,
    val report: ReportState = ReportState(),
    val inverter: InverterState = InverterState(),
    val extra: HomeExtra = HomeExtra()
) {
    /** Live data with the battery sign flipped when the Menu switch is on. */
    val now: PowerNow
        get() = if (settings.invertBattery) live.copy(batteryW = -live.batteryW) else live
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private var api = SolarmanApi { store.addCall() }
    private var busy = false
    private var lastTryMs = 0L
    private var generation = 0
    private var invSn = ""
    private var extraAtMs = 0L
    private var reportGen = 0
    private class Cached(val atMs: Long, val value: Any)
    private val cache = HashMap<String, Cached>()

    private val _state = MutableStateFlow(initial())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private fun initial(): UiState {
        val c = store.credentials()
        val id = store.plantId()
        return UiState(
            signedIn = c != null,
            email = c?.email ?: "",
            plantName = store.plantName() ?: "",
            plantId = id,
            plants = store.plants(),
            battery = if (id != 0L) store.plantBattery(id) else null,
            settings = store.settings(),
            callsToday = store.callsToday()
        )
    }

    fun signIn(appId: String, appSecret: String, email: String, password: String) {
        if (appId.isBlank() || appSecret.isBlank() || email.isBlank() || password.isEmpty()) {
            _state.update { it.copy(signInError = "Please fill in all four boxes.") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(signingIn = true, signInError = null) }
            try {
                val c = Credentials(appId.trim(), appSecret.trim(), email.trim(), sha256Lower(password))
                val fresh = SolarmanApi { store.addCall() }
                fresh.login(c)
                val plants = fresh.plants(c)
                api = fresh
                store.saveCredentials(c)
                store.savePlants(plants)
                val first = plants.firstOrNull()
                if (first != null) store.savePlant(first) else store.clearPlant()
                _state.update {
                    it.copy(
                        signedIn = true,
                        email = c.email,
                        plants = plants,
                        plantName = first?.name ?: "",
                        plantId = first?.id ?: 0L,
                        battery = first?.let { p -> store.plantBattery(p.id) },
                        signingIn = false,
                        signInError = null,
                        callsToday = store.callsToday()
                    )
                }
                lastTryMs = 0L
                refresh(true)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(signingIn = false, signInError = friendly(e), callsToday = store.callsToday()) }
            }
        }
    }

    fun signOut() {
        generation++
        busy = false
        store.clearCredentials()
        cache.clear()
        reportGen++
        api = SolarmanApi { store.addCall() }
        _state.update { UiState(settings = it.settings, callsToday = store.callsToday()) }
    }

    fun updateSettings(s: Settings) {
        store.saveSettings(s)
        _state.update { it.copy(settings = s) }
    }

    fun saveBattery(kwh: Double, reservePct: Double) {
        val id = _state.value.plantId
        if (id == 0L) return
        val b = PlantBattery(kwh, reservePct)
        store.savePlantBattery(id, b)
        _state.update { it.copy(battery = b) }
    }

    fun selectPlant(id: Long) {
        val plant = _state.value.plants.firstOrNull { it.id == id } ?: return
        if (plant.id == _state.value.plantId) return
        store.savePlant(plant)
        invSn = ""
        extraAtMs = 0L
        _state.update {
            it.copy(
                extra = HomeExtra(),
                plantId = plant.id,
                plantName = plant.name,
                battery = store.plantBattery(plant.id),
                live = PowerNow.Empty,
                day = NoDay,
                hasData = false,
                error = null,
                rawLive = "",
                rawDay = "",
                report = ReportState(tab = it.report.tab)
            )
        }
        lastTryMs = 0L
        refresh(true)
    }

    fun refresh(force: Boolean = false) {
        val creds = store.credentials() ?: return
        if (busy && !force) return
        val gap = if (force) 0L else 30_000L
        if (System.currentTimeMillis() - lastTryMs < gap) return
        val mine = ++generation
        busy = true
        lastTryMs = System.currentTimeMillis()
        _state.update { it.copy(loading = true) }
        viewModelScope.launch {
            try {
                var plantId = store.plantId()
                var name = store.plantName() ?: ""
                if (plantId == 0L) {
                    val list = api.plants(creds)
                    store.savePlants(list)
                    val p = list.firstOrNull()
                        ?: throw SolarmanException(null, "No plant was found on this SOLARMAN account.")
                    store.savePlant(p)
                    plantId = p.id
                    name = p.name
                    _state.update {
                        it.copy(plants = list, plantId = p.id, plantName = p.name, battery = store.plantBattery(p.id))
                    }
                }
                val liveJson = api.realTime(creds, plantId)
                val live = parseLive(liveJson)

                var day: DayTotals? = null
                var rawDay = ""
                try {
                    val dayJson = api.dayHistory(creds, plantId, LocalDate.now().toString())
                    day = parseDay(dayJson)
                    rawDay = dayJson.toString(2)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    rawDay = "Daily totals failed: ${friendly(e)}"
                }

                // Alarm flag and grid charging from the inverter. Skipped if it was read in the last 4 minutes.
                var extra: HomeExtra? = null
                if (force || System.currentTimeMillis() - extraAtMs > 4 * 60_000L) {
                    try {
                        if (invSn.isBlank()) {
                            val devs = parseDevices(api.devices(creds, plantId))
                            invSn = (devs.firstOrNull { it.isInverter } ?: devs.firstOrNull { !it.isLogger })?.sn.orEmpty()
                        }
                        if (invSn.isNotBlank()) {
                            extra = homeExtraOf(parseInverterItems(api.deviceCurrentData(creds, invSn)))
                            extraAtMs = System.currentTimeMillis()
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        invSn = ""
                    }
                }

                // A newer refresh or a plant switch happened while this one was running.
                if (mine != generation) return@launch

                _state.update {
                    it.copy(
                        plantId = plantId,
                        plantName = name,
                        live = live,
                        day = day ?: it.day,
                        extra = extra ?: it.extra,
                        hasData = true,
                        error = null,
                        rawLive = liveJson.toString(2),
                        rawDay = rawDay,
                        callsToday = store.callsToday()
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (mine == generation) {
                    _state.update { it.copy(error = friendly(e), callsToday = store.callsToday()) }
                }
            } finally {
                if (mine == generation) {
                    busy = false
                    _state.update { it.copy(loading = false) }
                }
            }
        }
    }

    // ---- Report tab ----

    fun reportTab(tab: Int) {
        _state.update { it.copy(report = it.report.copy(tab = tab, error = null)) }
        reportLoad(false)
    }

    /** Moves the Report tab one step back (-1) or forward (+1) and loads it. Never goes past today. */
    fun reportShift(delta: Int) {
        val today = LocalDate.now()
        _state.update {
            val r = it.report
            val moved = when (r.tab) {
                0 -> r.copy(day = r.day.plusDays(delta.toLong()).let { d -> if (d.isAfter(today)) today else d })
                1 -> r.copy(month = r.month.plusMonths(delta.toLong()).let { m -> if (m.isAfter(YearMonth.now())) YearMonth.now() else m })
                2 -> r.copy(year = (r.year + delta).coerceAtMost(today.year))
                else -> {
                    val a = r.cycleAnchor.plusMonths(delta.toLong())
                    r.copy(cycleAnchor = if (a.isAfter(today)) today else a)
                }
            }
            it.copy(report = moved.copy(error = null))
        }
        reportLoad(false)
    }

    fun saveBill(units: String, amount: String) {
        val id = _state.value.plantId
        if (id == 0L) return
        val r = _state.value.report
        val start = billCycle(r.cycleAnchor, _state.value.settings.billStartDay).first
        val e = BillEntry(units, amount)
        store.saveBillEntry(id, start, e)
        _state.update { it.copy(report = it.report.copy(bill = e)) }
    }

    fun reportRefresh() = reportLoad(true)

    private suspend fun <T : Any> cachedOrLoad(key: String, includesToday: Boolean, force: Boolean, load: suspend () -> T): T {
        val hit = cache[key]
        val fresh = hit != null && (!includesToday || System.currentTimeMillis() - hit.atMs < 5 * 60_000L)
        if (hit != null && fresh && !force) {
            @Suppress("UNCHECKED_CAST")
            val cached = hit.value as T
            return cached
        }
        val v = load()
        cache[key] = Cached(System.currentTimeMillis(), v)
        return v
    }

    fun inverterLoad() {
        val creds = store.credentials() ?: return
        val plantId = _state.value.plantId
        if (plantId == 0L) return
        if (_state.value.inverter.loading) return
        val invert = _state.value.settings.invertBattery
        val zone = ZoneId.systemDefault()
        _state.update { it.copy(inverter = it.inverter.copy(loading = true, error = null)) }
        viewModelScope.launch {
            try {
                val list = api.devices(creds, plantId)
                val devices = parseDevices(list)
                val inv = devices.firstOrNull { it.isInverter } ?: devices.firstOrNull { !it.isLogger }
                val log = devices.firstOrNull { it.isLogger }
                if (inv == null) {
                    _state.update {
                        it.copy(inverter = InverterState(error = "SOLARMAN listed no inverter for this plant.", raw = list.toString(2), loadedOnce = true))
                    }
                    return@launch
                }
                val data = api.deviceCurrentData(creds, inv.sn)
                val items = parseInverterItems(data)

                var loggerItems: List<InverterItem> = emptyList()
                var loggerRaw = ""
                var loggerError: String? = null
                if (log != null) {
                    try {
                        val ld = api.deviceCurrentData(creds, log.sn)
                        loggerItems = parseInverterItems(ld)
                        loggerRaw = ld.toString(2)
                    } catch (e: Exception) {
                        loggerError = friendly(e)
                    }
                }

                var points: List<IntraPoint> = emptyList()
                try {
                    val d = LocalDate.now().toString()
                    points = parseFrame(api.history(creds, plantId, 1, d, d), zone, invert)
                } catch (e: Exception) {
                }

                _state.update {
                    it.copy(
                        inverter = InverterState(
                            items = items, deviceSn = inv.sn, raw = data.toString(2),
                            inverterOnline = inv.online,
                            loggerSn = log?.sn.orEmpty(), loggerOnline = log?.online,
                            loggerItems = loggerItems, loggerRaw = loggerRaw, loggerError = loggerError,
                            points = points, updatedMs = System.currentTimeMillis(), loadedOnce = true,
                            error = if (items.isEmpty()) "SOLARMAN sent no readings for this device." else null
                        )
                    )
                }
            } catch (e: Exception) {
                _state.update { it.copy(inverter = it.inverter.copy(loading = false, loadedOnce = true, error = friendly(e))) }
            }
        }
    }

    fun reportLoad(force: Boolean) {
        val creds = store.credentials() ?: return
        val plantId = _state.value.plantId
        if (plantId == 0L) return
        val r = _state.value.report
        val settings = _state.value.settings
        val today = LocalDate.now()
        val zone = ZoneId.systemDefault()
        val mine = ++reportGen
        _state.update { it.copy(report = it.report.copy(loading = true, error = null)) }
        viewModelScope.launch {
            try {
                var intra: List<IntraPoint> = emptyList()
                var points: List<DayPoint> = emptyList()
                var bill = BillEntry()
                var rawFrame = ""
                var rawPeriod = ""
                when (r.tab) {
                    0 -> {
                        val d = r.day.toString()
                        val frameJson = cachedOrLoad("$plantId|f|$d", r.day == today, force) {
                            api.history(creds, plantId, 1, d, d)
                        }
                        intra = parseFrame(frameJson, zone, settings.invertBattery)
                        rawFrame = sampleOf(frameJson)
                        val dayJson = cachedOrLoad("$plantId|d|$d", r.day == today, force) {
                            api.history(creds, plantId, 2, d, d)
                        }
                        points = parseDays(dayJson)
                        rawPeriod = sampleOf(dayJson)
                        if (intra.isEmpty()) {
                            _state.update { it.copy(report = it.report.copy(error = "SOLARMAN sent no timed readings for this day. Copy the Report data on the Device tab and send it over.")) }
                        }
                    }
                    1 -> {
                        val first = r.month.atDay(1)
                        val last = minOf(r.month.atEndOfMonth(), today)
                        val j = cachedOrLoad("$plantId|m|${r.month}", r.month == YearMonth.now(), force) {
                            api.history(creds, plantId, 2, first.toString(), last.toString())
                        }
                        points = parseDays(j)
                        rawPeriod = sampleOf(j)
                    }
                    2 -> {
                        val j = cachedOrLoad("$plantId|y|${r.year}", r.year == today.year, force) {
                            api.history(creds, plantId, 3, "${r.year}-01", "${r.year}-12")
                        }
                        points = parseDays(j)
                        rawPeriod = sampleOf(j)
                    }
                    else -> {
                        val (start, end) = billCycle(r.cycleAnchor, settings.billStartDay)
                        val stop = minOf(end, today)
                        bill = store.billEntry(plantId, start)
                        if (!start.isAfter(today)) {
                            val j = cachedOrLoad("$plantId|b|$start", !end.isBefore(today), force) {
                                api.history(creds, plantId, 2, start.toString(), stop.toString())
                            }
                            points = parseDays(j)
                            rawPeriod = sampleOf(j)
                        }
                    }
                }
                if (mine != reportGen) return@launch
                _state.update {
                    it.copy(
                        callsToday = store.callsToday(),
                        report = it.report.copy(
                            intra = intra, points = points, bill = bill,
                            rawFrame = if (r.tab == 0) rawFrame else it.report.rawFrame,
                            rawPeriod = rawPeriod, loadedOnce = true
                        )
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (mine == reportGen) {
                    _state.update { it.copy(callsToday = store.callsToday(), report = it.report.copy(error = friendly(e), intra = emptyList(), points = emptyList())) }
                }
            } finally {
                if (mine == reportGen) {
                    _state.update { it.copy(report = it.report.copy(loading = false)) }
                }
            }
        }
    }

    private fun friendly(e: Exception): String {
        if (e is SolarmanException) {
            val extra = e.message?.let { " ($it)" } ?: ""
            return when (e.code) {
                "2101002" -> "SOLARMAN says the app asked too often. It will try again at the next refresh."
                "2101009" -> "This SOLARMAN account is locked. Try again later."
                "2101010" -> "The API allowance for this account is used up."
                "2101017", "2101019" -> "SOLARMAN rejected the sign-in token. Pull to refresh to sign in again."
                "2101025", "2101028", "2101029" -> "SOLARMAN did not accept the App ID, App Secret, email or password$extra"
                else -> e.message ?: "SOLARMAN returned an error."
            }
        }
        return when (e) {
            is java.net.UnknownHostException -> "No internet connection."
            is java.net.SocketTimeoutException -> "SOLARMAN took too long to answer."
            else -> e.message ?: "Something went wrong."
        }
    }
}
