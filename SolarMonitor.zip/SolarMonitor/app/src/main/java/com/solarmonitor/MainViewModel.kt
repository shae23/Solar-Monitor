package com.solarmonitor

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.solarmonitor.data.Credentials
import com.solarmonitor.data.DayTotals
import com.solarmonitor.data.PowerNow
import com.solarmonitor.data.Settings
import com.solarmonitor.data.SolarmanApi
import com.solarmonitor.data.SolarmanException
import com.solarmonitor.data.Store
import com.solarmonitor.data.parseDay
import com.solarmonitor.data.parseLive
import com.solarmonitor.data.sha256Lower
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

data class UiState(
    val signedIn: Boolean = false,
    val email: String = "",
    val plantName: String = "",
    val plantId: Long = 0L,
    val live: PowerNow = PowerNow.Empty,
    val day: DayTotals = DayTotals(null, null, null, null),
    val settings: Settings = Settings(),
    val loading: Boolean = false,
    val hasData: Boolean = false,
    val error: String? = null,
    val callsToday: Int = 0,
    val rawLive: String = "",
    val rawDay: String = "",
    val signingIn: Boolean = false,
    val signInError: String? = null
) {
    /** Live data with the battery sign flipped when the Menu switch is on. */
    val now: PowerNow
        get() = if (settings.invertBattery) live.copy(batteryW = -live.batteryW) else live
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private var api = SolarmanApi { store.addCall() }
    private var busy = false
    private var lastTryMs = 0L

    private val _state = MutableStateFlow(initial())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private fun initial(): UiState {
        val c = store.credentials()
        return UiState(
            signedIn = c != null,
            email = c?.email ?: "",
            plantName = store.plantName() ?: "",
            plantId = store.plantId(),
            settings = store.settings(),
            callsToday = store.callsToday()
        )
    }

    fun signIn(appId: String, appSecret: String, email: String, password: String) {
        if (appId.isBlank() || appSecret.isBlank() || email.isBlank() || password.isEmpty()) {
            _state.update { it.copy(signInError = "Please fill in all four boxes.") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(signingIn = true, signInError = null) }
            try {
                val c = Credentials(appId.trim(), appSecret.trim(), email.trim(), sha256Lower(password))
                val fresh = SolarmanApi { store.addCall() }
                fresh.login(c)
                val plants = fresh.plants(c)
                api = fresh
                store.saveCredentials(c)
                val first = plants.firstOrNull()
                if (first != null) store.savePlant(first) else store.clearPlant()
                _state.update {
                    it.copy(
                        signedIn = true,
                        email = c.email,
                        plantName = first?.name ?: "",
                        plantId = first?.id ?: 0L,
                        signingIn = false,
                        signInError = null,
                        callsToday = store.callsToday()
                    )
                }
                refresh(true)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(signingIn = false, signInError = friendly(e), callsToday = store.callsToday()) }
            }
        }
    }

    fun signOut() {
        store.clearCredentials()
        api = SolarmanApi { store.addCall() }
        _state.update {
            UiState(settings = it.settings, callsToday = store.callsToday())
        }
    }

    fun updateSettings(s: Settings) {
        store.saveSettings(s)
        _state.update { it.copy(settings = s) }
    }

    fun refresh(force: Boolean = false) {
        val creds = store.credentials() ?: return
        if (busy) return
        val gap = if (force) 10_000L else 60_000L
        if (System.currentTimeMillis() - lastTryMs < gap) return
        busy = true
        lastTryMs = System.currentTimeMillis()
        _state.update { it.copy(loading = true) }
        viewModelScope.launch {
            try {
                var plantId = store.plantId()
                var name = store.plantName() ?: ""
                if (plantId == 0L) {
                    val p = api.plants(creds).firstOrNull()
                        ?: throw SolarmanException(null, "No plant was found on this SOLARMAN account.")
                    store.savePlant(p)
                    plantId = p.id
                    name = p.name
                }
                val liveJson = api.realTime(creds, plantId)
                val live = parseLive(liveJson)

                var day: DayTotals? = null
                var rawDay = ""
                try {
                    val dayJson = api.dayHistory(creds, plantId, LocalDate.now().toString())
                    day = parseDay(dayJson)
                    rawDay = dayJson.toString(2)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    rawDay = "Daily totals failed: ${friendly(e)}"
                }

                _state.update {
                    it.copy(
                        plantId = plantId,
                        plantName = name,
                        live = live,
                        day = day ?: it.day,
                        hasData = true,
                        error = null,
                        rawLive = liveJson.toString(2),
                        rawDay = rawDay,
                        callsToday = store.callsToday()
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(error = friendly(e), callsToday = store.callsToday()) }
            } finally {
                busy = false
                _state.update { it.copy(loading = false) }
            }
        }
    }

    private fun friendly(e: Exception): String {
        if (e is SolarmanException) {
            val extra = e.message?.let { " ($it)" } ?: ""
            return when (e.code) {
                "2101002" -> "SOLARMAN says the app asked too often. It will try again at the next refresh."
                "2101009" -> "This SOLARMAN account is locked. Try again later."
                "2101010" -> "The API allowance for this account is used up."
                "2101017", "2101019" -> "SOLARMAN rejected the sign-in token. Pull to refresh to sign in again."
                "2101025", "2101028", "2101029" -> "SOLARMAN did not accept the App ID, App Secret, email or password$extra"
                else -> e.message ?: "SOLARMAN returned an error."
            }
        }
        return when (e) {
            is java.net.UnknownHostException -> "No internet connection."
            is java.net.SocketTimeoutException -> "SOLARMAN took too long to answer."
            else -> e.message ?: "Something went wrong."
        }
    }
}
