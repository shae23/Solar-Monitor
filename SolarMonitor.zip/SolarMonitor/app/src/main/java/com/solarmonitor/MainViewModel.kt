package com.solarmonitor

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.solarmonitor.data.Credentials
import com.solarmonitor.data.DayTotals
import com.solarmonitor.data.Plant
import com.solarmonitor.data.PlantBattery
import com.solarmonitor.data.PowerNow
import com.solarmonitor.data.Settings
import com.solarmonitor.data.SolarmanApi
import com.solarmonitor.data.SolarmanException
import com.solarmonitor.data.Store
import com.solarmonitor.data.parseDay
import com.solarmonitor.data.parseLive
import com.solarmonitor.data.sha256Lower
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate

private val NoDay = DayTotals(null, null, null, null)

data class UiState(
    val signedIn: Boolean = false,
    val email: String = "",
    val plantName: String = "",
    val plantId: Long = 0L,
    val plants: List<Plant> = emptyList(),
    val battery: PlantBattery? = null,
    val live: PowerNow = PowerNow.Empty,
    val day: DayTotals = NoDay,
    val settings: Settings = Settings(),
    val loading: Boolean = false,
    val hasData: Boolean = false,
    val error: String? = null,
    val callsToday: Int = 0,
    val rawLive: String = "",
    val rawDay: String = "",
    val signingIn: Boolean = false,
    val signInError: String? = null
) {
    /** Live data with the battery sign flipped when the Menu switch is on. */
    val now: PowerNow
        get() = if (settings.invertBattery) live.copy(batteryW = -live.batteryW) else live
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val store = Store(app)
    private var api = SolarmanApi { store.addCall() }
    private var busy = false
    private var lastTryMs = 0L
    private var generation = 0

    private val _state = MutableStateFlow(initial())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private fun initial(): UiState {
        val c = store.credentials()
        val id = store.plantId()
        return UiState(
            signedIn = c != null,
            email = c?.email ?: "",
            plantName = store.plantName() ?: "",
            plantId = id,
            plants = store.plants(),
            battery = if (id != 0L) store.plantBattery(id) else null,
            settings = store.settings(),
            callsToday = store.callsToday()
        )
    }

    fun signIn(appId: String, appSecret: String, email: String, password: String) {
        if (appId.isBlank() || appSecret.isBlank() || email.isBlank() || password.isEmpty()) {
            _state.update { it.copy(signInError = "Please fill in all four boxes.") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(signingIn = true, signInError = null) }
            try {
                val c = Credentials(appId.trim(), appSecret.trim(), email.trim(), sha256Lower(password))
                val fresh = SolarmanApi { store.addCall() }
                fresh.login(c)
                val plants = fresh.plants(c)
                api = fresh
                store.saveCredentials(c)
                store.savePlants(plants)
                val first = plants.firstOrNull()
                if (first != null) store.savePlant(first) else store.clearPlant()
                _state.update {
                    it.copy(
                        signedIn = true,
                        email = c.email,
                        plants = plants,
                        plantName = first?.name ?: "",
                        plantId = first?.id ?: 0L,
                        battery = first?.let { p -> store.plantBattery(p.id) },
                        signingIn = false,
                        signInError = null,
                        callsToday = store.callsToday()
                    )
                }
                lastTryMs = 0L
                refresh(true)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.update { it.copy(signingIn = false, signInError = friendly(e), callsToday = store.callsToday()) }
            }
        }
    }

    fun signOut() {
        generation++
        busy = false
        store.clearCredentials()
        api = SolarmanApi { store.addCall() }
        _state.update { UiState(settings = it.settings, callsToday = store.callsToday()) }
    }

    fun updateSettings(s: Settings) {
        store.saveSettings(s)
        _state.update { it.copy(settings = s) }
    }

    fun saveBattery(kwh: Double, reservePct: Double) {
        val id = _state.value.plantId
        if (id == 0L) return
        val b = PlantBattery(kwh, reservePct)
        store.savePlantBattery(id, b)
        _state.update { it.copy(battery = b) }
    }

    fun selectPlant(id: Long) {
        val plant = _state.value.plants.firstOrNull { it.id == id } ?: return
        if (plant.id == _state.value.plantId) return
        store.savePlant(plant)
        _state.update {
            it.copy(
                plantId = plant.id,
                plantName = plant.name,
                battery = store.plantBattery(plant.id),
                live = PowerNow.Empty,
                day = NoDay,
                hasData = false,
                error = null,
                rawLive = "",
                rawDay = ""
            )
        }
        lastTryMs = 0L
        refresh(true)
    }

    fun refresh(force: Boolean = false) {
        val creds = store.credentials() ?: return
        if (busy && !force) return
        val gap = if (force) 10_000L else 60_000L
        if (System.currentTimeMillis() - lastTryMs < gap) return
        val mine = ++generation
        busy = true
        lastTryMs = System.currentTimeMillis()
        _state.update { it.copy(loading = true) }
        viewModelScope.launch {
            try {
                var plantId = store.plantId()
                var name = store.plantName() ?: ""
                if (plantId == 0L) {
                    val list = api.plants(creds)
                    store.savePlants(list)
                    val p = list.firstOrNull()
                        ?: throw SolarmanException(null, "No plant was found on this SOLARMAN account.")
                    store.savePlant(p)
                    plantId = p.id
                    name = p.name
                    _state.update {
                        it.copy(plants = list, plantId = p.id, plantName = p.name, battery = store.plantBattery(p.id))
                    }
                }
                val liveJson = api.realTime(creds, plantId)
                val live = parseLive(liveJson)

                var day: DayTotals? = null
                var rawDay = ""
                try {
                    val dayJson = api.dayHistory(creds, plantId, LocalDate.now().toString())
                    day = parseDay(dayJson)
                    rawDay = dayJson.toString(2)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    rawDay = "Daily totals failed: ${friendly(e)}"
                }

                // A newer refresh or a plant switch happened while this one was running.
                if (mine != generation) return@launch

                _state.update {
                    it.copy(
                        plantId = plantId,
                        plantName = name,
                        live = live,
                        day = day ?: it.day,
                        hasData = true,
                        error = null,
                        rawLive = liveJson.toString(2),
                        rawDay = rawDay,
                        callsToday = store.callsToday()
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (mine == generation) {
                    _state.update { it.copy(error = friendly(e), callsToday = store.callsToday()) }
                }
            } finally {
                if (mine == generation) {
                    busy = false
                    _state.update { it.copy(loading = false) }
                }
            }
        }
    }

    private fun friendly(e: Exception): String {
        if (e is SolarmanException) {
            val extra = e.message?.let { " ($it)" } ?: ""
            return when (e.code) {
                "2101002" -> "SOLARMAN says the app asked too often. It will try again at the next refresh."
                "2101009" -> "This SOLARMAN account is locked. Try again later."
                "2101010" -> "The API allowance for this account is used up."
                "2101017", "2101019" -> "SOLARMAN rejected the sign-in token. Pull to refresh to sign in again."
                "2101025", "2101028", "2101029" -> "SOLARMAN did not accept the App ID, App Secret, email or password$extra"
                else -> e.message ?: "SOLARMAN returned an error."
            }
        }
        return when (e) {
            is java.net.UnknownHostException -> "No internet connection."
            is java.net.SocketTimeoutException -> "SOLARMAN took too long to answer."
            else -> e.message ?: "Something went wrong."
        }
    }
}
