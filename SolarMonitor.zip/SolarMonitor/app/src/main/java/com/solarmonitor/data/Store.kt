package com.solarmonitor.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.time.LocalDate

/**
 * Keeps the sign-in details and settings on the phone. The password is never saved,
 * only its SHA-256 hash, which is what SOLARMAN asks for.
 */
class Store(context: Context) {
    private val prefs: SharedPreferences = try {
        val app = context.applicationContext
        val key = MasterKey.Builder(app)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            app,
            "solar_monitor_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        context.applicationContext.getSharedPreferences("solar_monitor_plain", Context.MODE_PRIVATE)
    }

    fun credentials(): Credentials? {
        val appId = prefs.getString("app_id", "") ?: ""
        val secret = prefs.getString("app_secret", "") ?: ""
        val email = prefs.getString("email", "") ?: ""
        val hash = prefs.getString("password_hash", "") ?: ""
        if (appId.isEmpty() || secret.isEmpty() || email.isEmpty() || hash.isEmpty()) return null
        return Credentials(appId, secret, email, hash)
    }

    fun saveCredentials(c: Credentials) {
        prefs.edit()
            .putString("app_id", c.appId)
            .putString("app_secret", c.appSecret)
            .putString("email", c.email)
            .putString("password_hash", c.passwordHash)
            .apply()
    }

    fun clearCredentials() {
        prefs.edit()
            .remove("app_id")
            .remove("app_secret")
            .remove("email")
            .remove("password_hash")
            .remove("plant_id")
            .remove("plant_name")
            .apply()
    }

    fun plantId(): Long = prefs.getLong("plant_id", 0L)

    fun plantName(): String? = prefs.getString("plant_name", null)

    fun savePlant(plant: Plant) {
        prefs.edit().putLong("plant_id", plant.id).putString("plant_name", plant.name).apply()
    }

    fun clearPlant() {
        prefs.edit().remove("plant_id").remove("plant_name").apply()
    }

    fun settings(): Settings {
        val d = Settings()
        return Settings(
            batteryKwh = prefs.getString("battery_kwh", null)?.toDoubleOrNull() ?: d.batteryKwh,
            reservePct = prefs.getString("reserve_pct", null)?.toDoubleOrNull() ?: d.reservePct,
            refreshMinutes = prefs.getInt("refresh_minutes", d.refreshMinutes),
            showGenerator = prefs.getBoolean("show_generator", d.showGenerator),
            invertBattery = prefs.getBoolean("invert_battery", d.invertBattery)
        )
    }

    fun saveSettings(s: Settings) {
        prefs.edit()
            .putString("battery_kwh", s.batteryKwh.toString())
            .putString("reserve_pct", s.reservePct.toString())
            .putInt("refresh_minutes", s.refreshMinutes)
            .putBoolean("show_generator", s.showGenerator)
            .putBoolean("invert_battery", s.invertBattery)
            .apply()
    }

    @Synchronized
    fun addCall() {
        val today = LocalDate.now().toString()
        val count = if (prefs.getString("calls_day", "") == today) prefs.getInt("calls", 0) else 0
        prefs.edit().putString("calls_day", today).putInt("calls", count + 1).apply()
    }

    @Synchronized
    fun callsToday(): Int {
        val today = LocalDate.now().toString()
        return if (prefs.getString("calls_day", "") == today) prefs.getInt("calls", 0) else 0
    }
}
