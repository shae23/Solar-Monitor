package com.solarmonitor.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/**
 * Keeps the sign-in details and settings on the phone. The password is never saved,
 * only its SHA-256 hash, which is what SOLARMAN asks for.
 */
class Store(context: Context) {
    private val prefs: SharedPreferences = try {
        val app = context.applicationContext
        val key = MasterKey.Builder(app)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            app,
            "solar_monitor_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        context.applicationContext.getSharedPreferences("solar_monitor_plain", Context.MODE_PRIVATE)
    }

    fun credentials(): Credentials? {
        val appId = prefs.getString("app_id", "") ?: ""
        val secret = prefs.getString("app_secret", "") ?: ""
        val email = prefs.getString("email", "") ?: ""
        val hash = prefs.getString("password_hash", "") ?: ""
        if (appId.isEmpty() || secret.isEmpty() || email.isEmpty() || hash.isEmpty()) return null
        return Credentials(appId, secret, email, hash)
    }

    fun saveCredentials(c: Credentials) {
        prefs.edit()
            .putString("app_id", c.appId)
            .putString("app_secret", c.appSecret)
            .putString("email", c.email)
            .putString("password_hash", c.passwordHash)
            .apply()
    }

    fun clearCredentials() {
        prefs.edit()
            .remove("app_id")
            .remove("app_secret")
            .remove("email")
            .remove("password_hash")
            .remove("plant_id")
            .remove("plant_name")
            .remove("plants_json")
            .apply()
    }

    fun plantId(): Long = prefs.getLong("plant_id", 0L)

    fun plantName(): String? = prefs.getString("plant_name", null)

    fun savePlant(plant: Plant) {
        prefs.edit().putLong("plant_id", plant.id).putString("plant_name", plant.name).apply()
    }

    fun clearPlant() {
        prefs.edit().remove("plant_id").remove("plant_name").apply()
    }

    fun plants(): List<Plant> {
        val text = prefs.getString("plants_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(text)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                Plant(o.optLong("id"), o.optString("name"), o.optString("address"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun savePlants(list: List<Plant>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("address", it.address))
        }
        prefs.edit().putString("plants_json", arr.toString()).apply()
    }

    /** Battery size and reserve for one plant, or null until she has entered them. */
    fun plantBattery(plantId: Long): PlantBattery? {
        val kwh = prefs.getString("battery_kwh_$plantId", null)?.toDoubleOrNull() ?: return null
        val reserve = prefs.getString("reserve_pct_$plantId", null)?.toDoubleOrNull() ?: return null
        val cutoff = prefs.getString("cutoff_pct_$plantId", null)?.toDoubleOrNull() ?: 0.0
        return PlantBattery(kwh, reserve, cutoff)
    }

    fun savePlantBattery(plantId: Long, b: PlantBattery) {
        prefs.edit()
            .putString("battery_kwh_$plantId", b.kwh.toString())
            .putString("reserve_pct_$plantId", b.reservePct.toString())
            .putString("cutoff_pct_$plantId", b.cutoffPct.toString())
            .apply()
    }

    fun settings(): Settings {
        val d = Settings()
        return Settings(
            refreshMinutes = prefs.getInt("refresh_minutes", d.refreshMinutes).let { if (it == 1 || it == 2 || it == 5) it else d.refreshMinutes },
            showGenerator = prefs.getBoolean("show_generator", d.showGenerator),
            invertBattery = prefs.getBoolean("invert_battery", d.invertBattery),
            billStartDay = prefs.getInt("bill_start_day", d.billStartDay).coerceIn(1, 28)
        )
    }

    fun saveSettings(s: Settings) {
        prefs.edit()
            .putInt("refresh_minutes", s.refreshMinutes)
            .putBoolean("show_generator", s.showGenerator)
            .putBoolean("invert_battery", s.invertBattery)
            .putInt("bill_start_day", s.billStartDay.coerceIn(1, 28))
            .apply()
    }

    fun billEntry(plantId: Long, cycleStart: LocalDate): BillEntry =
        BillEntry(
            prefs.getString("bill_units_${plantId}_$cycleStart", "") ?: "",
            prefs.getString("bill_amount_${plantId}_$cycleStart", "") ?: ""
        )

    fun saveBillEntry(plantId: Long, cycleStart: LocalDate, e: BillEntry) {
        prefs.edit()
            .putString("bill_units_${plantId}_$cycleStart", e.units)
            .putString("bill_amount_${plantId}_$cycleStart", e.amount)
            .apply()
    }

    @Synchronized
    fun addCall() {
        val today = LocalDate.now().toString()
        val count = if (prefs.getString("calls_day", "") == today) prefs.getInt("calls", 0) else 0
        prefs.edit().putString("calls_day", today).putInt("calls", count + 1).apply()
    }

    @Synchronized
    fun callsToday(): Int {
        val today = LocalDate.now().toString()
        return if (prefs.getString("calls_day", "") == today) prefs.getInt("calls", 0) else 0
    }
}
