package com.solarmonitor.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class SolarmanException(val code: String?, message: String) : Exception(message)

data class Plant(val id: Long, val name: String)

fun sha256Lower(text: String): String {
    val bytes = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
    return bytes.joinToString("") { "%02x".format(it) }
}

private fun JSONObject.text(key: String): String? {
    if (!has(key) || isNull(key)) return null
    return optString(key).takeIf { it.isNotBlank() }
}

/**
 * Small client for the SOLARMAN OpenAPI. onCall runs before every request so the
 * app can count calls against the free plan allowance.
 */
class SolarmanApi(private val onCall: () -> Unit) {
    private val base = "https://globalapi.solarmanpv.com"
    private var token: String? = null
    private var tokenExpiresAtMs: Long = 0L

    suspend fun login(c: Credentials) {
        val body = JSONObject()
            .put("appSecret", c.appSecret)
            .put("email", c.email)
            .put("password", c.passwordHash)
        val reply = post("/account/v1.0/token", "appId=${c.appId}&language=en", body, null)
        val value = reply.text("access_token")
            ?: throw SolarmanException(null, "SOLARMAN did not send a token.")
        token = value
        val seconds = reply.optLong("expires_in", 3600L)
        tokenExpiresAtMs = System.currentTimeMillis() + (seconds - 300L).coerceAtLeast(60L) * 1000L
    }

    suspend fun plants(c: Credentials): List<Plant> {
        val body = JSONObject().put("pageNum", 1).put("pageSize", 20)
        val reply = authed(c, "/station/v1.0/list", body)
        val list: JSONArray = reply.optJSONArray("stationList") ?: JSONArray()
        val out = ArrayList<Plant>()
        for (i in 0 until list.length()) {
            val item = list.optJSONObject(i) ?: continue
            out.add(Plant(item.optLong("id"), item.text("name") ?: "My plant"))
        }
        return out
    }

    suspend fun realTime(c: Credentials, plantId: Long): JSONObject {
        val body = JSONObject().put("stationId", plantId)
        return authed(c, "/station/v1.0/realTime", body)
    }

    suspend fun dayHistory(c: Credentials, plantId: Long, date: String): JSONObject {
        val body = JSONObject()
            .put("stationId", plantId)
            .put("timeType", 2)
            .put("startTime", date)
            .put("endTime", date)
        return authed(c, "/station/v1.0/history", body)
    }

    private suspend fun ensureToken(c: Credentials) {
        if (token == null || System.currentTimeMillis() >= tokenExpiresAtMs) {
            login(c)
        }
    }

    private suspend fun authed(c: Credentials, path: String, body: JSONObject): JSONObject {
        ensureToken(c)
        return try {
            post(path, "language=en", body, token)
        } catch (e: SolarmanException) {
            if (e.code == "2101017" || e.code == "2101019") {
                token = null
                ensureToken(c)
                post(path, "language=en", body, token)
            } else {
                throw e
            }
        }
    }

    private suspend fun post(path: String, query: String, body: JSONObject, bearer: String?): JSONObject =
        withContext(Dispatchers.IO) {
            onCall()
            val conn = URL("$base$path?$query").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                if (bearer != null) conn.setRequestProperty("Authorization", "bearer $bearer")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                val status = conn.responseCode
                val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
                val json = try {
                    JSONObject(text)
                } catch (e: Exception) {
                    throw SolarmanException(null, "SOLARMAN sent a reply the app could not read (HTTP $status).")
                }
                val ok = if (json.has("success")) json.optBoolean("success", false) else status in 200..299
                if (!ok) {
                    throw SolarmanException(json.text("code"), json.text("msg") ?: "HTTP $status")
                }
                json
            } finally {
                conn.disconnect()
            }
        }
}
