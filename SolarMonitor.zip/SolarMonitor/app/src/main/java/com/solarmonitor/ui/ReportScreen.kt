package com.solarmonitor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.solarmonitor.UiState
import com.solarmonitor.data.IntraPoint
import com.solarmonitor.logic.Energy
import com.solarmonitor.logic.billCycle
import com.solarmonitor.logic.billGapPercent
import com.solarmonitor.logic.integrateKwh
import com.solarmonitor.logic.percentSplit
import com.solarmonitor.logic.total
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor

private val Tabs = listOf("Day", "Month", "Year", "Bill")
private val SheetColor = Color(0xFF1F2024)

private fun f1(v: Double): String = String.format(Locale.US, "%.1f", v)
private fun f2(v: Double): String = String.format(Locale.US, "%.2f", v)
private fun money(v: Double): String = "J$" + String.format(Locale.US, "%,.0f", v)

@Composable
fun ReportScreen(
    state: UiState,
    onLoad: () -> Unit,
    onTab: (Int) -> Unit,
    onShift: (Int) -> Unit,
    onRefresh: () -> Unit,
    onSaveBill: (String, String) -> Unit
) {
    val r = state.report
    val today = LocalDate.now()
    var shown by remember { mutableStateOf(DefaultSeries) }
    var cursor by remember(r.day) { mutableStateOf<Float?>(null) }
    var viewStart by remember(r.day) { mutableStateOf(0f) }
    var viewEnd by remember(r.day) { mutableStateOf(24f) }
    var filterOpen by remember { mutableStateOf(false) }

    LaunchedEffect(state.plantId) { onLoad() }

    val cycle = billCycle(r.cycleAnchor, state.settings.billStartDay)
    val label: String
    val sub: String?
    val canNext: Boolean
    when (r.tab) {
        0 -> {
            label = DateTimeFormatter.ofPattern("EEE d MMM yyyy", Locale.US).format(r.day)
            sub = null
            canNext = r.day.isBefore(today)
        }
        1 -> {
            label = DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US).format(r.month)
            sub = null
            canNext = r.month.isBefore(YearMonth.now())
        }
        2 -> {
            label = r.year.toString()
            sub = null
            canNext = r.year < today.year
        }
        else -> {
            val fmt = DateTimeFormatter.ofPattern("d MMM", Locale.US)
            label = fmt.format(cycle.first) + " ~ " + fmt.format(cycle.second)
            sub = if (cycle.second.isBefore(today)) "Billing cycle, complete"
            else "Billing cycle, day ${java.time.temporal.ChronoUnit.DAYS.between(cycle.first, today) + 1}"
            canNext = cycle.second.isBefore(today)
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 6.dp).height(60.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Report", color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Text(state.plantName, color = Palette.TextSecondary, fontSize = 13.sp, maxLines = 1)
            }
            RoundButton(Icons.Rounded.Refresh, "Refresh", true, 48.dp) { onRefresh() }
        }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Row(
            Modifier
                .padding(horizontal = 12.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Palette.Card)
                .padding(4.dp)
        ) {
            Tabs.forEachIndexed { i, name ->
                val on = r.tab == i
                Box(
                    Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (on) Palette.NavPill else Color.Transparent)
                        .clickable { onTab(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        name,
                        color = if (on) Palette.NavOn else Palette.TextSecondary,
                        fontSize = 15.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RoundButton(Icons.Rounded.ChevronLeft, "Previous", true, 44.dp) { onShift(-1) }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.CalendarMonth, null, tint = Palette.Text, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(label, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
                if (sub != null) Text(sub, color = Palette.TextSecondary, fontSize = 12.sp)
            }
            RoundButton(Icons.Rounded.ChevronRight, "Next", canNext, 44.dp) { onShift(1) }
            if (r.tab == 0) RoundButton(Icons.Rounded.FilterList, "Choose what to show", true, 44.dp) { filterOpen = true }
        }

        if (r.loading) {
            LinearProgressIndicator(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                color = Palette.NavOn,
                trackColor = Palette.Card
            )
        } else {
            Spacer(Modifier.height(10.dp))
        }

        Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            r.error?.let { msg ->
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Palette.ErrorCard).padding(14.dp)
                ) { Text(msg, color = Palette.ErrorText, fontSize = 14.sp) }
            }
            when (r.tab) {
                0 -> DayTab(
                    r.intra, r.points.total().takeIf { r.points.isNotEmpty() }, shown, cursor,
                    viewStart, viewEnd,
                    onView = { a, b -> viewStart = a; viewEnd = b },
                    onCursor = { cursor = it }
                )
                1 -> BarsTab(
                    "Month", r.points, YearMonth.from(r.month).lengthOfMonth(),
                    { it.dayOfMonth - 1 },
                    (0 until r.month.lengthOfMonth()).filter { it % 4 == 0 }.associateWith { (it + 1).toString() },
                    "kWh per day"
                )
                2 -> BarsTab(
                    "Year", r.points, 12, { it.monthValue - 1 },
                    (0 until 12).associateWith {
                        java.time.Month.of(it + 1).getDisplayName(java.time.format.TextStyle.SHORT, Locale.US)
                    },
                    "kWh per month"
                )
                else -> BillTab(state, cycle.first, cycle.second, onSaveBill)
            }
        }
        }
    }

    if (filterOpen) {
        FilterSheet(shown, onDismiss = { filterOpen = false }) { shown = it; filterOpen = false }
    }
}

@Composable
private fun RoundButton(icon: ImageVector, desc: String, enabled: Boolean, size: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Palette.Card)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = if (enabled) Palette.NavOn else Palette.IdleIcon, modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun Panel(modifier: Modifier = Modifier, side: androidx.compose.ui.unit.Dp = 16.dp, content: @Composable () -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Palette.Card)
            .padding(horizontal = side, vertical = 14.dp),
        content = { content() }
    )
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier, note: String? = null) {
    Column(modifier) {
        Text(label, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
        Text(value, color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        if (note != null) Text(note, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
    }
}

private class Part(val label: String, val color: Color, val kwh: Double)

@Composable
private fun SplitCard(title: String, total: Double, parts: List<Part>) {
    val pct = percentSplit(parts.map { it.kwh })
    Panel {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            Text(title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text(f1(total), color = Palette.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(" kWh", color = Palette.TextSecondary, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        Row(
            Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(Palette.Background)
        ) {
            val live = parts.filter { it.kwh > 0.0 }
            live.forEachIndexed { i, p ->
                if (i > 0) Spacer(Modifier.width(2.dp))
                Box(Modifier.weight(p.kwh.toFloat()).fillMaxHeight().background(p.color))
            }
        }
        Spacer(Modifier.height(8.dp))
        parts.forEachIndexed { i, p ->
            Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(p.color))
                Spacer(Modifier.width(8.dp))
                Text(p.label, color = Palette.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text("${pct[i]}%", color = Palette.TextSecondary, fontSize = 14.sp, textAlign = TextAlign.End, modifier = Modifier.width(48.dp))
                Text("${f1(p.kwh)} kWh", color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.width(88.dp))
            }
        }
    }
}

@Composable
private fun SplitCards(prefix: String, e: Energy) {
    SplitCard(
        "$prefix production", e.prod,
        listOf(Part("To load", Palette.Solar, e.toLoad), Part("To battery", Palette.Battery, e.toBattery), Part("To grid", Palette.Grid, e.toGrid))
    )
    SplitCard(
        "$prefix consumption", e.use,
        listOf(Part("From solar", Palette.Solar, e.fromSolar), Part("From battery", Palette.Battery, e.fromBattery), Part("From grid", Palette.Grid, e.fromGrid))
    )
}

private fun clockText(hour: Float): String {
    val h = floor(hour).toInt().coerceIn(0, 23)
    val m = ((hour - floor(hour)) * 60f).toInt().coerceIn(0, 59)
    val h12 = if (h % 12 == 0) 12 else h % 12
    return String.format(Locale.US, "%d:%02d %s", h12, m, if (h < 12) "AM" else "PM")
}

@Composable
private fun DayTab(
    intra: List<IntraPoint>,
    fromTotals: Energy?,
    shown: Set<Series>,
    cursor: Float?,
    viewStart: Float,
    viewEnd: Float,
    onView: (Float, Float) -> Unit,
    onCursor: (Float?) -> Unit
) {
    val sel = if (intra.isEmpty()) null else (cursor?.let { c -> nearestPoint(intra, c) } ?: intra.last())
    Panel(side = 4.dp) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (sel == null) "No readings" else "Pinch to zoom, drag to scroll",
                color = Palette.TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f)
            )
            listOf("Day" to 24f, "12 h" to 12f, "6 h" to 6f, "1 h" to 1f).forEach { (name, hours) ->
                val on = abs((viewEnd - viewStart) - hours) < 0.05f
                Box(
                    Modifier
                        .height(30.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .background(if (on) Palette.NavPill else Color.Transparent)
                        .clickable {
                            val centre = sel?.hour ?: ((viewStart + viewEnd) / 2f)
                            val ns = (centre - hours / 2f).coerceIn(0f, 24f - hours)
                            onView(ns, ns + hours)
                        }
                        .padding(horizontal = 11.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        name,
                        color = if (on) Palette.NavOn else Palette.TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        IntradayChart(
            points = intra, show = shown, cursorHour = sel?.hour,
            onCursor = onCursor,
            viewStart = viewStart, viewEnd = viewEnd, onView = onView,
            modifier = Modifier.fillMaxWidth().height(250.dp)
        )
        Spacer(Modifier.height(6.dp))
        DayOverview(
            points = intra, viewStart = viewStart, viewEnd = viewEnd, onView = onView,
            modifier = Modifier.fillMaxWidth().height(44.dp)
        )
        if (sel != null) {
            Spacer(Modifier.height(10.dp))
            Series.values().filter { it in shown }.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { s ->
                        val v = value(sel, s)
                        val text = if (s.isPercent) "${v.toInt()} %" else "${f2(v / 1000.0)} kW"
                        Column(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Palette.RunCard)
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(8.dp).clip(CircleShape).background(s.color))
                                Spacer(Modifier.width(6.dp))
                                Text(s.label, color = Palette.TextSecondary, fontSize = 12.sp, maxLines = 1)
                            }
                            Text(text, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }

    val e = fromTotals ?: if (intra.isEmpty()) null else Energy(
        prod = integrateKwh(intra) { it.solarW },
        use = integrateKwh(intra) { it.loadW },
        buy = integrateKwh(intra) { it.gridW },
        grid = 0.0,
        charge = integrateKwh(intra) { if (it.batteryW < 0) -it.batteryW else 0.0 },
        discharge = integrateKwh(intra) { if (it.batteryW > 0) it.batteryW else 0.0 }
    )
    if (e != null) {
        Panel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Produced", "${f1(e.prod)} kWh", Modifier.weight(1f))
                Stat("Used", "${f1(e.use)} kWh", Modifier.weight(1f))
                Stat("From grid", "${f1(e.buy)} kWh", Modifier.weight(1f))
            }
        }
        SplitCards("Daily", e)
        Panel {
            Text("Battery", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Charged", "${f1(e.charge)} kWh", Modifier.weight(1f))
                Stat("Discharged", "${f1(e.discharge)} kWh", Modifier.weight(1f))
                val low = intra.minByOrNull { it.soc }
                Stat(
                    "Lowest level", if (low != null) "${low.soc.toInt()} %" else "-", Modifier.weight(1f),
                    note = low?.let { "at " + clockText(it.hour) }
                )
            }
        }
    }
}

@Composable
private fun BarsTab(
    name: String,
    points: List<com.solarmonitor.data.DayPoint>,
    slots: Int,
    slotOf: (LocalDate) -> Int,
    labels: Map<Int, String>,
    caption: String
) {
    val e = points.total()
    Panel {
        Text(caption, color = Palette.TextSecondary, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        PairBarChart(
            slots = slots,
            bars = points.map { BarGroup(slotOf(it.date).coerceIn(0, slots - 1), it.prodKwh, it.useKwh) },
            labels = labels,
            colorA = Palette.Solar,
            colorB = Palette.Consumption,
            modifier = Modifier.fillMaxWidth().height(200.dp)
        )
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Legend("Produced", "${e.prod.toInt()} kWh", Palette.Solar, Modifier.weight(1f))
            Legend("Used", "${e.use.toInt()} kWh", Palette.Consumption, Modifier.weight(1f))
        }
    }
    if (points.isNotEmpty()) SplitCards(name, e)
    if (points.isNotEmpty()) {
        Panel {
            Text("Battery", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Charged", "${f1(e.charge)} kWh", Modifier.weight(1f))
                Stat("Discharged", "${f1(e.discharge)} kWh", Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun Legend(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Palette.RunCard).padding(horizontal = 10.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(6.dp))
            Text(label, color = Palette.TextSecondary, fontSize = 12.sp)
        }
        Text(value, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BillTab(state: UiState, start: LocalDate, end: LocalDate, onSave: (String, String) -> Unit) {
    val r = state.report
    val e = r.points.total()
    var units by remember(start, r.loading) { mutableStateOf(r.bill.units) }
    var amount by remember(start, r.loading) { mutableStateOf(r.bill.amount) }
    val billUnits = units.trim().replace(",", "").toDoubleOrNull()
    val billAmount = amount.trim().replace(",", "").toDoubleOrNull()
    val rate = if (billUnits != null && billAmount != null && billUnits > 0.0 && billAmount > 0.0) billAmount / billUnits else null

    Panel {
        Text("This cycle so far", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Used", "${e.use.toInt()} kWh", Modifier.weight(1f))
            Stat("From solar", "${e.fromSolar.toInt()} kWh", Modifier.weight(1f))
            Stat("From grid", "${e.buy.toInt()} kWh", Modifier.weight(1f))
        }
    }

    Panel {
        Text("Compare with your bill", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Type in the figures from your utility bill for this cycle.",
            color = Palette.TextSecondary, fontSize = 12.sp
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = units,
            onValueChange = { units = it; onSave(it, amount) },
            label = { Text("Units on the bill (kWh)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it; onSave(units, it) },
            label = { Text("Amount charged (J$)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        if (billUnits != null && billUnits > 0.0) {
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.Bottom) {
                Spacer(Modifier.weight(1f))
                Text("Your bill", color = Palette.TextSecondary, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.width(84.dp))
                Text("This app", color = Palette.TextSecondary, fontSize = 12.sp, textAlign = TextAlign.End, modifier = Modifier.width(84.dp))
            }
            Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Grid units", color = Palette.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(f1(billUnits), color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.width(84.dp))
                Text(f1(e.buy), color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End, modifier = Modifier.width(84.dp))
            }
            val diff = billUnits - e.buy
            Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Difference", color = Palette.Text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(
                    "${f1(abs(diff))} kWh (${abs(billGapPercent(billUnits, e.buy)).toInt()}%)",
                    color = if (abs(diff) < 0.5) Palette.Battery else Palette.ErrorText,
                    fontSize = 14.sp, fontWeight = FontWeight.Bold
                )
            }
            if (e.buy <= 0.0) {
                Text(
                    "The app shows no grid purchases for this cycle. SOLARMAN may not report meter units for your inverter, so the bill is the figure to trust.",
                    color = Palette.TextSecondary, fontSize = 12.sp
                )
            }
        }
    }

    Panel {
        Text("What solar saved you", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        if (rate != null) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(money(e.fromSolar * rate), color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("  estimate", color = Palette.TextSecondary, fontSize = 13.sp)
            }
            Text(
                "${e.fromSolar.toInt()} kWh from solar at your bill rate of J$${f2(rate)} per kWh.",
                color = Palette.TextSecondary, fontSize = 12.sp
            )
        } else {
            Text(
                "Add the units and amount from your bill to see the estimate.",
                color = Palette.TextSecondary, fontSize = 13.sp
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterSheet(current: Set<Series>, onDismiss: () -> Unit, onApply: (Set<Series>) -> Unit) {
    var draft by remember { mutableStateOf(current) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = SheetColor,
        contentColor = Palette.Text
    ) {
        Column(Modifier.navigationBarsPadding().verticalScroll(rememberScrollState()).padding(start = 20.dp, end = 20.dp, bottom = 24.dp)) {
            Text("What to show", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Palette.Text)
            Text("Power in kW on the left, battery charge in % on the right.", fontSize = 13.sp, color = Palette.TextSecondary)
            Spacer(Modifier.height(6.dp))
            Series.values().forEach { s ->
                val on = s in draft
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clickable { draft = if (on) draft - s else draft + s },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(s.color))
                    Spacer(Modifier.width(12.dp))
                    Text(s.label, fontSize = 16.sp, color = Palette.Text, modifier = Modifier.weight(1f))
                    Checkbox(
                        checked = on,
                        onCheckedChange = { draft = if (it) draft + s else draft - s },
                        colors = CheckboxDefaults.colors(
                            checkedColor = Palette.NavOn,
                            checkmarkColor = Palette.Background,
                            uncheckedColor = Palette.IdleIcon
                        )
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { draft = DefaultSeries }, modifier = Modifier.weight(1f).height(52.dp)) {
                    Text("Restore default", color = Palette.NavOn)
                }
                Button(
                    onClick = { onApply(if (draft.isEmpty()) DefaultSeries else draft) },
                    colors = ButtonDefaults.buttonColors(containerColor = Palette.NavOn, contentColor = Palette.Background),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) { Text("Show") }
            }
        }
    }
}
