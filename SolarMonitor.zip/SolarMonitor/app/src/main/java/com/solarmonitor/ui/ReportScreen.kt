package com.solarmonitor.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ReportScreen() {
    Column(Modifier.padding(16.dp)) {
        Text("Report", color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Text(
            "Monthly production and usage, and the comparison with your utility bill, will live here. This screen is built after Home is confirmed working.",
            color = Palette.TextSecondary, fontSize = 15.sp
        )
    }
}
